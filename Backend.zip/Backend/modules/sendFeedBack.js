module.exports = '<div style="margin:0; padding:0;font-family:arial;border:0;outline:0;background-color:#f7f7f7;padding-top:0px;">\
<table  border="0" cellpadding="0" cellspacing="0" width="100%" style="font-family:arial;" bgcolor="#f7f7f7">\
    <tr>\
        <td>\
        <table align="center" border="0" width="600px" cellpadding="0" cellspacing="0" style="margin-top:0px; margin-bottom:0px; background:#f7f7f7;width:600px;">\
            <tr>\
                <td align="center">\
                    <img src="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcSho9aI4PiUD6x4qYuTVQ4mK7CmWi6bWziPd7kRPJxvaVH2pv3k" alt="Logo"  style="padding:40px 0 10px 0;"/>\
                </td>\
            </tr>\
        </table>\
        </td>\
    </tr>\
</table>\
<table  border="0" cellpadding="0" cellspacing="0" width="100%" bgcolor="#f7f7f7" style="font-family:arial;">\
    <tr>\
        <td>\
            <table  align="center" border="0" width="600px" cellpadding="0" cellspacing="0" bgcolor="#ffffff"  style="margin-top:0px;margin-bottom:0px; background:#fff;width:600px;border:1px solid #e1e1e1;border-bottom:none;">\
                <tr>\
                    <td>\
                        <table align="center" cellpadding="0" cellspacing="0" width="100%" style="padding:50px;color:#565a5c;font-size:14px;">\
                            <tr><td>Hi,</td> </tr>\
                            <tr><td><br/></td></tr>\
                            <tr><td>Feedback from {{ nickname }}!</td></tr>\
                            <tr><td><br/></td></tr>\
                            <tr><td><b>Feedback:</b> {{ feedback }}</td></tr>\
                             <tr><td><br/></td></tr>\
                            <tr><td><br/></td></tr>\
                            <tr><td>Best regards,</td></tr>\
                            <tr><td><br/></td></tr>\
                            <tr><td>Team MadlyRad</td></tr>\
                        </table>\
                    </td>\
                </tr>\
            </table>\
        </td>\
    </tr>\
    <tr>\
        <td>\
            <table  align="center" border="0" width="600px" cellpadding="0" cellspacing="0" bgcolor="#ffffff"  style="margin-top:0px;margin-bottom:0px; background:#fff;width:600px;border:1px solid #e1e1e1;border-top:none;">\
                <tr>\
                    <td style="padding:15px;">\
                        <table align="center" cellpadding="0" cellspacing="0" bgcolor="#ffffff" width="100%" style="background:#fcb816;color:#fff;font-size:12px;padding:10px;">\
                            <tr><td><br/></td></tr>\
                            <tr><td><center><p style="margin:2px 0 5px 0;"><a href="#"><!-- <img src="alld_10.png" alt="refer button"/> --></a></p></center></td></tr>\
                        </table>\
                    </td>\
                </tr>\
            </table>\
        </td>\
    </tr>\
</table>\
<table  border="0" cellpadding="0" cellspacing="0" width="100%" style="font-family:arial;padding-bottom:50px;padding-top:10px;" bgcolor="#f7f7f7">\
    <tr>\
      <td align="center">\
            <a href="https://www.facebook.com/" target="_blank"><img src="www.facebook.com" alt="Facebook"/></a>&nbsp;\
            <!-- <a href="https://twitter.com/allmydox" target="_blank"><img src="https://www.alldox.com/Oneboxwebapp/images/alld_09_new.png" alt="Linked"/></a>&nbsp; -->\
            <a href="https://twitter.com" target="_blank"><img src="www.twitter.com" alt="Twitter"/></a> &nbsp;\
            <a href="" target="_blank"><img src="www.google.com" alt="Google"/></a>\
        </td>\
    </tr>\
</table>\
</div>\
';
