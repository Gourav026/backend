module.exports =
    '<body style="padding: 0;margin: 0;font-family: Arial, Helvetica, sans-serif;">\
        <div style="margin-top: 8%;text-align: center;">\
            <ul style="list-style: none;">\
                <li style="color:#827f9e;font-size: 20px;">Welcome, {{ name }},</li>\
                <li>Your One Time Password is </b></li>\
                <li style="margin-top:10px; font-size: 150%;">{{ verification_code }}</li>\
            </ul>\
        </div>\
</body>';