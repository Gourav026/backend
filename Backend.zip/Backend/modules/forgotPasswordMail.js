module.exports =
`<body style="background-color:rgb(235, 235, 235); margin: 25px;">\
<div style="background-color:white; width: 75%; margin: auto; padding: 10px; border-radius: 30px; box-shadow: 1px 1px 10px rgba(148,81,143,255)">\
<div style="text-align: center;"><img src="https://node.addydigital.com:3003/images/logo.png";alt="My logo";style="display: block; margin-left: auto;margin-right: auto;"  width="500" height="400"></div>\
<h1 style="margin-left: 5%;margin-right: 5%;text-align: left;font-size: 30px;">Forgot Password?</h1>\
<h1 style="margin-left: 5%;margin-right: 5%;text-align: left;font-size: 25px;">Don't Worry just follow the instructions below</h1>\
<div style="margin: 5%">\
<p style="text-align: left;font-size: 20px;">Hello {{ name }},</p>\
<p style="text-align: left;font-size: 20px;">Thank you for contacting BackSpin.</p>\
<p style="text-align: left;font-size: 20px;">We have reveived a forgot password request for the account related to this email id. If you wish to continue please click on the button below.</p>\
</div>\
<br>\
<a href={{ reset_password_link }}><button style="display: inline;background-color: #7b38d8;border-radius: 50px;border: 4px double #cccccc;color: #eeeeee;text-align: center;font-size: 20px;width: 80%;margin: 0% 0% 0% 10%;padding: 20px;-webkit-transition: all 0.5s;-moz-transition: all 0.5s;-o-transition: all 0.5s;transition: all 0.5s;cursor: pointer"> Reset Password </button></a>\
</div>\
</body>\  
`