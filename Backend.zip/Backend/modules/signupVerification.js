module.exports =
'<body style="background-color:rgb(235, 235, 235);margin: 25px;">\
<div style="background-color:white;width: 75%;margin: auto;padding: 10px;border-radius: 30px;box-shadow: 1px 1px 10px rgba(148,81,143,255)">\
<div style="text-align: center;"><img src="https://node.addydigital.com:3003/images/account.png";alt="My logo";style="display: block; margin-left: auto;margin-right: auto;"  width="500" height="400"></div>\
<br>\
<h2 style="margin: auto;text-align: center;font-size: 20px;">Account Successfully Created</h2>\
<br>\
<div style="margin: 5%">\
<p style="text-align: left;font-size: 20px;">Hello {{ name }},</p>\
<p style="text-align: left;font-size: 20px;">Your account have beed created successfully. Please click on the button below to confirm your account.</p>\
</div>\
<br>\
<a href={{ account_verify_link }}><button style="display: inline;background-color: #7b38d8;border-radius: 50px;border: 4px double #cccccc;color: #eeeeee;text-align: center;font-size: 20px;width: 80%;margin: 0% 0% 0% 10%;padding: 10px;-webkit-transition: all 0.5s;-moz-transition: all 0.5s;-o-transition: all 0.5s;transition: all 0.5s;cursor: pointer"> Confirm Account </button></a>\
</div>\
</body>\
'
