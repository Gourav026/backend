var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');

var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;

var notificationSchema = new Schema({
    fromUser: { type: mongoose.Schema.ObjectId },
    toUser: { type: mongoose.Schema.ObjectId },
    message: { type: String, default: '' },
    type: { type: String, default: '' }
    });

notificationSchema.plugin(mongoosePaginate);
notificationSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Notification', notificationSchema);