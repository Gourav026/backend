var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');

var crypto = require('crypto');
var _ = require('lodash');

var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var InsuaranceformSchema = new Schema({
            name       : { type: String, default: '' },
            age        : { type: Number },
            address    : { type: String, default: '' },
            city       : { type: String, default: '' },
            state      : { type: Number },
            country    : { type: String, default: '' },
            pin        : { type: Number },
            licence    : { type: String, default: '' },
            carNumber  : { type: String, default: '' }            

    }, 
    {
     timestamps: true
    });

InsuaranceformSchema.plugin(mongoosePaginate);
InsuaranceformSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Insuaranceform', InsuaranceformSchema);