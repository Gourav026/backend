let mongoose =require("mongoose");

let Schema=mongoose.Schema;

let HelpSchema=new Schema({
    title:{type: String},
    description:{type:String},
    status:{type:Boolean,default:true}
},
{
    timestamps:true
});

module.exports=mongoose.model('Help',HelpSchema);