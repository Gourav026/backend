let mongoose=require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');


let Schema = mongoose.Schema;

let CommentSchema=new Schema({
    module:{ type: String },
    userId:           {type: mongoose.Schema.ObjectId},
    newsFeedId:       {type: mongoose.Schema.ObjectId},
    comment     :     { type: String },
    status          : {type:Boolean , default:true},
   

},{
    timestamps: true
});

CommentSchema.plugin(mongoosePaginate);
CommentSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Comment', CommentSchema);