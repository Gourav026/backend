let mongoose=require('mongoose');
let mongoosePaginate = require('mongoose-paginate');
let mongooseAggregatePaginate = require('mongoose-aggregate-paginate');


let Schema = mongoose.Schema;

let NewsFeedSchema=new Schema({
    userId:           {type: mongoose.Schema.ObjectId},
    photo           : { type: String },
    imageMediumPath : { type: String },
    imageThumbPath  : { type: String },
    description     : { type: String },
    status          : {type:Boolean , default:true},
    video           : {type:String},
    videoThumb      : {type: String},
    likedBy         : [{type: mongoose.Schema.ObjectId}]
    

},{
    timestamps: true
});

NewsFeedSchema.plugin(mongoosePaginate);
NewsFeedSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('NewsFeed', NewsFeedSchema);