var AboutUsSchema =require("./aboutus")
var RoundSchema =require("./round")
var RoundDetailSchema =require("./roundDetail")
var CountrySchema =require("./country")
var StateSchema =require("./state")
var CitySchema =require("./city")
var CourseSchema =require("./course")
var CourseDetailSchema =require("./courseDetail")
var PrivacySchema =require("./privacy")
var TermSchema =require("./term")
var UserSchema =require("./users")
var IPBlocked =require("./ipBlocked")
var CountryBlock =require("./country-block")
var NewsFeedSchema =require("./newsFeed")
var CommentSchema =require("./comment")
var FeedbackSchema =require("./feedback")
let FaqSchema=require("./faq")
let HelpSchema=require("./help")
let PetitionSchema=require("./petition")
let NotificationSchema=require("./notification")
let InsuaranceformSchema=require("./insuaranceform")



module.exports = {
  AboutUsSchema,
  PrivacySchema,
  TermSchema,
  UserSchema,
  IPBlocked,
  CommentSchema,
  NewsFeedSchema,
  CountryBlock,
  CountrySchema,
  StateSchema,
  CitySchema,
  CourseSchema,
  CourseDetailSchema,
  RoundSchema,
  RoundDetailSchema,
  HelpSchema,
  FaqSchema,
  FeedbackSchema,
  PetitionSchema,
  NotificationSchema,
  InsuaranceformSchema
};
