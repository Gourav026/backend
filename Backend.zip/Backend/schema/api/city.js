var mongoose = require('mongoose');

const authTypes = ['apple', 'facebook', 'google', 'socialLogin'];
var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var CitySchema = new Schema({ 
            countryId     : { type: mongoose.Schema.ObjectId },
            stateId       : { type: mongoose.Schema.ObjectId },
            name          : { type: String},
            status        : { type: Boolean, default:true},
            latitude:     { type: Number},
            longitude:    { type: Number},
    }, 
    {
     timestamps: true
    });

// Validate empty name
CitySchema
  .path('name')
  .validate(function(name) {
    return name.length;
  }, 'name cannot be blank');

// Validate name is not taken
CitySchema
  .path('name')
  .validate(async function(value) {
    
    let cityExist = await this.constructor.findOne({ name: value })
    
    if (cityExist && this.isNew) {
      console.log('cityExist------>',cityExist)
  
      return false;
    }
    return true;  
  }, 'The specified name address is already in use.');

CitySchema.plugin(mongoosePaginate);
CitySchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('City', CitySchema);