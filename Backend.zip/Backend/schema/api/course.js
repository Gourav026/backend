var mongoose = require('mongoose');

const authTypes = ['apple', 'facebook', 'google', 'socialLogin'];
var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var CourseSchema = new Schema({    
            name            : { type: String },
            description     : { type: String },
            imageType       : { type: String },
            photo           : { type: String },
            imageMediumPath : { type: String },
            imageThumbPath  : { type: String },
            countryId       : { type: mongoose.Schema.ObjectId },
            stateId         : { type: mongoose.Schema.ObjectId },
            cityId          : { type: mongoose.Schema.ObjectId },
            rating          : { type: Number , default:0},
            lastRecord      : { type: Number , default:0},
            blueYard        : { type: Number , default:0},
            whiteYard       : { type: Number , default:0},
            yellowYard      : { type: Number , default:0},
            redYard         : { type: Number , default:0},
            lastRecordBy    : { type: mongoose.Schema.ObjectId },
            totalTimesPlayed: { type: Number , default:0},
            geoLocation     : [{
                                type: [Object],
                                index: '2d'
                              }],
            status          : { type: Boolean, default: true }
    }, 
    {
     timestamps: true
    });

// Validate empty name
CourseSchema
  .path('name')
  .validate(function(name) {
    return name.length;
  }, 'name cannot be blank');

// Validate name is not taken
CourseSchema
  .path('name')
  .validate(async function(value) {
    
    let courseExist = await this.constructor.findOne({ name: value })
    
    if (courseExist  && this.isNew) {
      console.log('courseExist------>',courseExist)
  
      return false;
    }
    return true;  
  }, 'The specified name address is already in use.');

CourseSchema.plugin(mongoosePaginate);
CourseSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Course', CourseSchema);