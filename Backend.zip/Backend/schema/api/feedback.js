var mongoose = require('mongoose');

var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var FeedbackSchema = new Schema({
            userId   : { type: mongoose.Schema.ObjectId , ref:'User'},
            title    : { type: String},
           description : { type: String },

    });

    FeedbackSchema.plugin(mongoosePaginate);
    FeedbackSchema.plugin(mongooseAggregatePaginate);
    module.exports = mongoose.model('Feedback', FeedbackSchema);