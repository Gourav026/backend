var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');

var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;

var privacySchema = new Schema({
    description: { type: String, default: '' },
    status: { type: Boolean,  default: true  }
    }, 
    {
            timestamps: true
    });


privacySchema.plugin(mongoosePaginate);
privacySchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('Privacy', privacySchema);