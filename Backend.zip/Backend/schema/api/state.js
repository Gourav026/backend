var mongoose = require('mongoose');

const authTypes = ['apple', 'facebook', 'google', 'socialLogin'];
var mongoosePaginate = require('mongoose-paginate');
var mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

var Schema = mongoose.Schema;
var StateSchema = new Schema({ 
            countryId     : { type: mongoose.Schema.ObjectId },
            name          : { type: String},
            status        : { type: Boolean, default:true}
    }, 
    {
     timestamps: true
    });

// Validate empty name
StateSchema
  .path('name')
  .validate(function(name) {
    return name.length;
  }, 'name cannot be blank');

// Validate name is not taken
StateSchema
  .path('name')
  .validate(async function(value) {
    
    let stateExist = await this.constructor.findOne({ name: value })
    
    if (stateExist  && this.isNew) {
      console.log('stateExist------>',stateExist)
  
      return false;
    }
    return true;  
  }, 'The specified name address is already in use.');

StateSchema.plugin(mongoosePaginate);
StateSchema.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model('State', StateSchema);






