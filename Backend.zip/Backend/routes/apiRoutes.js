/**
 * Main application routes
 */

"use strict";
var express = require("express");
var bodyParser = require('body-parser');

var errors = require("../components/errors")
var path = require("path")
var auth = require("../auth/auth.service")
var userController = require("../api/v1/userController")
var countryController = require("../api/v1/countryController")
var stateController = require("../api/v1/stateController")
var feedbackController = require("../api/v1/feedbackController")
var cityController = require("../api/v1/cityController")
var courseController = require("../api/v1/courseController")
var courseDetailController = require("../api/v1/courseDetailController")
var roundController = require("../api/v1/roundController")
var roundDetailController = require("../api/v1/roundDetailController")
var commentController = require("../api/v1/commentController")
var petitionController = require("../api/v1/petitionController")

var statisticController = require("../api/v1/statisticController")
var courseStatisticController = require("../api/v1/courseStatisticController")
var newsFeedController = require("../api/v1/newsFeedController")
var notificationController = require("../api/v1/notificationController")
var sendEmailController = require("../api/v1/sendEmailController")
var privacyController = require("../admin/v1/privacyController")
var faqController = require("../admin/v1/faqController")
const helpController = require("../admin/v1/helpController");

var geoBusiness =require("../businesses/geoBusiness")
var multer = require("multer")
var config = require("../config/environment")
var { StringHelper } = require("../helpers")


var multipart = require("connect-multiparty");
var multipartMiddleware = multipart();

var storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, config.fileTempFolder);
  },

  filename: function(req, file, cb) {
    let name =
      StringHelper.randomString(7) +
      "_" +
      StringHelper.getFileName(file.originalname);

    cb(null, name);
  }
});
var upload = multer({
  storage
});

function validateAdminOrPerformer(req, res, next) {
  if (req.user.role !== "admin" && !req.isPerformer) {
    return res.status(403).end();
  }

  next();
}

var whiteListIps = ["0.0.0.1"];
const checkBlocked = function(req, res, next) {
  var ip = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  if (whiteListIps.indexOf(ip) > -1 || ip.indexOf('64.38.212') > -1 || ip.indexOf('64.38.215') > -1 || ip.indexOf('64.38.240') > -1 || ip.indexOf('64.38.241') > -1) {
    return next();
  }
  geoBusiness.checkBlocked(ip, function(err, blocked) {
    if (err || blocked) {
      return res.status(403).send();
    }

    return next();
  });
};


  var app = express.Router();
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({
      extended: false
  }));
  console.log('app routes hitted');
  
  app.get("/v1/test",  function(req,res){
    console.log('test hitted');
    res.send('hi')
  });

  // app.post("/v1/changePassword",  function(req,res){
  //   console.log('changePassword hitted');
  //   res.send('changePassword')
  // });

  //app.use("*", checkBlocked);

 //--------- users profile start -------   
      app.post(
        "/v1/users/register",
        userController.create
      ); 

      app.delete(
        "/v1/users/deleteAll",
        userController.deleteAll
      );
      
      app.post(
        "/v1/changePassword",
        userController.changePassword
      ); 

      app.get(
        "/v1/users",  
        userController.index
      );

      app.put(
          "/v1/users/:id",
          auth.isAuthenticated(),
          userController.update
      );
      
      app.put(
        "/v1/userEmailVerification/:id",
        userController.update
      );

      app.delete(
        "/v1/users/:id",
        auth.isAuthenticated(),
        userController.delete
      );

      app.get(
        "/v1/verifyauth",  
        userController.verifyauth
      );
 //--------- users profile end -------   

 //--------- country start -------   
      app.post(
        "/v1/country/add",
        countryController.create
      ); 

      app.get(
        "/v1/country",  
        countryController.index
      );

      app.put(
          "/v1/country/:id",
          auth.isAuthenticated(),
          countryController.update
      );
      
      app.delete(
        "/v1/country/:id",
        auth.isAuthenticated(),
        countryController.delete
      );
//--------- country end -------  


//__________ Feedback Start ________//
app.get(
  "/v1/feedback",  
  feedbackController.index
);
app.post(
  "/v1/feedback/add",
  feedbackController.create
); 
//__________ Feedback End ________//
 //--------- state start -------   
      app.post(
        "/v1/state/add",
        stateController.create
      ); 

      app.get(
        "/v1/state",  
        stateController.index
      );

      app.put(
          "/v1/state/:id",
          auth.isAuthenticated(),
          stateController.update
      );
      
      app.delete(
        "/v1/state/:id",
        auth.isAuthenticated(),
        stateController.delete
      );
//--------- state end -------   

 //--------- city start -------   
      app.post(
        "/v1/city/add",
        cityController.create
      ); 

      app.get(
        "/v1/city",  
        cityController.index
      );

      app.put(
          "/v1/city/:id",
          auth.isAuthenticated(),
          cityController.update
      );
      
      app.delete(
        "/v1/city/:id",
        auth.isAuthenticated(),
        cityController.delete
      );
//--------- city end -------   

 //--------- course start -------   
      app.post(
        "/v1/course/add",
        courseController.create
      ); 

      app.get(
        "/v1/course",  
        courseController.index
      );

      app.put(
          "/v1/course/:id",
          auth.isAuthenticated(),
          courseController.update
      );
      
      app.delete(
        "/v1/course/:id",
        auth.isAuthenticated(),
        courseController.delete
      );
//--------- course end -------   
  

 //--------- course Detail start -------   
      app.post(
        "/v1/courseDetail/add",
        courseDetailController.create
      ); 

      app.get(
        "/v1/courseDetail",  
        courseDetailController.index
      );

      app.put(
          "/v1/courseDetail/:id",
          auth.isAuthenticated(),
          courseDetailController.update
      );
      
      app.delete(
        "/v1/courseDetail/:id",
        auth.isAuthenticated(),
        courseDetailController.delete
      );
//--------- course Detail end -------   



//--------- round  start -------   

      app.get(
        "/v1/round",  
        roundController.index
    );

      app.post(
        "/v1/users/:id/round/start",
        auth.isAuthenticated(),
        roundController.start
      );
            
      app.put(
        "/v1/round/:id",
        auth.isAuthenticated(),
        roundController.update
     );
//--------- round  end ------- 

//--------- round Detail start -------   
      app.post(
        "/v1/roundDetail/add",
        roundDetailController.create
      ); 

      app.post(
        "/v1/roundDetail/addnext",
        roundDetailController.createnext
      ); 

      app.get(
        "/v1/roundDetail",  
        roundDetailController.index
      );

      app.put(
          "/v1/roundDetail/:id",
          auth.isAuthenticated(),
          roundDetailController.update
      );
      
      app.delete(
        "/v1/roundDetail/:id",
        auth.isAuthenticated(),
        roundDetailController.delete
      );
//--------- round Detail end ------- 

//--------- admin news Feed start -------   
      app.post(
        "/v1/newsFeed/add",
        newsFeedController.create
      ); 

      app.get(
        "/v1/newsFeed",  
        newsFeedController.index
      );
      app.get(
        "/v1/newsFeedList",  
        newsFeedController.newsFeedList
      );

      app.put(
          "/v1/newsFeed/:id",
          auth.isAuthenticated(),
          newsFeedController.update
      );

      app.delete(
        "/v1/newsFeed/:id",
        auth.isAuthenticated(),
        newsFeedController.delete
      );
//--------- admin news Feed end -------  

//--------- admin comment start -------   
      app.post(
        "/v1/comment/add",
        commentController.create
      ); 

      app.get(
        "/v1/comment",  
        commentController.index
      );

      app.put(
          "/v1/comment/:id",
          auth.isAuthenticated(),
          commentController.update
      );

      app.delete(
        "/v1/comment/:id",
        auth.isAuthenticated(),
        commentController.delete
      );
//--------- admin comment end -------  

//--------- Statistic Report start -------   

    app.get(
      "/v1/leaderBoardStatistic",  
      statisticController.leaderBoardStatistic
    );
    
    app.get(
      "/v1/coursewiseLeaderBoardStatistic",  
      statisticController.coursewiseLeaderBoardStatistic
    );

    app.get(
      "/v1/playerwiseLeaderBoardStatistic",  
      statisticController.playerwiseLeaderBoardStatistic
    );


//--------- Statistic Report end ------- 


//--------- course Statistic start -------   

    app.get(
      "/v1/mostPopular",  
      courseStatisticController.mostPopularCourse
    );
    app.get(
      "/v1/mostPlayed",  
      courseStatisticController.mostPlayedCourse
    );

    

//--------- course Statistic end -------  

//...................Notification ..............

    app.post(
      "/v1/notification/add",
      notificationController.create
    ); 

    app.post(
      "/v1/notification/send",
      notificationController.send
    ); 

    app.get(
      "/v1/notification",  
      notificationController.index
    );

    app.delete(
      "/v1/notification/:id",
      auth.isAuthenticated(),
      notificationController.delete
    );

    app.post(
      '/v1/sendmail', 
      sendEmailController.sendEmail
    );


//----------------End Notification .............

 //--------- api privacy start -------   
    app.get(
      "/v1/privacy",  
      privacyController.index
    );
//--------- api privacy end -------   

//--------- api faq start -------   
    app.get(
      "/v1/faq",  
      faqController.index
    );
//--------- api faq end -------   

//--------- api help start -------   

    app.get(
      "/v1/help",  
      helpController.index
    );

//--------- api help end -------   


//--------- api petition start -------   
    app.post(
      "/v1/petition/add",
      petitionController.create
    ); 

    app.get(
      "/v1/petition",  
      petitionController.index
    );

    app.put(
        "/v1/petition/:id",
        auth.isAuthenticated(),
        petitionController.update
    );

    app.delete(
      "/v1/petition/:id",
      auth.isAuthenticated(),
      petitionController.delete
    );
//--------- api petition end -------  


 //--------- api forget password mail send start -------   
      
    app.post(
      "/v1/forgetPasswordMailVerification",  
      userController.forgetPasswordMailVerification
    );
 //--------- api forget password mail send start -------   

  // app.get("/api/v1/users/:id", auth.hasRole("admin"), userController.show);

  // //app.get("/api/v1/users", auth.hasRole("admin"), userController.index);
  // app.get("/api/v1/users/check/uservip", userController.checkVip);

  // app.get("/api/v1/users/verifyEmail/:token", userController.verifyEmail);
  // //app.use("/auth", require("../auth"));

  // app.post("/api/v1/server/reload", auth.hasRole("admin"), function(req, res) {
  //   var pm2Id = process.env.PM2_ID || 0;
  //   var cmd = `pm2 reload ${pm2Id}`;

  //   exec(cmd, function(error, stdout, stderr) {
  //     res.status(200).end();
  //   });
  // });

  // All undefined asset or api routes should return a 404
  app
    .route(
      "/:url(api|auth|components|app|bower_components|assets|lib|styles)/*"
    )
    .get(errors[404]);
  app.get(/^\/backend(.*)$/, (req, res) => {
    res.sendFile(path.resolve("backend/index.html"));
  });
  // All other routes should redirect to the index.html
  app.route("/*").get((req, res) => {
    res.sendFile(path.resolve(app.get("appPath") + "/index.html"));
  });
  module.exports= app
  
// /*i|auth|components|app|bower_components|assets|lib|styles)"
//     )
//     .get(errors[404]);
//   app.get(/^\/backend(.*)$/, (req, res) => {
//     res.sendFile(path.resolve("backend/index.html"));
//   });
//   // All other routes should redirect to the index.html
//   app.route("/*").get((req, res) => {
//     res.sendFile(path.resolve(app.get("appPath") + "/index.html"));
//   });
//   module.exports= app
// i|auth|components|app|bower_components|assets|lib|styles)/*"
//     )
//     .get(errors[404]);
//   app.get(/^\/backend(.*)$/, (req, res) => {
//     res.sendFile(path.resolve("backend/index.html"));
//   });
//   // All other routes should redirect to the index.html
//   app.route("/*").get((req, res) => {
//     res.sendFile(path.resolve(app.get("appPath") + "/index.html"));
//   });
//   module.exports= app

