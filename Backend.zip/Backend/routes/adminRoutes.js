/**
 * Main application routes
 */

"use strict";
var express = require("express");
var bodyParser = require('body-parser');

var errors = require("../components/errors")
var path = require("path")
var auth = require("../auth/auth.service")
var adminController = require("../admin/v1/adminController")
var userController = require("../admin/v1/userController")
var countryController = require("../admin/v1/countryController")
var stateController = require("../admin/v1/stateController")
var cityController = require("../admin/v1/cityController")
var termController = require("../admin/v1/termController")
var aboutUsController = require("../admin/v1/aboutUsController")
var privacyController = require("../admin/v1/privacyController")
var courseController = require("../admin/v1/courseController")
var courseDetailController = require("../admin/v1/courseDetailController")
var feedbackController = require("../admin/v1/feedbackController")
//var courseStatisticController = require("../admin/v1/courseStatisticController")
var newsFeedController =require("../admin/v1/newsFeedController")
var commentController =require("../admin/v1/commentController")


var roundController = require("../admin/v1/roundController")
var roundDetailController = require("../admin/v1/roundDetailController")
var faqController = require("../admin/v1/faqController")
// var statisticController = require("../admin/v1/statisticController")
var geoBusiness =require("../businesses/geoBusiness")
var multer = require("multer")
var config = require("../config/environment")
var { StringHelper } = require("../helpers")


var multipart = require("connect-multiparty");
const helpController = require("../admin/v1/helpController");
var multipartMiddleware = multipart();

var storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, config.fileTempFolder);
  },

  filename: function(req, file, cb) {
    let name =
      StringHelper.randomString(7) +
      "_" +
      StringHelper.getFileName(file.originalname);

    cb(null, name);
  }
});
var upload = multer({
  storage
});

function validateAdminOrPerformer(req, res, next) {
  if (req.user.role !== "admin" && !req.isPerformer) {
    return res.status(403).end();
  }

  next();
}

var whiteListIps = ["0.0.0.1"];
const checkBlocked = function(req, res, next) {
  var ip = req.headers["x-forwarded-for"] || req.connection.remoteAddress;
  if (whiteListIps.indexOf(ip) > -1 || ip.indexOf('64.38.212') > -1 || ip.indexOf('64.38.215') > -1 || ip.indexOf('64.38.240') > -1 || ip.indexOf('64.38.241') > -1) {
    return next();
  }
  geoBusiness.checkBlocked(ip, function(err, blocked) {
    if (err || blocked) {
      return res.status(403).send();
    }

    return next();
  });
};


  var app = express.Router();
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({
      extended: false
  }));
  console.log('app routes hitted');
  
  app.get("/v1/test",  function(req,res){
    console.log('test hitted');
    res.send('hi')
  });

  //app.use("*", checkBlocked);

 //--------- admin profile start -------   
      app.post(
        "/v1/admin/register",
        adminController.create
      ); 

      app.get(
        "/v1/admin",  
        adminController.index
      );

      app.put(
          "/v1/admin/:id",
          auth.isAuthenticated(),
          adminController.update
      );
      
      app.delete(
        "/v1/admin/:id",
        auth.isAuthenticated(),
        adminController.delete
      );
 //--------- admin profile end -------   


 //--------- admin user profile start -------   
      app.post(
        "/v1/user/register",
        userController.create
      ); 

      app.get(
        "/v1/user",  
        userController.index
      );

      app.put(
          "/v1/user/:id",
          auth.isAuthenticated(),
          userController.update
      );
      
      app.delete(
        "/v1/user/:id",
        auth.isAuthenticated(),
        userController.delete
      );
      
      app.get(
        "/v1/userList",  
        userController.userList
      );

      app.get(
        "/v1/verifyauth",  
        userController.verifyauth
      );
 //--------- admin user profile end -------   

 //--------- admin country start -------   
      app.post(
      "/v1/country/add",
      countryController.create
      ); 

      app.get(
        "/v1/country",  
        countryController.index
      );

      app.get(
        "/v1/countryList",  
        countryController.countryList
      );

      app.put(
          "/v1/country/:id",
          auth.isAuthenticated(),
          countryController.update
      );

      app.delete(
        "/v1/country/:id",
        auth.isAuthenticated(),
        countryController.delete
      );
//--------- admin country end -------   

//--------- admin city start -------   
    app.post(
      "/v1/city/add",
      cityController.create
      ); 

      app.get(
        "/v1/city",  
        cityController.index
      );

      app.get(
        "/v1/cityList",  
        cityController.cityList
      );

      app.put(
          "/v1/city/:id",
        auth.isAuthenticated(),
          cityController.update
      );

      app.delete(
        "/v1/city/:id",
        auth.isAuthenticated(),
        cityController.delete
      );
//--------- admin city end -------   


//--------- admin state start -------   
      app.post(
        "/v1/state/add",
        stateController.create
      );

      app.get(
        "/v1/state",  
        stateController.index
      );

      app.get(
        "/v1/stateList",  
        stateController.stateList
      );

      app.put(
          "/v1/state/:id",
        auth.isAuthenticated(),
          stateController.update
      );

      app.delete(
        "/v1/state/:id",
        auth.isAuthenticated(),
        stateController.delete
      );
//--------- admin state end -------   


 //--------- admin term start -------   
      app.post(
        "/v1/term/register",
        termController.create
      ); 

      app.get(
        "/v1/term",  
        termController.index
      );

      app.put(
          "/v1/term/:id",
          auth.isAuthenticated(),
          termController.update
      );
      
      app.delete(
        "/v1/term/:id",
        auth.isAuthenticated(),
        termController.delete
      );
 //--------- admin term end -------   

 //--------- admin feedback start -------   
              app.post(
                "/v1/feedback/register",
                feedbackController.create
              ); 

              app.get(
                "/v1/feedback",  
                feedbackController.index
              );

              app.put(
                  "/v1/feedback/:id",
                  auth.isAuthenticated(),
                  feedbackController.update
              );

              app.delete(
                "/v1/feedback/:id",
                auth.isAuthenticated(),
                feedbackController.delete
              );
//--------- admin feedback end -------   

 
 //--------- admin privacy start -------   
      app.post(
        "/v1/privacy/register",
        privacyController.create
      ); 

      app.get(
        "/v1/privacy",  
        privacyController.index
      );

      app.put(
          "/v1/privacy/:id",
          auth.isAuthenticated(),
          privacyController.update
      );
      
      app.delete(
        "/v1/privacy/:id",
        auth.isAuthenticated(),
        privacyController.delete
      );
 //--------- admin privacy end -------   

 
 //--------- admin aboutUs start -------   
      app.post(
        "/v1/aboutUs/register",
        aboutUsController.create
      ); 

      app.get(
        "/v1/aboutUs",  
        aboutUsController.index
      );

      app.put(
          "/v1/aboutUs/:id",
          auth.isAuthenticated(),
          aboutUsController.update
      );
      
      app.delete(
        "/v1/aboutUs/:id",
        auth.isAuthenticated(),
        aboutUsController.delete
      );
 //--------- admin aboutUs end -------   

 
 //--------- admin course start -------   
      app.post(
        "/v1/course/register",
        courseController.create
      ); 

      app.get(
        "/v1/course",  
        courseController.index
      );

      app.get(
        "/v1/courseList",  
        courseController.courseList
      );

      app.put(
          "/v1/course/:id",
          auth.isAuthenticated(),
          courseController.update
      );
      
      app.delete(
        "/v1/course/:id",
        auth.isAuthenticated(),
        courseController.delete
      );
 //--------- admin course end -------  
 
 
 //--------- admin course Detail start -------   
      app.post(
        "/v1/courseDetail/register",
        courseDetailController.create
      ); 

      app.get(
        "/v1/courseDetail",  
        courseDetailController.index
      );

      app.put(
          "/v1/courseDetail/:id",
          auth.isAuthenticated(),
          courseDetailController.update
      );
      app.put(
          "/v1/courseDetail/bulk/update",
          //auth.isAuthenticated(),
          courseDetailController.bulkUpdate
      );
      
      app.delete(
        "/v1/courseDetail/:id",
        auth.isAuthenticated(),
        courseDetailController.delete
      );
 //--------- admin course Detail end -------  


 //--------- admin news Feed start -------   
      app.post(
        "/v1/newsFeed/add",
        newsFeedController.create
      ); 

      app.get(
        "/v1/newsFeed",  
        newsFeedController.index
      );

      app.put(
          "/v1/newsFeed/:id",
          auth.isAuthenticated(),
          newsFeedController.update
      );

      app.delete(
        "/v1/newsFeed/:id",
        auth.isAuthenticated(),
        newsFeedController.delete
      );
 //--------- admin news Feed end -------  


 //--------- admin comment start -------   
 app.post(
  "/v1/comment/add",
  commentController.create
); 

app.get(
  "/v1/comment",  
  commentController.index
);

app.put(
    "/v1/comment/:id",
    auth.isAuthenticated(),
    commentController.update
);

app.delete(
  "/v1/comment/:id",
  auth.isAuthenticated(),
  commentController.delete
);
//--------- admin comment end -------  

//--------- round  start -------   

      app.get(
        "/v1/round",  
        roundController.index
       );

      app.post(
        "/v1/users/:id/round/start",
        auth.isAuthenticated(),
        roundController.start
      );
      
      app.put(
        "/v1/round/:id",
        auth.isAuthenticated(),
        roundController.update
     );
     app.delete(
      "/v1/round/:id",
      auth.isAuthenticated(),
      roundController.delete
   );
//--------- round  end ------- 

//--------- round Detail start -------   
      app.post(
        "/v1/roundDetail/add",
        roundDetailController.create
      ); 

      app.get(
        "/v1/roundDetail",  
        roundDetailController.index
      );

      app.put(
          "/v1/roundDetail/:id",
          auth.isAuthenticated(),
          roundDetailController.update
      );
      
      app.delete(
        "/v1/roundDetail/:id",
        auth.isAuthenticated(),
        roundDetailController.delete
      );
//--------- round Detail end ------- 

//--------- FAQ start -------   
  app.post(
    "/v1/faq/add",
    faqController.create
  ); 

  app.get(
    "/v1/faq",  
    faqController.index
  );

  app.put(
      "/v1/faq/:id",
      auth.isAuthenticated(),
      faqController.update
  );

  app.delete(
    "/v1/faq/:id",
    auth.isAuthenticated(),
    faqController.delete
  );
//--------- FAQ end ------- 
//--------- HELP start -------   
app.post(
  "/v1/help/add",
  helpController.create
); 

app.get(
  "/v1/help",  
  helpController.index
);

app.put(
    "/v1/help/:id",
    auth.isAuthenticated(),
    helpController.update
);

app.delete(
  "/v1/help/:id",
  auth.isAuthenticated(),
  helpController.delete
);
//--------- HELP end ------- 



 //--------- admin course Statistic start -------   

  // app.get(
  //   "/v1/mostPopular",  
  //   courseStatisticController.mostPopularCourse
  // );
  // app.get(
  //   "/v1/mostPlayed",  
  //   courseStatisticController.mostPlayedCourse
  // );

//--------- admin course Statistic end -------  
  app
    .route(
      "/:url(api|auth|components|app|bower_components|assets|lib|styles)/*"
    )
    .get(errors[404]);
  app.get(/^\/backend(.*)$/, (req, res) => {
    res.sendFile(path.resolve("backend/index.html"));
  });
  // All other routes should redirect to the index.html
  app.route("/*").get((req, res) => {
    res.sendFile(path.resolve(app.get("appPath") + "/index.html"));
  });
  module.exports= app
