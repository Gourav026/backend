
const {app,server} = require('./index')

server.listen(3004, function (err) {
    if (err) {
        throw err;
    } else {
        console.log("Server is running at http://localhost:" + 3004);
    }
});
server.timeout = 5000000;