'use strict';

var { CourseDetailBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { CourseDetailValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

const validationError=(res, statusCode,message,data)=>{
  statusCode= statusCode||500;
  return res.status(statusCode)
      .send({
          statusCode:statusCode,
          message:message,
          success:false,
          response:data,
      });
}



const handleResponse=(res, statusCode,message,data)=>{
  statusCode= statusCode||500;
  return res.status(statusCode)
      .send({
          statusCode:statusCode,
          message:message,
          success:true,
          response:data,
      });
}


class CourseDetailController {
  /**
   * Get list of courseDetails
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return CourseDetailBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'CourseDetail List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new courseDetail
   */
  static create(req, res, next) {

    CourseDetailValidator.validateCreating(req.body).then( courseDetail => {
      
        courseDetail.courseId = req.body.courseId;
        courseDetail.holeNumber = req.body.holeNumber;
        courseDetail.par = req.body.par;
        courseDetail.strokeIndex = req.body.strokeIndex;
        courseDetail.CenterLatLong = req.body.CenterLatLong;
        courseDetail.scoringAverage = req.body.scoringAverage;
        if(req.body.geoLocation)
        {
          courseDetail.geoLocation = JSON.parse(req.body.geoLocation);
        }
        courseDetail.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:true
             
         CourseDetailBusiness.create(courseDetail)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'CourseDetail Added Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));



  }


   /**
   * Update Profile CourseDetail
   */
  static update(req, res, next) {
    //TODO - update validator
    CourseDetailValidator.validateUpdating({...req.body, ...req.params}).then(courseDetail => {
    console.log('req.files--->', req.files)
    var courseDetailId = req.params.id;
    CourseDetailBusiness.findOne({_id: courseDetailId})
      .then(courseDetail => {
        if (!courseDetail) { 
          handleResponse(res, 500, 'CourseDetail Not Exist', {}) 
        }
        courseDetail.courseId = req.body.courseId?req.body.courseId:courseDetail.courseId;
        courseDetail.holeNumber = req.body.holeNumber?req.body.holeNumber:courseDetail.holeNumber;
        courseDetail.par = req.body.par?req.body.par:courseDetail.par;
        courseDetail.strokeIndex = req.body.strokeIndex?req.body.strokeIndex:courseDetail.strokeIndex;
        courseDetail.scoringAverage = req.body.scoringAverage?req.body.scoringAverage:courseDetail.scoringAverage;
        courseDetail.CenterLatLong = req.body.CenterLatLong?req.body.CenterLatLong:courseDetail.CenterLatLong;
        if(req.body.geoLocation)
        {
          courseDetail.geoLocation = JSON.parse(req.body.geoLocation);
        }
        courseDetail.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:courseDetail.status;

          CourseDetailBusiness.update(courseDetail)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'CourseDetail Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a courseDetail
   * restriction: 'admin'
   */
  static delete(req, res) {

    CourseDetailValidator.validateUpdating(req.params).then(courseDetail => {

        CourseDetailBusiness.findOne({_id: req.params.id})
        .then(courseDetail => {

            return CourseDetailBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'CourseDetail deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  
   /**
   * Update Bulk CourseDetail
   */
  static bulkUpdate(req, res, next) {
    //TODO - update validator
    console.log('req.body--->', req.body)
        var courseDetail = JSON.parse(req.body.courseDetail);
    //var courseDetail = req.body.coursedetails;
    console.log('req.courseDetail--->', courseDetail)

    // if(courseDetail.length > 0)
    // {
          CourseDetailBusiness.bulkUpdate(courseDetail)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'CourseDetail Updated Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
    // }else{
    //   handleResponse(res, 500, 'No CourseDetail Found', [])
    // }
    }
}

module.exports = CourseDetailController;
