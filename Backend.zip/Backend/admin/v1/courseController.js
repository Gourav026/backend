'use strict';

var { CourseBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { CourseValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');
var {CourseDetailController}=require('./courseDetailController')
let {CourseDetailBusiness}=require('../../businesses')

var { UserBusiness } = require('../../businesses')

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

const validationError=(res, statusCode,message,data)=>{
  statusCode= statusCode||500;
  return res.status(statusCode)
      .send({
          statusCode:statusCode,
          message:message,
          success:false,
          response:data,
      });
}



const handleResponse=(res, statusCode,message,data)=>{
  statusCode= statusCode||500;
  return res.status(statusCode)
      .send({
          statusCode:statusCode,
          message:message,
          success:true,
          response:data,
      });
}


class CourseController {
  /**
   * Get courses
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return CourseBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Course List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  //===================== get all courseList =======================
  static courseList(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return CourseBusiness.courseList(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Course List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new course
   */
  static create(req, res, next) {

    CourseValidator.validateCreating(req.body).then( async course => {
        course.name = req.body.name;
        course.countryId = req.body.countryId;
        course.stateId = req.body.stateId;
        course.cityId = req.body.cityId;
        course.rating = req.body.rating;
        course.redYard = req.body.redYard;
        course.blueYard = req.body.blueYard;
        course.whiteYard = req.body.whiteYard;
        course.yellowYard = req.body.yellowYard;
        course.description= req.body.description;
        course.lastRecord = req.body.lastRecord;
        course.lastRecordBy = req.body.lastRecordBy;
        if(req.body.geoLocation)
        {
          course.geoLocation = JSON.parse(req.body.geoLocation);
        }
        course.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                        ) ? req.body.status:true

        CourseBusiness.create(course)
        .then((data) => {

            console.log('course Data=',data)
            console.log('course details in course=',JSON.parse( req.body.coursedetails))

            if(req.body.coursedetails)
            {
                
                let courseDetail=JSON.parse(req.body.coursedetails)

                courseDetail.map((value,index)=>{
                    let details={courseId:data._id,...value};
                    console.log("details=",details);
                    courseDetail[index]=details;
                })
                

                console.log("courseDetailUpdated=",courseDetail);
                CourseDetailBusiness.bulkUpdate(courseDetail)
                .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'CourseDetail Updated Successfully', data)
                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
            }
            if( req.files && req.files.photo)
            {
            
                data.imageType = config.imageType;

                let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
                Func(req.files.photo, data._id, 'courses', '/uploads/images/courses/', function(err, result) {
                    console.log('result',result)
                
                    if(result)
                    {
                        data.photo  = result.imageFullPath;
                        data.imageMediumPath  = result.imageMediumPath;
                        data.imageThumbPath  = result.imageThumbPath;
                    }

                    CourseBusiness.update(data)
                    .then((data) => {

                        console.log('data',data)
                        handleResponse(res, 200, 'Course Added Successfully', data)
                    })
                    .catch((err) => {
                        handleResponse(res, 500, err.message, err)
                    });
                });
            
            }else{
            
            handleResponse(res, 200, 'Course Added Successfully', data)
            }
        })
        .catch((err) => {
            console.log('err',err)
            handleResponse(res, 500, err.message, err)
        });
        //})
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }


   /**
   * Update Profile Course
   */
  static update(req, res, next) {
    //TODO - update validator
    CourseValidator.validateUpdating({...req.body, ...req.params}).then(course => {
    console.log('req.files--->', req.files)
    var courseId = req.params.id;
    CourseBusiness.findOne({_id: courseId})
      .then(course => {
        if (!course) { 
          handleResponse(res, 500, 'Course Not Exist', {}) 
        }
        course.name = req.body.name?req.body.name:course.name;
        course.countryId = req.body.countryId?req.body.countryId:course.countryId;
        course.stateId = req.body.stateId?req.body.stateId:course.stateId;
        course.cityId = req.body.cityId?req.body.cityId:course.cityId;
        course.rating = req.body.rating?req.body.rating:course.rating;
        course.lastRecord = req.body.lastRecord?req.body.lastRecord:course.lastRecord;
        course.redYard = req.body.redYard? req.body.redYard:course.redYard ;
        course.blueYard = req.body.blueYard ? req.body.blueYard:course.blueYard ;
        course.whiteYard = req.body.whiteYard ? req.body.whiteYard:course.whiteYard ;
        course.yellowYard = req.body.yellowYard? req.body.yellowYard:course.yellowYard ;
        course.lastRecordBy = req.body.lastRecordBy?req.body.lastRecordBy:course.lastRecordBy;

        if(req.body.geoLocation)
        {
          course.geoLocation = JSON.parse(req.body.geoLocation);
          console.log('req.body.geoLocation-------',JSON.parse(req.body.geoLocation));
          console.log('course.geoLocation-------',course.geoLocation);
        }

        course.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                        ) ? req.body.status:course.status;

        if( req.files && req.files.photo)
        {
          //console.log('')
            if(course.photo && course.photo!=''){
                UserBusiness.unlinkFile(course.photo)
                .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                .catch((err) => {
                    handleResponse(res, 500, err.message, err)
                });
            }

            console.log('course.imageMediumPath--',course.imageMediumPath)
            if(course.imageMediumPath && course.imageMediumPath!=''){
                UserBusiness.unlinkFile(course.imageMediumPath)
                .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
            }

            if(course.imageThumbPath && course.imageThumbPath!=''){
                UserBusiness.unlinkFile(course.imageThumbPath)
                .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
            }

            course.imageType = config.imageType;
            let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
            Func(req.files.photo, req.params.id, 'courses', '/uploads/images/courses/', function(err, result) {
            
            if(result)
            {
                course.photo  = result.imageFullPath;
                course.imageMediumPath  = result.imageMediumPath;
                course.imageThumbPath  = result.imageThumbPath;
            }
            CourseBusiness.update(course)
            .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'Course Updated Successfully', data)
            })
            .catch((err) => {
                handleResponse(res, 500, err.message, err)
            });
        })
      }else{

        CourseBusiness.update(course)
        .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'Course Updated Successfully', data)
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
      }
  })
})
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));
}

  /**
   * Deletes a course
   * restriction: 'admin'
   */
  static delete(req, res) {

    CourseValidator.validateUpdating(req.params).then(course => {

        CourseBusiness.findOne({_id: req.params.id})
        .then(course => {

            return CourseBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)

              CourseDetailBusiness.find({courseId :  req.params.id})//after deleting course all the course details must be deleted
              .then(course=>{
                return CourseDetailBusiness.deleteAll(req.params.id)
                .then((data)=>{
                  console.log('all coursedetails deleted data =',data)
                  
                })
                .catch((err) => {
                  handleResponse(res, 500, err.message, err)
                });
              })
              .catch((err) => {   
                handleResponse(res, 500, err.message, err)
              }) 

              handleResponse(res, 200, 'Course deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports = CourseController;
