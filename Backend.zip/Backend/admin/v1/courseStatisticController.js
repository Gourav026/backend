'use strict'

let {CourseStatisticBusiness} =require('../../businesses')

function validationError(res, statusCode, message, data) {
    statusCode = statusCode || 422;
    return res.status(statusCode)
    .send(
    {
    statuscode:statusCode,
    message:message,
    response:data
    }); 
}
  
function handleResponse(res, statusCode, message, data) {
    statusCode = statusCode || 500;
    return res.status(statusCode)
    .send(
        {
        statuscode:statusCode,
        message:message,
        response:data
        });
}

class CourseStatisticController{

    static mostPopularCourse(req,res){

        if(req.query.limit!='undefined'){
            req.query.limit=parseInt(req.query.limit);
        }
        if(req.query.offset!='undefined'){
			      req.query.offset = parseInt(req.query.offset);
        }
        console.log("mostpopular hitted");
        //console.log("req=",req);
        return CourseStatisticBusiness.getMostPopularCourse(req.query)
        .then((data)=>{
          handleResponse(res, 200, 'Most Popular Statistic', data)
        })
        .catch((err)=>{
            handleResponse(res,500,err.message,err);
        })

        
    }


    static mostPlayedCourse(req,res){
        if(req.query.limit!='undefined'){
            req.query.limit=parseInt(req.query.limit);
        }
        if(req.query.offset!='undefined'){
			      req.query.offset = parseInt(req.query.offset);
        }
        console.log("mostplayed course controller hitted");

        CourseStatisticBusiness.getMostPlayedCourse(req.query)
        .then((data)=>{
            handleResponse(res, 200, 'Most Played course Statistic', data)
          })
          .catch((err)=>{
              handleResponse(res,500,err.message,err);
          })
    }
}

module.exports = CourseStatisticController