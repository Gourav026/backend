'use strict';

let {HelpBusiness}=require('../../businesses');
const help = require('../../schema/api/help');
let {HelpValidator}= require('../../validators');

const validationError=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:false,
            response:data,
        });
  }
  
  
  
const handleResponse=(res, statusCode,message,data)=>{
    statusCode= statusCode||500;
    return res.status(statusCode)
        .send({
            statusCode:statusCode,
            message:message,
            success:true,
            response:data,
        });
        
}

  

class HelpController{


    //========================================get list of HELP ==========================================
    static index(req, res) {
        if(req.query.limit!='undefined'){
                req.query.limit = parseInt(req.query.limit);
            }
            if(req.query.offset!='undefined'){
                req.query.offset = parseInt(req.query.offset);
        }
        console.log('index hitted',req.query);
        
        return HelpBusiness.find(req.query)
        .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'HELP List', data)
        })
        .catch((err) => {
            handleResponse(res, 500, err.message, err)
        });
  }


    //========================================create new FAq ==========================================
    static create(req,res,next)
    {
        HelpValidator.validateCreaating(req.body).then(help=>{
            help.title=req.body.title? req.body.title: help.title;
            help.description=req.body.description? req.body.description: help.description;

            HelpBusiness.create(help).then(data=>{
                console.log('data',data)
                handleResponse(res, 200, 'Help created Successfully', data)
            })
            .catch(err=>{
                handleResponse(res, 500, err.message, err)  
            });
        })
        .catch(err=>{
            console.log("validation error==>",err);
            validationError(res,422,err.cause.details[0].message,err);
        });
    }


     /**
   * ======================================= Update HELP =====================================
   */
    static update(req, res, next) {
    //TODO - update validator
        HelpValidator.validateUpdating({...req.body, ...req.params})
        .then(help => {
            console.log('req.files--->', req.files)
            var helpId = req.params.id;
            HelpBusiness.findOne({_id: helpId})
            .then(help => {
                if (!help) {
                return handleResponse(res, 200, 'help Not Exist', data)
                }
                help.description = req.body.description?req.body.description:help.description;
                help.title = req.body.title?req.body.title:help.title;
                

                HelpBusiness.update(help)
                .then((data) => {
                    console.log('data',data)
                    handleResponse(res, 200, 'help Updated Successfully', data)
                })
                .catch((err) => {
                    handleResponse(res, 500, err.message, err)
                });
            })
        })
        .catch(err => validationError(res, 422, err.message, err));
    }

    /**
     *====================================================== Deletes a help =========================
     
     */
    static delete(req, res) {

        HelpValidator.validateUpdating(req.params).then(help => {

            HelpBusiness.findOne({_id: req.params.id})
            .then(help => {

                return HelpBusiness.delete(req.params.id)
                .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'help Deleted Successfully', data)
                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
            
                })
                .catch((err) => {
                handleResponse(res, 500, err.message, err)
                });
        }) 
        .catch(err => validationError(res, 422, err.cause.details[0].message, err));
    }

}

module.exports=HelpController;
