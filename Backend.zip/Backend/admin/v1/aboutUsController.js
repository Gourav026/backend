'use strict';


var { AboutUsBusiness } = require('../../businesses')
var { AboutUsValidator, parseJoiError } = require('../../validators')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      success:false,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        success:true,
        message:message,
        response:data
      });
}


class AboutUsController {
  /**
   * Get list of aboutUs
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);

    return AboutUsBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'AboutUs List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new aboutUs
   */
  static create(req, res, next) {

    AboutUsValidator.validateCreating(req.body).then(aboutUs => {
      aboutUs.description = req.body.description;
      aboutUs.status = ( 
                      (req.body.status === true || req.body.status == 'true') || 
                      (req.body.status === false || req.body.status == 'false') 
                    ) ? req.body.status:true
      
        AboutUsBusiness.create(aboutUs)
        .then((data) => {
          console.log('data',data)
          handleResponse(res, 200, 'AboutUs Register Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }


   /**
   * Update Profile AboutUs
   */
  static update(req, res, next) {
    //TODO - update validator
    AboutUsValidator.validateUpdating({...req.body, ...req.params}).then(aboutUs => {
    console.log('req.files--->', req.files)
    var aboutUsId = req.params.id;
    AboutUsBusiness.findOne({_id: aboutUsId})
      .then(aboutUs => {
        if (!aboutUs) {
          return handleResponse(res, 200, 'AboutUs Not Exist', data)
        }
        aboutUs.description = req.body.description?req.body.description:aboutUs.description;

        aboutUs.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:aboutUs.status;

          AboutUsBusiness.update(aboutUs)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'AboutUs Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a aboutUs
   * restriction: 'aboutUs'
   */
  static delete(req, res) {

    AboutUsValidator.validateUpdating(req.params).then(aboutUs => {

        AboutUsBusiness.findOne({_id: req.params.id})
        .then(aboutUs => {

            return AboutUsBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'AboutUs Deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));
  }

}

module.exports = AboutUsController;
