'use strict';

var express =require('express')
var passport =require('passport')
var { signToken } =require('../auth.service')
var {  UserSchema } =require('../../schema/api')
var { UserValidator, parseJoiError } = require('../../validators')
var { UserBusiness } = require('../../businesses')

var router = express.Router();

router.post('/index', function(req, res, next) {
  console.log('start hit');
 // if (req.body.type === 'user') {

    console.log('admin hit');
    UserValidator.validateLogin(req.body).then(user => {

      UserBusiness.findOne({email:user.email,role:'admin'})
      .then((data) => {

        console.log('admin businss-->',data)
          if(!data)
          {
            return res.status(401).send(
              {
                statuscode:401,
                success:false,
                message:'Admin Authentication Failed',
                response:{}
              });
          }
          data.authenticate(user.password, async function(err, isCorrect) {

            if (err ) {
              return res.status(500).send(
                {
                  statuscode:500,
                  success:false,
                  message:err.message,
                  response:err 
                });
            }

            if (!isCorrect) {
              return res.status(401).send(
                {
                  statuscode:401,
                  success:false,
                  message:'User Not Authenticated',
                  response:!isCorrect
                });
            }
    
            var token = signToken(data._id, 'admin');
            data.authToken = token

            UserBusiness.update(data)
            .then((updatedData) => {

              
                UserBusiness.findOne({_id: data._id})
                .then((user) => {

                  res.status(200)
                    .send(
                      {
                        statuscode:200,   
                        success:true,
                        message:"Login Successfully",
                        response:user
                      });
                })
                .catch( (err) => {
                  
                    res.status(401).send(
                      {
                        statuscode:401,
                        success:false,                        
                        message:err.message,
                        response:err
                      });
                })

            })
            .catch((err) => {
              res.status(401).send(
                {
                  statuscode:401,
                  success:false,
                  message:err.message,
                  response:err
                });
            });


          });
      })
      .catch((err) => {
        console.log('err',err)

        res.status(401).send(
          {
            statuscode:401,
            success:false,
            message:err.message,
            response:err
          });
      
      });

    })
    .catch((err) => 
    {
      res.status(400)
        .send({
            statuscode:401,
            success:false,
            message:err.cause.details[0].message,
            response:err
        });
    });
 // }

});


module.exports= router;
