'use strict';

var express =require('express')
var passport =require('passport')
var { signToken } =require('../auth.service')
var {  UserSchema } =require('../../schema/api')
var { UserBusiness } = require('../../businesses')
var { UserValidator, parseJoiError } = require('../../validators')
var { signToken } =require('../auth.service')
var config = require('../../config/environment')
var { Uploader } = require('../../components')

var router = express.Router();

router.post('/index', function(req, res, next) {
  console.log('start hit',req.body);

    UserValidator.validateSocialLogin(req.body).then(user => {

    let query = {"socialLogin.socialId": req.body.socialLogin.socialId}

    UserBusiness.findOne(query)
    .then( async (guser) => {

          if(!guser)
          {
            console.log(guser);

            UserBusiness.create({
              socialLogin:req.body.socialLogin,
              firstName:req.body.firstName,
              lastName:req.body.lastName,
              email:req.body.email,
              deviceId:req.body.deviceId
            })
            .then( (userSubmitted) => {

              let token = signToken(userSubmitted._id, 'guser');
              
              userSubmitted.authToken = token

              let Func = Uploader.uploadImageWithSocialMedia;
              Func(req.body.socialLogin.image, userSubmitted._id, 'users', '/uploads/images/users/', async function(err, result) {
               
                if(result)
                {
                  console.log('result------>',result);
                  userSubmitted.photo           = result.imageFullPath;
                  userSubmitted.imageMediumPath = result.imageMediumPath;
                  userSubmitted.imageThumbPath  = result.imageThumbPath;
                }
                var ObjectId = require('mongoose').Types.ObjectId;

                await UserSchema.updateOne( 
                  {_id:new ObjectId(userSubmitted._id)},
                  {
                  $set:{
                    photo:userSubmitted.photo,
                    imageMediumPath:userSubmitted.imageMediumPath,
                    imageThumbPath:userSubmitted.imageThumbPath,
                    deviceId:req.body.deviceId ? req.body.deviceId :userSubmitted.deviceId,
                  }
                })


              UserBusiness.update(userSubmitted)
              .then((updatedData) => {
  
                  UserBusiness.findOne({_id:userSubmitted._id})
                  .then( (userupdated) => {

                    res.status(200)
                      .send(
                        {
                          statuscode:200,
                          message:"user registered successfully",
                          response:userupdated
                        });

                  })
                  .catch((err) => 
                  {
                    res.status(401)
                      .send({
                          statuscode:401,
                          message:err.message,
                          response:err
                      });
                  });
              })
              .catch((err) => 
              {
                res.status(401)
                  .send({
                      statuscode:401,
                      message:err.message,
                      response:err
                  });
              });

            });
            })
            .catch((err) => 
            {
              res.status(401)
                .send({
                    statuscode:401,
                    message:err.message,
                    response:err
                });
            });
          
          }
          else{
            
          let token = signToken(guser._id, 'guser');

          guser.socialLogin= req.body.socialLogin,
          guser.firstName  = req.body.firstName,
          guser.lastName   = req.body.lastName,
          guser.deviceId   = req.body.deviceId,
          guser.email      = req.body.email,
          guser.authToken  =  token
          if(req.body.socialLogin.image != guser.socialLogin.image)
          {
          let Func =  Uploader.uploadImageWithSocialMedia;
          await Func(req.body.socialLogin.image, guser._id, 'users', '/uploads/images/users/', async function(err, result) {
           
              if(result)
              {
                console.log('result------>',result);
                guser.photo           = result.imageFullPath;
                guser.imageMediumPath = result.imageMediumPath;
                guser.imageThumbPath  = result.imageThumbPath;
              }
              var ObjectId = require('mongoose').Types.ObjectId;

              await UserSchema.updateOne( 
                {_id:new ObjectId(guser._id)},
                {
                $set:{
                  photo:guser.photo,
                  email:guser.email,
                  imageMediumPath:guser.imageMediumPath,
                  imageThumbPath:guser.imageThumbPath,
                }
              })

              UserBusiness.findOne({_id:guser._id})
              .then( (userupdated) => {

                res.status(200)
                  .send(
                    {
                      statuscode:200,
                      message:"Login Successfully",
                      response:userupdated
                    });

              })
              .catch((err) => 
              {
                res.status(401)
                  .send({
                      statuscode:401,
                      message:err.message,
                      response:err
                  });
              });
              
             
            });
          }else{
          UserBusiness.update(guser)
          .then((updatedData) => {

              UserBusiness.findOne({_id:guser._id})
              .then( (userupdated) => {

                res.status(200)
                  .send(
                    {
                      statuscode:200,
                      message:"Login Successfully",
                      response:userupdated
                    });

              })
              .catch((err) => 
              {
                res.status(401)
                  .send({
                      statuscode:401,
                      message:err.message,
                      response:err
                  });
              });
          })
          .catch((err) => 
          {
            res.status(401)
              .send({
                  statuscode:401,
                  message:err.message,
                  response:err
              });
          });
        }
      }

    })
    .catch((err) => 
    {
      res.status(401)
        .send({
            statuscode:401,
            message:err.message,
            response:err
        });
    });
  })
  .catch((err) => 
  {
    res.status(400)
      .send({
          statuscode:401,
          message:err.cause.details[0].message,
          response:err
      });
  });

});


module.exports= router;
