'use strict';
var { RoundDetailSchema, CourseDetailSchema, RoundSchema } = require('../../schema/api')
var { RoundDetailBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { RoundDetailValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')
var ObjectId = require('mongoose').Types.ObjectId;

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class RoundDetailController {
  /**
   * Get list of roundDetails
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return RoundDetailBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'RoundDetail List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new roundDetail
   */
  static create(req, res, next) {

    RoundDetailValidator.validateCreating(req.body).then( roundDetail => {
            roundDetail.roundId     = req.body.roundId;
            roundDetail.holeNumber  = req.body.holeNumber;
            roundDetail.scoreDetail = req.body.scoreDetail

            RoundDetailBusiness.findOne({
              roundId: req.body.roundId,
              holeNumber: req.body.holeNumber,
            })
            .then( async roundUpdatedDetail => {

                if(req.body.modeSelection != 'strokemode')
                {
                  //status -- E , 1UP, 2UP, 3UP
                  let resultStatus =  {
                    team        : 'A',      
                    status      : ''  
                  }
                  let previousScore = req.body.scoreDetail

                  if(roundUpdatedDetail)
                  {
                     RoundDetailBusiness.findOne({
                            roundId: req.body.roundId,
                            holeNumber: parseInt(req.body.holeNumber)-1,
                          })
                          .then(async roundPreviousDetail => {
                            let teamAScore         = previousScore.filter(team => team.team == 'A')[0].score
                            let teamBScore         = previousScore.filter(team => team.team == 'B')[0].score

                            if(previousScore.length > 2){

                              teamAScore = previousScore.filter(team => team.team == 'A')
                              teamAScore = teamAScore.reduce((min, p) => p.score < min ? p.score : min, teamAScore[0].score)
                              teamBScore = previousScore.filter(team => team.team == 'B')
                              teamBScore = teamBScore.reduce((min, p) => p.score < min ? p.score : min, teamBScore[0].score)
    
                            }

                            let previousTeam       = roundPreviousDetail.result.team
                            let previousStatus     = roundPreviousDetail.result.status
                            let rounddetail        = await RoundDetailSchema.find({roundId:req.body.roundId})
                            console.log('rounddetail--',rounddetail)

                            let filteredRoundUP    = rounddetail.filter(roundResult => roundResult.result.status == '1UP')
                            console.log('filteredRoundUP--',filteredRoundUP)
                            console.log('previousStatus--',previousStatus)

                            let initNumber = 1
                            let team = 'N/A'
                            let status = 'AS'
                            if(filteredRoundUP.length > 0)
                            {
                               team       = previousTeam
                               status     = previousStatus
                               if(status == 'AS'){
                                initNumber = 1
                               }else{
                                initNumber = parseInt(previousStatus.charAt(0)) +1
                               }
                              //  console.log('team--',team)
                              //  console.log('status--',status)
                              
                            }
                            

                        // console.log('teamAScore--->',teamAScore);
                        // console.log('teamBScore--->',teamBScore);

                            if(teamAScore > teamBScore)
                            {
                              if(previousTeam == 'A')
                              {
                                team = 'A'
                                initNumber = parseInt(previousStatus.charAt(0))-1
                              }else{
                                team = 'B'
                              }
                            //  console.log('initNumber--->',initNumber);

  
                              if(initNumber == 0){

                                resultStatus =  {
                                  team        : 'N/A',      
                                  status      : 'AS' 
                                }

                              }else{

                                resultStatus =  {
                                  team        : team,      
                                  status      : initNumber+'UP' 
                                }

                              }
                              console.log('resultStatus 1. --->',resultStatus );


                            }else if(teamAScore < teamBScore)
                            {
                              if(previousTeam == 'B')
                              {
                                team = 'B'
                                initNumber = parseInt(previousStatus.charAt(0))-1
                              }else{
                                team = 'A'
                              }

                              if(initNumber == 0){

                                resultStatus =  {
                                  team        : 'N/A',      
                                  status      : 'AS' 
                                }

                              }else{

                                resultStatus =  {
                                  team        : team,      
                                  status      : initNumber+'UP' 
                                }

                              }
                              
                            }else
                            {
                              resultStatus =  {
                                team        : team,      
                                status      : status
                              }
                            }

                            roundDetail.result = resultStatus

                            RoundDetailBusiness.create(roundDetail)
                            .then((data) => {
                              console.log('data',data)
                              handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                            })
                            .catch((err) => {
                              handleResponse(res, 500, err.message, err)
                            });                                      
                            // handleResponse(res, 200, 'RoundDetail Added Successfully', {
                            //   resultStatus:resultStatus })
                          })
                          .catch((err) => {
                            handleResponse(res, 500, err.message, err)
                          });
                                   
                  }else{
                      
                        let teamAScore = previousScore.filter(team => team.team == 'A')[0].score
                        let teamBScore = previousScore.filter(team => team.team == 'B')[0].score
                        
                        if(previousScore.length > 2){

                          teamAScore = previousScore.filter(team => team.team == 'A')
                          teamAScore = teamAScore.reduce((min, p) => p.score < min ? p.score : min, teamAScore[0].score)
                          teamBScore = previousScore.filter(team => team.team == 'B')
                          teamBScore = teamBScore.reduce((min, p) => p.score < min ? p.score : min, teamBScore[0].score)

                        }

                        console.log('teamAScore--->',teamAScore);
                        console.log('teamBScore--->',teamBScore);
                        if(teamAScore > teamBScore)
                        {
                          resultStatus =  {
                            team        : 'B',      
                            status      : 1+'UP' 
                          }
                        }else if(teamAScore < teamBScore)
                        {
                          resultStatus =  {
                            team        : 'A',      
                            status      : 1+'UP' 
                          }
                        }else
                        {
                          resultStatus =  {
                            team        : 'N/A',      
                            status      : 'AS' 
                          }
                        }

                        roundDetail.result = resultStatus

                        RoundDetailBusiness.create(roundDetail)
                      .then((data) => {
                        console.log('data',data)
                        handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                      })
                      .catch((err) => {
                        handleResponse(res, 500, err.message, err)
                      });                        
                      //handleResponse(res, 200, 'RoundDetail Added Successfully', roundDetail)
                    
                  }

                }else{
                  //status -- AS , 1UP, 2UP, 3UP
                  let resultStatus =  {
                    team        : 'A',      
                    status      : ''  
                  }
                  let previousScore = req.body.scoreDetail
                  
                  let round               = await RoundSchema.findOne({_id:new ObjectId(req.body.roundId)})
                  console.log('round--',round)
                  let coursedetail        = await CourseDetailSchema.find({courseId:round.courseId}).sort({holeNumber:1})
                  console.log('coursedetail--',coursedetail)
                  let parTotal = coursedetail.map( (crsdetail) => {
                    return crsdetail.par
                  })
                  console.log('roundUpdatedDetail-------',roundUpdatedDetail);
                  /** for stroke play */
                  if(round.startingHole != req.body.holeNumber )
                  {
                    let holeNumber = parseInt(req.body.holeNumber) - 1

                    if(round.startingHole == 10 && holeNumber == 0)
                    {
                      holeNumber = 18
                    }
                     RoundDetailBusiness.findOne({
                            roundId: req.body.roundId,
                            holeNumber: holeNumber,
                          })
                          .then(async roundPreviousDetail => {

                            let parScore           = parTotal[req.body.holeNumber-1]
                            let userScore          = previousScore[0].score
                            let previousTeam       = "N/A"
                            let previousStatus     = roundPreviousDetail.result.status
                            let rounddetail        = await RoundDetailSchema.find({roundId:req.body.roundId})
                            console.log('rounddetail--',rounddetail)

                            let sumScore = 0
                            let sumPar = 0
                            console.log('sumPar--',sumPar)
                            console.log('sumScore--',sumScore)

                            let filteredRoundUP    = rounddetail.filter(roundResult => roundResult.result.status != 'E')
                            //console.log('filteredRoundUP--',filteredRoundUP)
                            console.log('previousStatus--',previousStatus)
                            console.log('parScore--',parScore)

                            let initNumber = 0
                            let team = 'N/A'
                            let status = 'E'
                            if(filteredRoundUP.length > 0)
                            {
                               team       = previousTeam
                               status     = previousStatus
                               if(status == 'E'){
                                initNumber = 0
                               }else{
                                initNumber = parseInt(previousStatus)
                               }
                            }
                            console.log('initNumber--',initNumber)
                            console.log('parScore--',parScore)
                            console.log('userScore--',userScore)

                            if(round.startingHole == 10)
                            {
                              if(parseInt(round.startingHole)+8 == req.body.holeNumber )
                              {
                                sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                                
                                sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                            
                                roundDetail.subTotal    = { 
                                                            title:'IN',
                                                            par:sumPar,
                                                            score:sumScore,
                                                            lastHole:req.body.holeNumber
                                                          }                              
                              }
                              
                              if(parseInt(round.startingHole)-1 == req.body.holeNumber )
                              {
                                sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                                
                                sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                            
                                roundDetail.subTotal    = { 
                                                            title:'OUT',
                                                            par:sumPar,
                                                            score:sumScore,
                                                            lastHole:req.body.holeNumber
                                                          }                              
                              }
                           }else{

                            if(parseInt(round.startingHole)+8 == req.body.holeNumber )
                            {
                              sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                              
                              sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                          
                              roundDetail.subTotal    = { 
                                                          title:'OUT',
                                                          par:sumPar,
                                                          score:sumScore,
                                                          lastHole:req.body.holeNumber
                                                        }                              
                            }
                            
                            if(parseInt(round.startingHole)+17 == req.body.holeNumber )
                            {
                              sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                              
                              sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.scoreDetail[0].score; }, 0) + userScore; // 7
                                                          
                              roundDetail.subTotal    = { 
                                                          title:'IN',
                                                          par:sumPar,
                                                          score:sumScore,
                                                          lastHole:req.body.holeNumber
                                                        }                              
                            }

                           }

                              if(parScore > userScore)
                              {
                                console.log('result value 1-----',initNumber-parScore+userScore);

                                resultStatus =  {
                                  team        : 'N/A',      
                                  status      : (initNumber-parScore+userScore) != 0 ? (initNumber-parScore+userScore) >0 ? '+'+(initNumber-parScore+userScore) : (initNumber-parScore+userScore) : 'E'
                                }
                              }else if(parScore < userScore)
                              {
                                console.log('result value 2-----',initNumber-parScore+userScore);
                                resultStatus =  {
                                  team        : 'N/A',      
                                  status      : (initNumber-parScore+userScore) != 0 ? (initNumber+userScore-parScore) >0 ? '+'+(initNumber+userScore-parScore) : (initNumber+userScore-parScore) : 'E'
                                }
                              }else
                              {
                                console.log('result value 3-----',initNumber-parScore+userScore);

                                resultStatus =  {
                                  team        : 'N/A',      
                                  status      : status
                                }
                              }
                              
                            roundDetail.par    = parScore                             
                            roundDetail.result = resultStatus


                            RoundDetailBusiness.create(roundDetail)
                            .then((data) => {
                              console.log('data',data)
                              handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                            })
                            .catch((err) => {
                              handleResponse(res, 500, err.message, err)
                            });                                      
                            // handleResponse(res, 200, 'RoundDetail Added Successfully', {
                            //   resultStatus:roundDetail })
                          })
                          .catch((err) => {
                            handleResponse(res, 500, err.message, err)
                          });
                                   
                  }else{
                      
                        let parScore  = parTotal[req.body.holeNumber-1]
                        let userScore = previousScore[0].score
                     
                        console.log('parScore--->',parScore);
                        console.log('userScore--->',userScore);
                        if(parScore > userScore)
                        {
                          resultStatus =  {
                            team        : 'N/A',      
                            status      : '-'+(parScore-userScore) 
                          }
                        }else if(parScore < userScore)
                        {
                          resultStatus =  {
                            team        : 'N/A',      
                            status      : '+'+(userScore-parScore) 
                          }
                        }else
                        {
                          resultStatus =  {
                            team        : 'N/A',      
                            status      : 'E' 
                          }
                        }

                        roundDetail.result = resultStatus
                        roundDetail.par    = parScore

                        RoundDetailBusiness.create(roundDetail)
                      .then((data) => {
                        console.log('data',data)
                        handleResponse(res, 200, 'RoundDetail Added Successfully', data)
                      })
                      .catch((err) => {
                        handleResponse(res, 500, err.message, err)
                      });                        
                      //handleResponse(res, 200, 'RoundDetail Added Successfully', roundDetail)
                    
                  }
                  // handleResponse(res, 200, 'RoundDetail Added Successfully', parTotal)

                }

              //   RoundDetailBusiness.create(roundDetail)
              //  .then((data) => {
              //    console.log('data',data)
              //    handleResponse(res, 200, 'RoundDetail Added Successfully', data)
              //  })
              //  .catch((err) => {
              //    handleResponse(res, 500, err.message, err)
              //  });

              
            //   else{

            //   roundUpdatedDetail.roundId = req.body.roundId?req.body.roundId:roundUpdatedDetail.roundId;
            //   roundUpdatedDetail.holeNumber = req.body.holeNumber?req.body.holeNumber:roundUpdatedDetail.holeNumber;
            //   roundUpdatedDetail.scoreDetail = req.body.scoreDetail?req.body.scoreDetail:roundUpdatedDetail.scoreDetail;

            //   RoundDetailBusiness.update(roundUpdatedDetail)
            //   .then((data) => {
            //     console.log('data',data)
            //     handleResponse(res, 200, 'RoundDetail Updated Successfully', data)
            //   })
            //   .catch((err) => {
            //     handleResponse(res, 500, err.message, err)
            //   });
              
            // }
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }


   /**
   * Update Profile RoundDetail
   */
  static update(req, res, next) {
    //TODO - update validator
    RoundDetailValidator.validateUpdating({...req.body, ...req.params}).then(roundDetail => {
    console.log('req.files--->', req.files)
    var roundDetailId = req.params.id;
    RoundDetailBusiness.findOne({_id: roundDetailId})
      .then(roundDetail => {
        if (!roundDetail) { 
          handleResponse(res, 500, 'RoundDetail Not Exist', {}) 
        }
        roundDetail.roundId = req.body.roundId?req.body.roundId:roundDetail.roundId;
        roundDetail.holeNumber = req.body.holeNumber?req.body.holeNumber:roundDetail.holeNumber;
        roundDetail.playerId = req.body.playerId?req.body.playerId:roundDetail.playerId;
        roundDetail.playerScore = req.body.playerScore?req.body.playerScore:roundDetail.playerScore;
        
          RoundDetailBusiness.update(roundDetail)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'RoundDetail Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a roundDetail
   * restriction: 'admin'
   */
  static delete(req, res) {

    RoundDetailValidator.validateUpdating(req.params).then(roundDetail => {

        RoundDetailBusiness.findOne({_id: req.params.id})
        .then(roundDetail => {

            return RoundDetailBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'RoundDetail deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports = RoundDetailController;
