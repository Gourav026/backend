'use strict';

var { CourseBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { CourseValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class CourseController {
  /**
   * Get list of courses
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return CourseBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Course List', data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, err)
    });
  }

  /**
   * Creates a new course
   */
  static create(req, res, next) {

    CourseValidator.validateCreating(req.body).then( async course => {
        course.name = req.body.name;
        course.countryId = req.body.countryId;
        course.stateId = req.body.stateId;
        course.cityId = req.body.cityId;
        course.rating = req.body.rating;
        course.description= req.body.description;
        course.lastRecord = req.body.lastRecord;
        course.lastRecordBy = req.body.lastRecordBy;
        if(req.body.geoLocation)
        {
          course.geoLocation = JSON.parse(req.body.geoLocation);
        }
        course.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                        ) ? req.body.status:true

            CourseBusiness.create(course)
            .then((data) => {
              console.log('data',data)

              if( req.files && req.files.photo)
              {
              
                data.imageType = config.imageType;
    
                let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
                 Func(req.files.photo, data._id, 'courses', '/uploads/images/courses/', function(err, result) {
                  console.log('result',result)
                  
                  if(result)
                  {
                    data.photo  = result.imageFullPath;
                    data.imageMediumPath  = result.imageMediumPath;
                    data.imageThumbPath  = result.imageThumbPath;
                  }
    
                  CourseBusiness.update(data)
                  .then((data) => {
                    console.log('data',data)
                    handleResponse(res, 200, 'Course Added Successfully', data)
                  })
                  .catch((err) => {
                    handleResponse(res, 500, err.message, err)
                  });
                });
              
              }else{
               
              handleResponse(res, 200, 'Course Added Successfully', data)
              }
            })
            .catch((err) => {
              console.log('err',err)
              handleResponse(res, 500, err.message, err)
            });
          //})
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }


   /**
   * Update Profile Course
   */
  static update(req, res, next) {
    //TODO - update validator
    CourseValidator.validateUpdating({...req.body, ...req.params}).then(course => {
    console.log('req.files--->', req.files)
    var courseId = req.params.id;
    CourseBusiness.findOne({_id: courseId})
      .then(course => {
        if (!course) { 
          handleResponse(res, 500, 'Course Not Exist', {}) 
        }
        course.name = req.body.name?req.body.name:course.name;
        course.countryId = req.body.countryId?req.body.countryId:course.countryId;
        course.stateId = req.body.stateId?req.body.stateId:course.stateId;
        course.cityId = req.body.cityId?req.body.cityId:course.cityId;
        course.rating = req.body.rating?req.body.rating:course.rating;
        course.lastRecord = req.body.lastRecord?req.body.lastRecord:course.lastRecord;
        course.lastRecordBy = req.body.lastRecordBy?req.body.lastRecordBy:course.lastRecordBy;
        if(req.body.geoLocation)
        {
          course.geoLocation = JSON.parse(req.body.geoLocation);
        }
        course.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:course.status;

        if( req.files && req.files.photo)
        {
          //console.log('')
          if(course.photo && course.photo!=''){
              UserBusiness.unlinkFile(course.photo)
              .then( unlinkres => { console.log('unlinkres-',unlinkres)})
              .catch((err) => {
                handleResponse(res, 500, err.message, err)
              });
          }
          console.log('course.imageMediumPath--',course.imageMediumPath)
          if(course.imageMediumPath && course.imageMediumPath!=''){
            UserBusiness.unlinkFile(course.imageMediumPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          }
          if(course.imageThumbPath && course.imageThumbPath!=''){
            UserBusiness.unlinkFile(course.imageThumbPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          } 
        }
        async.waterfall([
          function(cb) { 
            if (!req.files) {
                cb();
                if (!req.files.photo) {
                cb();
                }
            }

            course.imageType = config.imageType;
            let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
            Func(req.files.photo, req.params.id, 'courses', '/uploads/images/courses/', function(err, result) {
              
              if(result)
              {
              course.photo  = result.imageFullPath;
              course.imageMediumPath  = result.imageMediumPath;
              course.imageThumbPath  = result.imageThumbPath;
              }
              cb();
            });
          }
        ], function() {
              
          CourseBusiness.update(course)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'Course Updated Successfully', data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message, err)
          });
     })
  })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }

  /**
   * Deletes a course
   * restriction: 'admin'
   */
  static delete(req, res) {

    CourseValidator.validateUpdating(req.params).then(course => {

        CourseBusiness.findOne({_id: req.params.id})
        .then(course => {

            return CourseBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'Course deleted Successfully', data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
        
            })
            .catch((err) => {   
              handleResponse(res, 500, err.message, err)
            }) 
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }
}

module.exports = CourseController;
