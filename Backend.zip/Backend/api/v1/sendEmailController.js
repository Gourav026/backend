'use strict';

var config = require('../../config/environment/index')
var mailProperty = require('../../modules/sendMail')
const AWS = require("aws-sdk");
const bodyParser = require('body-parser');

let aws = require("@aws-sdk/client-ses");

  //       accessKeyId: config.AWS.accessKeyId,
  //       secretAccessKey: config.AWS.secretAccessKey,
// configure AWS SDK
process.env.AWS_ACCESS_KEY_ID = config.AWS.accessKeyId;
process.env.AWS_SECRET_ACCESS_KEY = config.AWS.secretAccessKey;

const nodemailer = require('nodemailer');

function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      response:data
    });
}

function handleResponse(res, statusCode, message, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        response:data
      });
}


class sendEmailController {

  /**
   * Send Email
   */
  static sendEmail(req, res, next) {

    console.log(req.body);
    console.log('config.AWS.accessKeyId----',config.AWS.accessKeyId)
    console.log('config.AWS.secretAccessKey----',config.AWS.secretAccessKey)
    console.log('config.AWS.region----',config.AWS.region)
    console.log('req.body.email----',req.body.email)
    console.log('config.AWS.SenderEmailId----',config.AWS.SenderEmailId)
    let promise = new Promise((resolve,reject) => {
      
      resolve( mailProperty('emailVerificationMail')(req.body.email, {
          name: req.body.fullName,
          email: req.body.email,
          verification_code: 123,
          site_url: config.liveUrl,
          date: new Date()
        }).send());

        })

        promise.then(data => {
            console.log("email submitted to SES", data);
            res.status(200).send({
                message:'Message send successfully !'
            })
        }).catch(error => {
            console.log(error);
            res.status(404).send({
                message:'Failed to send !'
            })
        });

  //   AWS.config.update({
  //       accessKeyId: config.AWS.accessKeyId,
  //       secretAccessKey: config.AWS.secretAccessKey,
  //       region: config.AWS.region
  //   });
    
  //   const ses = new AWS.SES({ apiVersion: "2010-12-01" });
  //   const params = {
  //     Destination: {
  //       ToAddresses: [req.body.email] // Email address/addresses that you want to send your email
  //     },
  //     Message: {
  //       Body: {
  //         Html: {
  //           // HTML Format of the email
  //           Data:
  //             "Thank you for reaching out"
  //         },
  //         Text: {
  //           Data: "Thanks for reaching out"
  //         }
  //       },
  //       Subject: {
  //         Data: "Thanks for reaching out"
  //       }
  //     },
  //     Source: config.AWS.SenderEmailId
  //   };

  //   //For Sender
  //   const params1 = {
  //     Destination: {
  //        ToAddresses: [config.AWS.SenderEmailId] // Email address/addresses that you want to send your email
  //     },
  //     Message: {
  //       Body: {
  //         Html: {
  //           Data: "Name: "+req.body.name+"Email: "+req.body.email+"Message: "+req.body.message+""
  //         }, 
  //         Text: {
  //          Data: "This is the feedback message from user"
  //         }
  //       },
  //       Subject: {
  //        Data: "Feedback from "+req.body.name
  //       }
  //    },
  //    Source: config.AWS.SenderEmailId
  //  };

  //   const sendEmailReceiver = ses.sendEmail(params).promise();
  //   const sendEmailSender = ses.sendEmail(params1).promise();
    
  //   sendEmailReceiver
  //     .then(data => {
  //       console.log("email submitted to SES", data);
  //       sendEmailSender.then(data => {
  //           console.log("email submitted to SES", data);
  //           res.status(200).send({
  //               message:'Message send successfully !'
  //           })
  //       }).catch(error => {
  //           console.log(error);
  //           res.status(404).send({
  //               message:'Failed to send !'
  //           })
  //       });
  //     })
  //     .catch(error => {
  //       console.log(error);
  //       res.status(404).send({
  //           message:'Failed to send !'
  //       })
  //   });
   }

}

module.exports = sendEmailController;
