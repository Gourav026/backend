'use strict';


var { UserSchema } = require('../../schema/api')
var { UserBusiness } = require('../../businesses')
var { S3, GM, Mailer, Uploader } = require('../../components')
var { UserValidator, parseJoiError } = require('../../validators')
var mailProperty = require('../../modules/sendMail');

var Helper = require('../../helpers')
var config = require('../../config/environment')
var jwt = require('jsonwebtoken')
var async = require('async')
var _ = require('lodash')


function validationError(res, statusCode, message, data) {
  statusCode = statusCode || 422;
  return res.status(statusCode)
  .send(
    {
      statuscode:statusCode,
      message:message,
      success:false,
      response:data
    });
}

function handleResponse(res, statusCode, message, isSuccess, data) {
  statusCode = statusCode || 500;
  return res.status(statusCode)
    .send(
      {
        statuscode:statusCode,
        message:message,
        success:isSuccess,
        response:data
      });
}


class UserController {
  /**
   * Get list of users
   */
  static index(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('index hitted',req.query);
    
    return UserBusiness.find(req.query)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'User List', true, data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message, false, err)
    });
  }

  
  /**
   * Get list of users
   */
  static verifyauth(req, res) {
    if(req.query.limit!='undefined'){
			req.query.limit = parseInt(req.query.limit);
		}
		if(req.query.offset!='undefined'){
			req.query.offset = parseInt(req.query.offset);
    }
    console.log('verifyAuth hitted',req.query);
    
    return UserBusiness.verifyAuth(req.headers)
    .then((data) => {
      console.log('data',data)
      handleResponse(res, 200, 'Token Verified Successfully',true, data)
    })
    .catch((err) => {
      handleResponse(res, 500, err.message,false, err)
    });
  }
  
  /**
   * Creates a new user
   */
  static create(req, res, next) {

    UserValidator.validateCreating(req.body).then(user => {
      user.firstName = req.body.firstName || 'Unknown';
      user.lastName = req.body.lastName ;
      user.email = req.body.email;
      user.contactNumber = req.body.contactNumber;
      user.countryId = req.body.countryId;
      user.stateId = req.body.stateId;
      user.cityId = req.body.cityId;
      user.emailVerify = req.body.emailVerify || true;
      user.geoLocation=req.body.geoLocation?req.body.geoLocation:[];
      user.status = ( 
                      (req.body.status === true || req.body.status == 'true') || 
                      (req.body.status === false || req.body.status == 'false') 
                    ) ? req.body.status:true
      if (req.user && req.user.role === 'admin') {
        user.role = req.body.role;
      }

      if(req.body.password!='' && typeof req.body.password !='undefined'){
        user.password = req.body.password;
      }

      user.emailVerifiedToken = Helper.StringHelper.randomString(48);
             
        UserBusiness.create(user)
        .then((data) => {
          
          console.log('data',data)
                 
          // let Func =  Uploader.uploadImageWithAvatar;
          // let Payload = {firstName:data.firstName,lastName:data.lastName};

          //  Func(Payload, data._id, 'users', '/uploads/images/users/', function(err, result) {
          //   console.log('result',result)
            
          //   if(result)
          //   {
          //     data.photo  = result.imageFullPath;
          //     data.imageMediumPath  = result.imageMediumPath;
          //     data.imageThumbPath  = result.imageThumbPath;
          //   }

            UserBusiness.update(data)
            .then((data) => {
              console.log('data',data)
              mailProperty('signupVerification')(data.email, {
                name                    : `${data.firstName} ${data.lastName}`,
                email                   : data.email,
                account_verify_link    : config.liveUrl+'accountVerify/'+data._id+'/'+data.emailVerifiedToken,
                site_url                : config.liveUrl,
                date                    : new Date()
              }).send();
              handleResponse(res, 200, 'User Register Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 200, err.message, false, err)
            });
          //});
         // handleResponse(res, 200, 'User Register Successfully', data)
        })
        .catch((err) => {
          handleResponse(res, 500, err.message,false, err)
        });
    })
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }


   /**
   * Update Profile User
   */
  static update(req, res, next) {
    //TODO - update validator
    UserValidator.validateUpdating({...req.body, ...req.params}).then(user => {
    console.log('req.files--->', req.files)
    console.log('req.body--->', req.body)
    var userId = req.params.id;
    UserBusiness.findOne({_id: userId})
      .then(user => {
        if (!user) {
          return handleResponse(res, 200, 'User Not Exist',true, user)
        }
        user.firstName = req.body.firstName?req.body.firstName:user.firstName;
        user.lastName = req.body.lastName?req.body.lastName:user.lastName;
        user.email = req.body.email?req.body.email:user.email;
        user.contactNumber = req.body.contactNumber?req.body.contactNumber:user.contactNumber;
        user.countryId = req.body.countryId;
        user.stateId = req.body.stateId;
        user.cityId = req.body.cityId;
        user.geoLocation=req.body.geoLocation?req.body.geoLocation:user.geoLocation;
        user.status = ( 
                        (req.body.status === true || req.body.status == 'true') || 
                        (req.body.status === false || req.body.status == 'false') 
                      ) ? req.body.status:user.status;

        if(req.body.setting!='' && typeof req.body.setting !='undefined'){

          let setting = JSON.parse(req.body.setting)
          console.log('setting--',setting, setting.onScreenNotification);
          if(setting.onScreenNotification === false || setting.onScreenNotification === true){
            console.log('setting onScreenNotification--', setting.onScreenNotification);

            user.setting.onScreenNotification = setting.onScreenNotification;
          }
          
          if(setting.inAppNotification === false || setting.inAppNotification === true){
            console.log('setting inAppNotification--', setting.inAppNotification);
            user.setting.inAppNotification = setting.inAppNotification;
          }

        }                      
        if(req.body.password!='' && typeof req.body.password !='undefined'){
          user.password = req.body.password;
        }
        if(req.body.handicap!='' && typeof req.body.handicap !='undefined'){
          user.handicap = req.body.handicap;
        }
        if(req.body.nickName!='' && typeof req.body.nickName !='undefined'){
          user.nickName = req.body.nickName;
        }
        
        if(typeof req.body.emailVerifiedToken !='undefined'){
          user.emailVerifiedToken = req.body.emailVerifiedToken;
        }

        user.role = req.body.role?req.body.role:user.role;
        user.emailVerify = ( 
                              (req.body.emailVerify === true || req.body.emailVerify == 'true') || 
                              (req.body.emailVerify === false || req.body.emailVerify == 'false') 
                            ) ? req.body.emailVerify:user.emailVerify;
 
        let definedFriendList    = user.friendList ? user.friendList : []
            
        if(req.body.friendId != '' && req.body.friendId && !user.friendList.includes(req.body.friendId))
        {
          
            let unFriendIndex = user.unFriendList.indexOf(req.body.friendId);
            if (unFriendIndex !== -1) {
              user.unFriendList.splice(unFriendIndex, 1);
            }

            user.friendList = user.unFriendList
            
            definedFriendList.push(req.body.friendId)
            user.friendList = definedFriendList
        }
          
        let definedUnFriendList    = user.unFriendList ? user.unFriendList : []
            
        if(req.body.unFriendId != '' && req.body.unFriendId && !user.unFriendList.includes(req.body.unFriendId))
        {
          
            let friendIndex = user.friendList.indexOf(req.body.unFriendId);
            if (friendIndex !== -1) {
              user.friendList.splice(friendIndex, 1);
            }

            user.unFriendList = user.friendList

            definedUnFriendList.push(req.body.unFriendId)
            user.unFriendList = definedUnFriendList
        }

        if( req.files && req.files.photo)
        {
          console.log('')
         if(user.photo && user.photo!=''){
              UserBusiness.unlinkFile(user.photo)
              .then( unlinkres => { console.log('unlinkres-',unlinkres)})
              .catch((err) => {
                handleResponse(res, 500, err.message,false, err)
              });
          }

          console.log('user.imageMediumPath--',user.imageMediumPath)

          if(user.imageMediumPath && user.imageMediumPath!=''){
            UserBusiness.unlinkFile(user.imageMediumPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });
          }

          if(user.imageThumbPath && user.imageThumbPath!=''){
            UserBusiness.unlinkFile(user.imageThumbPath)
            .then( unlinkres => { console.log('unlinkres-',unlinkres)})
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });
          }
          
          user.imageType = config.imageType;
          let Func = config.imageType == 's3' ? Uploader.uploadImageWithThumbnailsToS3 : Uploader.uploadImageWithThumbnails;
          Func(req.files.photo, req.user._id, 'users', '/uploads/images/users/', function(err, result) {
           
            if(result)
            {
            user.photo  = result.imageFullPath;
            user.imageMediumPath  = result.imageMediumPath;
            user.imageThumbPath  = result.imageThumbPath;

            UserBusiness.update(user)
            .then((data) => {
              console.log('data',data)
             // handleResponse(res, 200, 'User Updated Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });

            }
          });

          UserBusiness.update(user)
          .then((data) => {
            console.log('data',data)
            handleResponse(res, 200, 'User Updated Successfully',true, data)
          })
          .catch((err) => {
            handleResponse(res, 500, err.message,false, err)
          });
          

        }else{
          if(user.photo){
            console.log('updated user---',user);
            UserBusiness.update(user)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'User Updated Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });

          }else{
            let Func = Uploader.uploadImageWithAvatar;
            Func({firstName:user.firstName,lastName:user.lastName}, user._id, 'users', '/uploads/images/users/', function(err, result) {
             console.log('result------>',result)
              if(result)
              {
                user.photo  = result.imageFullPath;
                user.imageMediumPath  = result.imageMediumPath;
                user.imageThumbPath  = result.imageThumbPath;
              }
              UserBusiness.update(user)
              .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'User Updated Successfully',true, data)
              })
              .catch((err) => {
                handleResponse(res, 500, err.message,false, err)
              });
            });
          }


        }
         
    })
  })
  .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }

  /**
   * Deletes a user
   * restriction: 'admin'
   */
  static delete(req, res) {

    UserValidator.validateUpdating(req.params).then(user => {

        UserBusiness.findOne({_id: req.params.id})
        .then(user => {

            return UserBusiness.delete(req.params.id)
            .then((data) => {
              console.log('data',data)
              handleResponse(res, 200, 'User Deleted Successfully',true, data)
            })
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));


  }

  /**
   * DeleteAll user
   * restriction: 'admin'
   */
  static deleteAll(req, res) {

    if(process.env.PORT == '3004')
    {
    UserSchema.find({})
    .then(async users => {
      console.log('users--',users);
                  
            const promises = users.map(async user => {
            
                  if(user.photo && user.photo!=''){
                   await UserBusiness.unlinkFile(user.photo)
                    
                    }

                    console.log('user.imageMediumPath--',user.imageMediumPath)

                    if(user.imageMediumPath && user.imageMediumPath!=''){
                      await UserBusiness.unlinkFile(user.imageMediumPath)
                      
                    }

                    if(user.imageThumbPath && user.imageThumbPath!=''){
                     await UserBusiness.unlinkFile(user.imageThumbPath)
                      
                    }
                    return user
              });

              const removedUsers = await Promise.all(promises);

              const removedUser = await UserSchema.deleteMany({})  // return Query;

                
              return UserBusiness.find({})
              .then((data) => {
                console.log('data',data)
                handleResponse(res, 200, 'Users Deleted Successfully',true, data)
              })
              .catch((err) => {
                handleResponse(res, 500, err.message,false, err)
              });
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message, err)
            });
          }else{
            handleResponse(res, 500, 'Not Authorized',false, {})

          }
}


  /**
   * Change Password of a user
   */
  static changePassword(req, res) {

    UserValidator.validateChangePassword(req.body).then(user => {
      let ObjectId = require('mongoose').Types.ObjectId;
      console.log('req.body._id---',req.body._id);

      UserBusiness.findOne({_id: new ObjectId(req.body._id)})
        .then(data => {
              console.log('data--------',data);
              if(data)
              {
              data.authenticate(req.body.currentPassword, async function(err, isCorrect) {

                if (err || !isCorrect) {
                  
                  handleResponse(res, 200, 'Incorrect Current Password',false, {})

                }else{

                UserBusiness.forgotPassword({_id:data._id}, req.body.password)
                .then((updatedData) => {
                      console.log('updatedData--',updatedData);          
                      mailProperty('forgotPasswordResponse')(data.email, {
                        name                    : `${data.firstName} ${data.lastName}`,
                        email                   : data.email,
                        password : req.body.password,
                        date                    : new Date()
                      }).send();

                      handleResponse(res, 200, 'User Password Changed Successfully',true, updatedData)
                    })  
                    .catch((err) => 
                    {
                      handleResponse(res, 500, err.message,false, err)
                    });
                  }

              });  
            }else{
              handleResponse(res, 200, "User Doesn't Exist",false, {})

            }        


            // return UserBusiness.changePassword(req.params.id)
            // .then((data) => {
            //   console.log('data',data)
            //   handleResponse(res, 200, 'User Password Changed Successfully', data)
            // })
            // .catch((err) => {
            //   handleResponse(res, 500, err.message, err)
            // });
           // handleResponse(res, 200, 'User Password Changed Successfully', user)
        
            })
            .catch((err) => {
              handleResponse(res, 500, err.message,false, err)
            });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }


  /**
   * Forget Password of a user
   */
  static forgetPasswordMailVerification(req, res) {

    UserValidator.validateSendEmailVerification(req.body).then(user => {
      let ObjectId = require('mongoose').Types.ObjectId;
      console.log('req.body.email---',req.body.email);

      UserBusiness.findOne({email: req.body.email})
        .then(user => {
              console.log('user--------',user);
              if(user)
              {

                user.emailVerifiedToken = Helper.StringHelper.randomString(48);

                mailProperty('forgotPasswordMail')(user.email, {
                            name                    : `${user.firstName} ${user.lastName}`,
                            email                   : user.email,
                            reset_password_link     : config.liveUrl+'resetPassword/'+user._id+'/'+user.emailVerifiedToken,
                            site_url                : config.liveUrl,
                            date                    : new Date()
                }).send();
          

                UserBusiness.update(user)
                .then((data) => {
                  console.log('data',data)
                  handleResponse(res, 200, 'Mail Sent  Successfully. Please Check Your Registered Email',true, data)
                })
                .catch((err) => {
                  handleResponse(res, 500, err.message,false, err)
                });

              }else{
                handleResponse(res, 200, "User Doesn't Exist",false, {})

              }        
              })
              .catch((err) => {
                handleResponse(res, 500, err.message,false, err)
              });
    }) 
    .catch(err => validationError(res, 422, err.cause.details[0].message, err));

  }


}

module.exports = UserController;
