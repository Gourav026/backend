var { RoundDetailSchema } =require('../schema/api')
var fs = require('fs');
const { resolve } = require('bluebird');

class RoundDetailBusiness {
  /**
   * create a new roundDetail
   * @param  {Object} data roundDetail data
   * @return {Promise}
   */
  static create(data) {
    var newRoundDetail = new RoundDetailSchema(data);
    return newRoundDetail.save().then((roundDetail) => {
      //fire event to another sides
    console.log('roundDetail--->',roundDetail)
    return roundDetail
    });
  }



  /**
   * update roundDetail
   * @param  {Object} Mongoose roundDetail object
   * @return {Promise}
   */
  static update(roundDetail) {
    return roundDetail.save().then((updated) => {
     return updated
    });
  }

  /**
   * Update all data by query
   * @param  {Object} data roundDetail data
   * @return {Promise}
   */
  static updateByQuery(params) {
    //TODO - code me
    let promise = new Promise((resolve, reject) => {
      resolve(true);
    });

    return Promise;
  }

  /**
   * find list of roundDetails
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 18;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    
    if(params.holeNumber){
      condition.holeNumber = parseInt(params.holeNumber) ;
    }

    if(params.playerId){
      condition.playerId = new ObjectId(params.playerId) ;
    }

    if(params.roundId){
      condition.roundId = new ObjectId(params.roundId);
    }

    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page;
      }

     if(params.skip){
        skip =   params.skip;
      }
       console.log('limit',limit)
       var aggregate = RoundDetailSchema.aggregate([
          {
              $match: condition
          },
          
          { 
              $lookup : {
                  from : 'rounds',
                  localField : 'roundId',
                  foreignField : '_id',
                  as : 'roundId'
              }
          },
          {
              $unwind : { path : '$roundId', preserveNullAndEmptyArrays : true } 
          },
          { 
            $lookup : {
                from : 'users',
                localField : 'scoreDetail.playerId',
                foreignField : '_id',
                as : 'playerId'
            }
        },
        {
            $unwind : { path : '$playerId', preserveNullAndEmptyArrays : true } 
        },
        {
            $project : {
                holeNumber : 1,
                par:1,
                si:1,
                location:1,
                roundId:1,
                subTotal:1,
                playerScore:1,
                scoreDetail:1,
                geoLocation:1,
                result:1,
                updatedAt:1
            }
        }, 
        {
            $group : {              
                _id :"$_id",
                roundId : {
                  "$first": "$roundId"
                },
                holeNumber : {
                    "$first": "$holeNumber"
                },
                par : {
                    "$first": "$par"
                },
                si : {
                    "$first": "$si"
                },
                location : {
                    "$first": "$location"
                },
                geoLocation : {
                    "$first": "$geoLocation"
                },
                subTotal : {
                    "$first": "$subTotal"
                },
                scoreDetail : {
                    "$first": "$scoreDetail"
                },
                result : {
                    "$first": "$result"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                holeNumber : 1,
                roundId : 1,
                par:1,
                si:1,
                location:1,
                geoLocation:1,
                subTotal:1,
                scoreDetail: 1,
                result: 1,
                updatedAt:1
            }
        }, 
        {
            $sort: {holeNumber: 1}
        },
        { 
            '$facet'    : {
            metadata: [
               { $count: "total" },
               { $addFields: { page: page, latestHoleNumber: { $add: [   "$total" , 1 ] } } },
              
               ],
            
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ], // add projection here wish you re-shape the docs

            subTotal:[
              { $unwind: "$scoreDetail" },
              {
                
                $group:{
                  _id:{
                    _id:"$scoreDetail.playerId",
                    holeNumber:{$lte:["$holeNumber",9]}
                  },
                  par:{
                    $sum:"$par"
                  },
                  // scoreDetail:{
                  //   "$addToSet":"$scoreDetail"
                  // },
                  score:{
                    $sum:"$scoreDetail.score"
                  }
                  
                },
                
              },
              
              {
                $project:{
                  _id:1,
                  //scoreDetail:1,
                  par:1,
                  score:1,
                  lastHole:{ 

                    $cond: {
                      if: { $gte: [ "$_id.holeNumber", true ] },
                       then: 9,
                       else: 18
                     }
                  },
                  title:{ 

                    $cond: {
                      if: { $gte: [ "$_id.holeNumber", true ] },
                       then: "OUT",
                       else: "IN"
                     }
                  }
                }
              }
            ],
            total:[
              { $unwind: "$scoreDetail" },
              {
                
                $group:{
                  _id:"$scoreDetail.playerId",
                  
                  par:{
                    $sum:"$par"
                  },
                  
                  score:{
                    $sum:"$scoreDetail.score"
                  }
                  
                },
                
              },
              
              
            ],
            resource: [
                      { 
                          $lookup : {
                              from : 'users',
                              localField : 'scoreDetail.playerId',
                              foreignField : '_id',
                              as : 'userId'
                          }
                      },
                      {
                          $unwind : { path : '$userId', preserveNullAndEmptyArrays : true } 
                      },
                      { 
                          $lookup : {
                              from : 'courses',
                              localField : 'roundId.courseId',
                              foreignField : '_id',
                              as : 'courseId'
                          }
                      },
                      {
                          $unwind : { path : '$courseId', preserveNullAndEmptyArrays : true } 
                      },

                      {
                          $project : {
                              _id : 1,
                              subTotal:1,
                              score:"$findSum.score", 
                              roundName:"$roundId.name",
                              lastUpdatedHole:"$roundId.lastUpdatedHole",
                              userId: {
                                _id:"$userId._id",
                                firstName:"$userId.firstName",
                                lastName:"$userId.lastName",
                                photo:"$userId.photo"
                              },
                              courseId:{
                                _id:"$courseId._id",
                                name:"$courseId.name",
                                description:"$courseId.description"
                              },
                              //latestHole: { $count: "total" }

                          }
                      },
                      {
                          $group : {              
                              _id :"$scoreDetail.playerId",
                              userId : {
                                "$addToSet": "$userId"
                             },
                             courseId : {
                              "$first": "$courseId"
                             },
                             score : {
                              "$first": "$score"
                             },
                             roundName : {
                              "$first": "$roundName"
                             },
                             lastUpdatedHole : {
                              "$first": "$lastUpdatedHole"
                             },
                             subTotal : {
                              "$addToSet": "$subTotal"
                           },
                          }
                      },
                      {
                        $addFields: {
                          total:{
                            parTotal: { $sum: "$subTotal.par" } ,
                            scoreTotal: { $sum: "$subTotal.score" } 
                          }
                        }
                      },
                      {
                          $project : {
                              _id : 1,
                              roundName: 1,
                              lastUpdatedHole: 1,
                              userId: 1,
                              courseId: 1,
                              subTotal:1,
                              total:1,
                              score:1
                          }
                      }
                    ]
          } 
        }
    ]

    ).exec()

    return aggregate
  }
  /**
   * find single record by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static findOne(params) {    
    return RoundDetailSchema.findOne(params).exec();
  }


  /**
   * delete account & fire delete event
   * @param  {String} id
   * @return {Promise}
   */
  static delete(id) {
    return RoundDetailSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }

    /**
   * enter score details by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static getPlayerScoreStatus(params) { 

        let promise =  new Promise( (resolve,reject) => { 

        let roundDetail = params.roundDetail

        let resultStatus =  {
          team        : 'A',      
          status      : null
        }

       let totalRounddetail =  params.totalRoundDetail.map( val => 
          { 
            //let validPlayers = val.scoreDetail.filter( score.isEditable !=false)

            let filterVal = val.scoreDetail.filter( score => score.score !=null && score.isEditable !=false)
            return filterVal 
          }).filter( rdetail => rdetail !='')
        
          console.log('totalRoundDetail--',totalRounddetail) 

        let parScore  = params.parTotal[params.holeNumber-1]
        let filterVal = params.previousScore.filter( score => score.isEditable !=false)
       // console.log('totalRoundDetail--',totalRounddetail) 

        if(filterVal.length == 2){

         // filterVal.map( async (prevScore, i) => {  
        for (let index = 0; index < filterVal.length; index++) {
          const prevScore = filterVal[index];

           // console.log('prevScore--',prevScore, i);
            let userScore = prevScore.score
          
           // console.log('parScore--->',parScore);
            console.log('userScore--->',userScore);
            if(filterVal[index].score > filterVal[index+1].score)
            {
              resultStatus =  {     
                status      : '-'+(filterVal[index].score-filterVal[index+1].score) 
              }
            }else if(filterVal[index].score < filterVal[index+1].score)
            {
              resultStatus =  { 
                status      : '+'+(filterVal[index+1].score-filterVal[index].score) 
              }
            }else
            {
              resultStatus =  { 
                status      : 'E' 
              }
            }
    
            resolve(resultStatus)
            }

        }else{
          filterVal.map( async (prevScore, i) => {  
        
            console.log('prevScore--',prevScore, i);
            let userScore = prevScore.score
          
            console.log('parScore--->',parScore);
            console.log('userScore--->',userScore);
            if(parScore > userScore)
            {
              resultStatus =  {     
                status      : '-'+(parScore-userScore) 
              }
            }else if(parScore < userScore)
            {
              resultStatus =  { 
                status      : '+'+(userScore-parScore) 
              }
            }else
            {
              resultStatus =  { 
                status      : 'E' 
              }
            }
    
            resolve(resultStatus)
            })
        }

    })

    return promise
  
  }

      /**
   * enter score details by params
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static enterScoreNext(params) { 

    let promise =  new Promise( async (resolve,reject) => { 

    let roundDetail = params.roundDetail
    roundDetail.scoreDetail= []

    let resultStatus =  {
      team        : 'A',      
      status      : ''  
    }
    if(params.round.startingHole != params.holeNumber )
    {
        let holeNumber = parseInt(params.holeNumber) - 1

        if(params.round.startingHole == 10 && holeNumber == 0)
        {
          holeNumber = 18
        }
        // let roundPreviousDetail = await 
         RoundDetailSchema.findOne({
              roundId: params.roundId,
              holeNumber: holeNumber,
            }).then( async(roundPreviousDetail)=> { 

             console.log('roundPreviousDetail--',roundPreviousDetail)
             if(roundPreviousDetail)
             {
              let loopPromise = await params.previousScore.map( async (prevScore, i) => {  

                let parScore           = params.parTotal[params.holeNumber-1]
                let siScore            = params.siTotal[params.holeNumber-1]

                let userScore          = prevScore.score
                let previousTeam       = "N/A"
                let getPlayerId        = params.previousScore.findIndex( rpd => rpd.playerId == prevScore.playerId)
                 console.log('getPlayerId--',getPlayerId);
                let previousStatus     = roundPreviousDetail.scoreDetail.map( (rpd) => {
                  if(rpd.playerId == prevScore.playerId)
                  {
                    return rpd.result.status
                  }
                })
                console.log('previousStatus 1--',previousStatus)

                previousStatus = previousStatus.filter(ps => ps != null)[0]
                console.log('previousStatus 2--',previousStatus)
               
                let rounddetail        = await RoundDetailSchema.find({roundId:params.roundId})
               // console.log('rounddetail--',rounddetail)

                let sumScore = 0
                let sumPar = 0
                let sumSI = 0
                // console.log('sumPar--',sumPar)
                // console.log('sumScore--',sumScore)

                let filteredRound    = rounddetail.map((round1) => {
               
                 return round1.scoreDetail.map( (rpd) => {
                    console.log('rpd--',rpd)
                    if(rpd.playerId == prevScore.playerId)
                    {
                      return rpd.result.status
                    }
                  })
                })
                console.log('filteredRound--',filteredRound)
               // let filteredRoundUP    = filteredRound[1].filter(roundResult => roundResult != 'E')
               // console.log('filteredRoundUP--',filteredRoundUP)
               // console.log('previousStatus--',previousStatus)
                console.log('parScore--',parScore)

                let initNumber = 0
                let team = 'N/A'
                let status = 'E'
                // if(filteredRoundUP.length > 0)
                // {
                //   team       = previousTeam
                //   status     = previousStatus
                //   if(status == 'E'){
                //     initNumber = 0
                //   }else{
                //     initNumber = parseInt(previousStatus)
                //   }
                // }
                //console.log('initNumber--',initNumber)
                console.log('parScore--',parScore)
                console.log('userScore--',userScore)

                if(params.round.startingHole == 10)
                {
                  if(parseInt(params.round.startingHole)+8 == params.holeNumber )
                  {
                    sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                    sumSI  = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + siScore;
                    
                    sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[getPlayerId].score; }, 0) + userScore; // 7
                                                
                    prevScore.subTotal    = { 
                                                title:'IN',
                                                par:sumPar,
                                                si:sumSI,
                                                score:sumScore,
                                                lastHole:params.holeNumber
                                              }                              
                  }
                  
                  if(parseInt(params.round.startingHole)-1 == params.holeNumber )
                  {
                    sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                    sumSI  = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.si; }, 0) + siScore;
                    
                    sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 0 && roundResult.holeNumber <9).reduce(function (acc, obj) { return acc + obj.scoreDetail[getPlayerId].score; }, 0) + userScore; // 7
                                                
                    prevScore.subTotal    = { 
                                                title:'OUT',
                                                par:sumPar,
                                                si:sumSI,
                                                score:sumScore,
                                                lastHole:params.holeNumber
                                              }                              
                  }
              }else{

                if(parseInt(params.round.startingHole)+8 == params.holeNumber )
                {
                  sumPar = rounddetail.reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                  sumSI = rounddetail.reduce(function (acc, obj) { return acc + obj.si; }, 0) + siScore;
                  
                  sumScore = rounddetail.reduce(function (acc, obj) { return acc + obj.scoreDetail[getPlayerId].score; }, 0) + userScore; // 7
                                              
                  prevScore.subTotal    = { 
                                              title:'OUT',
                                              par:sumPar,
                                              si:sumSI,
                                              score:sumScore,
                                              lastHole:params.holeNumber
                                            }                              
                }
                
                if(parseInt(params.round.startingHole)+17 == params.holeNumber )
                {
                  sumPar = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.par; }, 0) + parScore;
                  
                  sumSI = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.si; }, 0) + siScore;
                  
                  sumScore = rounddetail.filter(roundResult => roundResult.holeNumber > 9 && roundResult.holeNumber <18).reduce(function (acc, obj) { return acc + obj.scoreDetail[getPlayerId].score; }, 0) + userScore; // 7
                                              
                  prevScore.subTotal    = { 
                                              title:'IN',
                                              par:sumPar,
                                              si:sumSI,
                                              score:sumScore,
                                              lastHole:params.holeNumber
                                            }                              
                }

              }

                  if(parScore > userScore)
                  {
                    console.log('result value 1-----',initNumber-parScore+userScore);

                    resultStatus =  {   
                      status      : (initNumber-parScore+userScore) != 0 ? (initNumber-parScore+userScore) >0 ? '+'+(initNumber-parScore+userScore) : (initNumber-parScore+userScore) : 'E'
                    }
                  }else if(parScore < userScore)
                  {
                    console.log('result value 2-----',initNumber-parScore+userScore);
                    resultStatus =  {      
                      status      : (initNumber-parScore+userScore) != 0 ? (initNumber+userScore-parScore) >0 ? '+'+(initNumber+userScore-parScore) : (initNumber+userScore-parScore) : 'E'
                    }
                  }else
                  {
                    console.log('result value 3-----',initNumber-parScore+userScore);

                    resultStatus =  {    
                      status      : status
                    }
                  }
                  
                roundDetail.par    = parScore   
                roundDetail.si     = siScore
                // prevScore.result = resultStatus
                console.log('prevScore-->',prevScore);
                roundDetail.scoreDetail.push(prevScore)
                console.log('roundDetail.scoreDetail-->',roundDetail.scoreDetail);
                return roundDetail
              })
              
              const promiseval = await Promise.all(loopPromise);
              console.log('promiseval----->',promiseval);
              resolve(promiseval[0])
            }else{
              reject('Please check the hole Number')
            }
            })
            
    }else{
                
      let parScore  = params.parTotal[params.holeNumber-1]
      let siScore   = params.siTotal[params.holeNumber-1]
      params.previousScore.map( async (prevScore, i) => {  
      
      console.log('prevScore--',prevScore, i);
      let userScore = prevScore.score
    
      console.log('parScore--->',parScore);
      console.log('siScore--->',siScore);
      console.log('userScore--->',userScore);
      if(parScore > userScore)
      {
        resultStatus =  {     
          status      : '-'+(parScore-userScore) 
        }
      }else if(parScore < userScore)
      {
        resultStatus =  { 
          status      : '+'+(userScore-parScore) 
        }
      }else
      {
        resultStatus =  { 
          status      : 'E' 
        }
      }
      //prevScore.result = resultStatus
      roundDetail.scoreDetail.push(prevScore)
      roundDetail.par    = parScore
      roundDetail.si     = siScore

      // RoundDetailSchema.create(roundDetail)
      // .then((data) => {
      //   console.log('data',data)
      //   resolve(data)

      // // handleResponse(res, 200, 'RoundDetail Added Successfully', data)
      // })
      // .catch((err) => {
      //   reject(err)

      // //  handleResponse(res, 500, err.message, err)
      // });    
      resolve(roundDetail)

      //handleResponse(res, 200, 'RoundDetail Added Successfully', roundDetail)
      })

    }

    })
  return promise
  
  }


  static bulkInsert(params)
  {
      let promise=new Promise((resolve,reject) => {

        for (let index = 0; index < 18; index++) 
        {
          console.log('params---',params);
              // {
              //   "holeNumber": "18", 
              //   "roundId": "6055b9639c3e5e59e4961832", 
              //   "scoreDetail": [
              //                   {"playerId": "6055b9639c3e5e59e4961830", "score": "4"}, 
              //                   {"playerId": "6055b9639c3e5e59e4961831", "score": "2"}
              //                 ]
              // }

               let roundDetail = {}
               roundDetail.scoreDetail=  [];
               params.players.map( (playerId)=> {
                roundDetail.scoreDetail.push({"playerId": playerId, "score": ''})
               })

               roundDetail.holeNumber =  index+1;
               roundDetail.roundId    =  params.roundId;
               roundDetail.par        =  params.par[index] ? params.par[index] : 0;
               roundDetail.si         =  params.si[index]  ? params.si[index] : 0;

              // console.log('bulk insert--->',roundDetail);
               
               var newRoundDetail = new RoundDetailSchema(roundDetail);
               newRoundDetail.save()
               .then((created)=>{
                //  console.log('created info ---',created);
               });
            
            resolve(true);
         }
      });
      return promise;
  }  


  static bulkUpdate(roundDetailArray)
  {
      let updatedRoundDetail=[];
      let promise=new Promise((resolve,reject) => {

         roundDetailArray.map((roundDetail)=>{
            
            //let roundDetail=rounddetail.length>0?rounddetail[0]:{}
            console.log("roundetail in bulkUpdate",roundDetail)
            if(roundDetail._id)
            {
               RoundDetailSchema.update(
                  {_id:roundDetail._id},
                  {
                     $set:{
                        ...((roundDetail.par) ?{par:roundDetail.par} : {}),
                        ...((roundDetail.scoreDetail) ? {scoreDetail:roundDetail.scoreDetail}:{}),
                        ...((roundDetail.result)? {result:roundDetail.result}:{}),
                        ...((roundDetail.subTotal)? {subTotal:roundDetail.subTotal}:{})
                     }
                  }
               )
               .then((updated)=>{
                  console.log('updated info ---',updated);
                  updatedRoundDetail.push(updated);
               })
            }
            else{
               var newRoundDetail = new RoundDetailSchema(roundDetail);
               newRoundDetail.save()
               .then((created)=>{
                  console.log('created info ---',created);
               });
            }
            resolve(true);
         })
      });
      return promise;
  }


  static deleteAll(id) {
    
    return RoundDetailSchema.deleteMany({roundId:id}).exec()
    .then((data) => {

      return data;
    });
  }


}

module.exports = RoundDetailBusiness;
