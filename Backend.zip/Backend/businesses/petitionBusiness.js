const { resolve } = require('bluebird');
let {PetitionSchema}= require('../schema/api')

class PetitionBusiness{

  /**
   * create a new newsFeedDetail
   * @param  {Object} data newsfeed data
   * @return {Promise}
   */
  static create(data) {
    var newPetition = new PetitionSchema(data);
    return newPetition.save().then((petitions) => {
    return petitions
    })
    .catch(err=>{
      return err;
    })
  }

  /**
   * update comment
   * @param  {Object} Mongoose comment object
   * @return {Promise}
   */
  static update(comment) {
    return comment.save().then((updated) => {
     return updated
    });
  }

  /**
   * find list of courses
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }

    if(params.signedStatus){
        condition.signedStatus = params.signedStatus;
    }

    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }

    if(params.limit){
        var filter = { sortCheck : order};
        filter[sort] = filter.sortCheck;
        delete filter.sortCheck;
        limit =   params.limit;
    }

    if(params.page){
        page =   params.page -1;
        skip =   page*limit;
    }
    console.log('limit',limit)
    var aggregate = PetitionSchema.aggregate([
        {
            $match: condition
        },
        {
            $lookup:{
              from:"users",
              localField:"userId",
              foreignField:"_id",
              as:"userId"
            }
        },
        {
          $unwind : { path : '$userId', preserveNullAndEmptyArrays : true } 
        },
        {
            $lookup:{
              from:"rounds",
              localField:"roundId",
              foreignField:"_id",
              as:"roundId"
            }
        },
        {
          $unwind : { path : '$roundId', preserveNullAndEmptyArrays : true } 
        },
        {
            $project : {
                _id : 1,
                userId:{
                  _id:"$userId._id",
                  firstName:"$userId.firstName",
                  lastName:"$userId.lastName",
                  photo:"$userId.photo"
                },
                roundId: {
                  _id:"$roundId._id",
                  name:"$roundId.name"
                },
                signedStatus:1,
                status   :  1,
            }
        }, 
        {
            $group : {
                _id :"$_id",
                userId : {
                  "$first": "$userId"
                },
                signedStatus : {
                  "$first": "$signedStatus"
                },
                roundId : {
                "$first": "$roundId"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : { 
            metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }


    /**
     * find single record by params
     * @param  {Object} params Mongo query
     * @return {Promise}
     */
    static findOne(params) {    
        return PetitionSchema.findOne(params).exec();
    }

    /**
     * delete account & fire delete event
     * @param  {String} id
     * @return {Promise}
     */
    static delete(id) {
      return PetitionSchema.findByIdAndRemove(id).exec()
      .then((data) => {

        return data;
      });
    }

        /**
     * petition account & fire delete event
     * @param  {String} id
     * @return {Promise}
     */
    static scorecard(headerInfo,scoreDetail) {
      let promise = new Promise( (resolve, reject) => {
      let htmlData=''
         // scoreDetail.map( (scored, i) => {
              let playerScore = scoreDetail
                                .map(function (sc,i) { 

                                  console.log('sc.playerId',sc.playerId)
                                  console.log('headerInfo[i]',headerInfo[i])

                                  let scorecard = scoreDetail.filter( score => score.playerId == headerInfo[i].toString())
                                  // {
                                  //   console.log('sc',sc)
                                  //   return sc
                                  // }

                                  htmlData+=`<td>${scorecard[0].score}</td>`
                              })
              console.log('playerScore--',htmlData);
              //if(scored.playerId == headerInfo[i])

              resolve(htmlData)
         // })
      })

      return promise
    }

}

module.exports = PetitionBusiness;