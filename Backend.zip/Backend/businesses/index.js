var UserBusiness =require('./userBusiness')
var CountryBusiness =require('./countryBusiness')
var StateBusiness =require('./stateBusiness')
var CityBusiness =require('./cityBusiness')
var CourseBusiness =require('./courseBusiness')
var CourseDetailBusiness =require('./courseDetailBusiness')
var RoundDetailBusiness =require('./roundDetailBusiness')

var GeoBusiness =require('./geoBusiness')
var FeedbackBusiness =require('./feedbackBusiness')
var RoundBusiness =require('./roundBusiness')
var StatisticBusiness =require('./statisticBusiness')
var PrivacyBusiness =require('./privacyBusiness')
var TermBusiness =require('./termBusiness')
var AboutUsBusiness =require('./aboutUsBusiness')
var CourseStatisticBusiness =require('./courseStatisticBusiness')
var NewsFeedBusiness =require('./newsFeedBusiness')
var CommentBusiness =require('./commentBusiness')
let FaqBusiness=require('./faqBusiness')
let HelpBusiness=require('./helpBusiness')
let PetitionBusiness=require('./petitionBusiness')
let NotificationBusiness=require('./notificationBusiness')
let InsuaranceformBusiness=require('./insuaranceformBusiness')

module.exports = {
  UserBusiness,
  GeoBusiness,
  RoundBusiness,
  CountryBusiness,
  StateBusiness,
  CityBusiness,
  CourseBusiness,
  CourseDetailBusiness,
  RoundDetailBusiness,
  StatisticBusiness,
  PrivacyBusiness,
  HelpBusiness,
  FaqBusiness,
  TermBusiness,
  AboutUsBusiness,
  CommentBusiness,
  NewsFeedBusiness,
  CourseStatisticBusiness,
  FeedbackBusiness,
  PetitionBusiness,
  NotificationBusiness,
  InsuaranceformBusiness
};
