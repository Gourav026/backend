 let {CourseSchema} = require('../schema/api')
 let {RoundDetailSchema} = require('../schema/api')

 class CourseStatisticBusiness{


    static getMostPopularCourse(params){
        console.log('get most popular course business hitted..');

        let ObjectId = require('mongoose').Types.ObjectId;
        let condition = {};
        let limit = 5;
        let page = 0;
        let skip = 0;
        let sort = 'createdAt';
        let order = -1;
        if(params._id !== undefined){
            console.log('params._id hitted',params._id);

            condition = {
            _id: {$eq: new ObjectId(params._id)}
            }
        }

        if(typeof params.sort != 'undefined'){
            sort = params.sort;
        }
        if(typeof params.order != 'undefined'){
          order = params.order;
        }
        if(params.status=='active'){
            condition.status = params.status;
        }
        if(typeof params.keyword != 'undefined' && params.sort != null){
            let regex = new RegExp(params.keyword, "i")
            condition = {'$or':[{name : regex},{email : regex}]};
        }
        if(params.limit){
            let filter = { sortCheck : order};
            filter[sort] = filter.sortCheck;
            delete filter.sortCheck;
            limit =   params.limit;
        }
        if(params.page){
            page =   params.page -1;
            skip =   page*limit;
        }
          

        let aggregate=CourseSchema.aggregate([
            {
                $match:condition
            },
            { 
                $lookup : {
                    from : 'countries',
                    localField : 'countryId',
                    foreignField : '_id',
                    as : 'countryId'
                }
            },
            {
                $unwind : { path : '$countryId', preserveNullAndEmptyArrays : true } 
            },
            {
                $lookup : {
                    from : 'states',
                    localField : 'stateId',
                    foreignField : '_id',
                    as : 'stateId'
                }
            },
            {
                $unwind : { path : '$stateId', preserveNullAndEmptyArrays : true } 
            },
            {
              $lookup : {
                  from : 'cities',
                  localField : 'cityId',
                  foreignField : '_id',
                  as : 'cityId'
              }
            },
            {
                $unwind : { path : '$cityId', preserveNullAndEmptyArrays : true } 
            },
            
            {
                $project : {
                    _id : 1,
                    name : 1,
                    description : 1,
                    photo: 1,
                    imageMediumPath: 1,
                    imageThumbPath : 1,
                    countryId: {
                        _id:"$countryId._id",
                        name:"$countryId.name",
                        status:"$countryId.status"
                    },
                    stateId: {
                        _id:"$stateId._id",
                        name:"$stateId.name",
                        status:"$stateId.status"
                    },
                    cityId: {
                      _id:"$cityId._id",
                      name:"$cityId.name",
                      status:"$cityId.status"
                  },
                  geoLocation:1,
                  rating : 1,
                  redYard:1,
                  blueYard:1,
                  yellowYard:1,
                  whiteYard:1,
                  lastRecord: 1,
                  status   :  1,
                  updatedAt:1
                }
            }, 
            {
                $group : {
                    _id :"$_id",
                    name : {
                        "$first": "$name"
                    },
                    description : {
                      "$first": "$description"
                    },
                    redYard : {
                      "$first": "$redYard"
                    },
                    blueYard : {
                      "$first": "$blueYard"
                    },
                    whiteYard : {
                      "$first": "$whiteYard"
                    },
                    yellowYard : {
                      "$first": "$yellowYard"
                    },
                    photo : {
                    "$first": "$photo"
                    },
                    imageMediumPath : {
                    "$first": "$imageMediumPath"
                    },
                    imageThumbPath: {
                        "$first": "$imageThumbPath"
                    },
                    countryId : {
                        "$first": "$countryId"
                    },
                    stateId : {
                        "$first": "$stateId"
                    },
                    cityId : {
                      "$first": "$cityId"
                    }, 
                    rating : {
                      "$first": "$rating"
                    },
                    lastRecord : {
                      "$first": "$lastRecord"
                    },
                    status : {
                      "$first": "$status"
                    },
                    geoLocation:{
                      "$first":"$geoLocation"
                    },
                    updatedAt : {
                        "$first": "$updatedAt"
                    }
                }
            },
            {
                $project : {
                    _id : 1,
                    name:1,
                    description:1,
                    photo:1,
                    imageMediumPath:1,
                    imageThumbPath:1,
                    countryId : 1,
                    stateId: 1,
                    cityId:1,
                    rating: 1,
                    redYard:1,
                    blueYard:1,
                    yellowYard:1,
                    whiteYard:1,
                    geoLocation:1,
                    lastRecord:1,
                    status: 1,
                    updatedAt:1
                }
            }, 
            {
                $sort: {rating: -1}
            },
            { 
                '$facet'    : {
                metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit } } ],
                data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
                 } 
            }
        ]).exec();


        return aggregate;
          
    }



    static getMostPlayedCourse(params)
    {
        console.log('most played course business hitted');
    
        var ObjectId = require('mongoose').Types.ObjectId;
        var condition = {};
        let limit = 10;
        let page = 0;
        let skip = 0;
        var sort = 'createdAt';
        var order = -1;

        if(params._id !== undefined){
            console.log('params._id hitted',params._id);

            condition = {
                playerId: {$eq: new ObjectId(params._id)}
            }
        }

        if(typeof params.sort != 'undefined'){
            sort = params.sort;
        }
        if(typeof params.order != 'undefined'){
            order = params.order;
        }
        if(params.status=='active'){
            condition.status = params.status;
        }
        if(typeof params.keyword != 'undefined' && params.sort != null){
            var regex = new RegExp(params.keyword, "i")
            condition = {'$or':[{name : regex},{email : regex}]};
        }
        if(params.limit){
            var filter = { sortCheck : order};
            filter[sort] = filter.sortCheck;
            delete filter.sortCheck;
            limit =   params.limit;
        }


        if(params.page){
            page =   params.page -1;
            skip =   page*limit;
        }
        if(params.skip){
            skip =   params.skip;
        }

        let aggregate=CourseSchema.aggregate([
            {
                $match:condition
            },
            { 
                $lookup : {
                    from : 'countries',
                    localField : 'countryId',
                    foreignField : '_id',
                    as : 'countryId'
                }
            },
            {
                $unwind : { path : '$countryId', preserveNullAndEmptyArrays : true } 
            },
            
            {
                $lookup : {
                    from : 'states',
                    localField : 'stateId',
                    foreignField : '_id',
                    as : 'stateId'
                }
            },
            {
                $unwind : { path : '$stateId', preserveNullAndEmptyArrays : true } 
            },
            {
              $lookup : {
                  from : 'cities',
                  localField : 'cityId',
                  foreignField : '_id',
                  as : 'cityId'
              }
            },
            {
                $unwind : { path : '$cityId', preserveNullAndEmptyArrays : true } 
            },
            
            {
                $project : {
                    _id : 1,
                    name : 1,
                    description : 1,
                    photo: 1,
                    imageMediumPath: 1,
                    imageThumbPath : 1,
                    countryId: {
                        _id:"$countryId._id",
                        name:"$countryId.name",
                        status:"$countryId.status"
                    },
                    stateId: {
                        _id:"$stateId._id",
                        name:"$stateId.name",
                        status:"$stateId.status"
                    },
                    cityId: {
                      _id:"$cityId._id",
                      name:"$cityId.name",
                      status:"$cityId.status"
                  },
                  geoLocation:1,
                  rating : 1,
                  redYard:1,
                  blueYard:1,
                  yellowYard:1,
                  whiteYard:1,
                  lastRecord: 1,
                  status   :  1,
                  totalTimesPlayed:1,
                  updatedAt:1
                }
            }, 
            {
                $group : {
                    _id :"$_id",
                    name : {
                        "$first": "$name"
                    },
                    description : {
                      "$first": "$description"
                    },
                    redYard : {
                      "$first": "$redYard"
                    },
                    blueYard : {
                      "$first": "$blueYard"
                    },
                    whiteYard : {
                      "$first": "$whiteYard"
                    },
                    yellowYard : {
                      "$first": "$yellowYard"
                    },
                    photo : {
                    "$first": "$photo"
                    },
                    imageMediumPath : {
                    "$first": "$imageMediumPath"
                    },
                    imageThumbPath: {
                        "$first": "$imageThumbPath"
                    },
                    countryId : {
                        "$first": "$countryId"
                    },
                    stateId : {
                        "$first": "$stateId"
                    },
                    cityId : {
                      "$first": "$cityId"
                    }, 
                    rating : {
                      "$first": "$rating"
                    },
                    lastRecord : {
                      "$first": "$lastRecord"
                    },
                    status : {
                      "$first": "$status"
                    },
                    geoLocation:{
                      "$first":"$geoLocation"
                    },
                    totalTimesPlayed:{
                      "$first":"$totalTimesPlayed"
                    },
                    updatedAt : {
                        "$first": "$updatedAt"
                    }
                }
            },
            {
                $project : {
                    _id : 1,
                    name:1,
                    description:1,
                    photo:1,
                    imageMediumPath:1,
                    imageThumbPath:1,
                    countryId : 1,
                    stateId: 1,
                    cityId:1,
                    rating: 1,
                    redYard:1,
                    blueYard:1,
                    yellowYard:1,
                    whiteYard:1,
                    geoLocation:1,
                    totalTimesPlayed:1,
                    lastRecord:1,
                    status: 1,
                    updatedAt:1
                }
            }, 
            {
                $sort:{totalTimesPlayed:-1}
            },
            { 
                '$facet'    : {
                metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit } } ],
                data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
                 } 
            }
        ]).exec();

        return aggregate;
    }
}

 module.exports = CourseStatisticBusiness;