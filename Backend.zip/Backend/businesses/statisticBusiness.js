var { CourseSchema, CourseDetailSchema, RoundSchema, RoundDetailSchema } = require('../schema/api')
var fs = require('fs')

class StatisticBusiness {


  /**
   * find list of roundDetails
   * @param  {Object} params Mongo query
   * @return {Promise}
   */

    static find(params) {
        console.log('find hitted');
        
        var ObjectId = require('mongoose').Types.ObjectId;
        var condition = {};
        let limit = 18;
        let page = 0;
        let skip = 0;
        var sort = 'createdAt';
        var order = -1;
        if(params._id !== undefined){
          console.log('params._id hitted',params._id);
    
          condition = {
          _id: {$eq: new ObjectId(params._id)}
          }
        }
    
        if(typeof params.sort != 'undefined'){
            sort = params.sort;
        }
        if(typeof params.order != 'undefined'){
          order = params.order;
        }
        if(params.status=='active'){
            condition.status = params.status;
        }
        if(typeof params.keyword != 'undefined' && params.sort != null){
          var regex = new RegExp(params.keyword, "i")
          condition = {'$or':[{name : regex},{email : regex}]};
        }
    
        if(params.playerId){
          condition.playerId = new ObjectId(params.playerId) ;
        }
    
        if(params.roundId){
          condition.roundId = new ObjectId(params.roundId);
        }
    
        if(params.limit){
          var filter = { sortCheck : order};
          filter[sort] = filter.sortCheck;
          delete filter.sortCheck;
          limit =   params.limit;
          }
    
          if(params.page){
            page =   params.page;
          }
    
         if(params.skip){
            skip =   params.skip;
          }
           console.log('limit',limit)
           var aggregate = RoundDetailSchema.aggregate([
    
            { $unwind: "$scoreDetail" },
          //   {
          //     $lookup:
          //       {
          //         from: "users",
          //         localField: "scoreDetail.playerId",
          //         foreignField: "_id",
          //         as: "playerdetails"
          //       },
          //    },
             
          //    {
          //         $unwind : { path : '$playerdetails', preserveNullAndEmptyArrays : true } 
          //     },
              
          //   { $group: { _id: "$scoreDetail.playerId", playerdetails:{ "addToSet":"$playerdetails" }}  },
          //    {
          //       $project : {
          //           score : 1,
          //           playerdetails:1,
          //           scoreDetail:1
                   
          //       }
          //    }, 
    
    
            //{ $project: { value: { count: { $size: "$orders_ids" }, score: "$score", avg: { $divide: [ "$score", { $size: "$orders_ids" } ] } } } },
            
           //  { $group: { _id:null, playerId: "$scoreDetail.playerId", value: { $sum: "$scoreDetail.score" } } },
    
              {
                  $match: condition
              },
              
              { 
                  $lookup : {
                      from : 'rounds',
                      localField : 'roundId',
                      foreignField : '_id',
                      as : 'roundId'
                  }
              },
              {
                  $unwind : { path : '$roundId', preserveNullAndEmptyArrays : true } 
              },
              { 
                $lookup : {
                    from : 'users',
                    localField : 'scoreDetail.playerId',
                    foreignField : '_id',
                    as : 'playerId'
                }
            },
            {
                $unwind : { path : '$playerId', preserveNullAndEmptyArrays : true } 
            },
            {
                $project : {
                    holeNumber : 1,
                    par:1,
                    si:1,
                    score:1,
                    roundId:1,
                    subTotal:1,
                    playerScore:1,
                    scoreDetail:1,
                    playerId:1,
                    orders_ids:1,
                    updatedAt:1
                }
            }, 
            
            {
                $group : { 
                    _id: "$scoreDetail.playerId",
                     score: { $sum: "$scoreDetail.score" } , 
                     orders_ids: { $addToSet: "$_id" },   
                   // _id :"$_id",
                    roundId : {
                      "$first": "$roundId"
                    },
                    holeNumber : {
                        "$first": "$holeNumber"
                    },
                    par : {
                        "$first": "$par"
                    },
                    si : {
                        "$first": "$si"
                    },
                    subTotal : {
                        "$first": "$subTotal"
                    },
                    scoreDetail : {
                        "$first": "$scoreDetail"
                    },
                    playerId : {
                        "$first": "$playerId"
                    },
                    updatedAt : {
                        "$first": "$updatedAt"
                    }
                }
            },
            {
                $project : {
                    _id : 1,
                    holeNumber : 1,
                    roundId : 1,
                    par:1,
                    score:1,
                    si:1,
                    subTotal:1,
                     scoreDetail: 1,
                    playerId: 1,
                    roundno: {  $size: "$orders_ids"  },
                    orders_ids:1,
                    updatedAt:1
                }
            },
            {
                $sort: {holeNumber: 1}
            },
            { $match:
              { $expr:
                 { 
                   $gte: [ "$roundno", 10 ]  
                 }
              }
           },
          //   { $redact: {
          //     let: { order_item: "$orders_ids"},
          //     $cond: {
                
          //       if: { $gt: [ { $size: "$$order_item" }, 6 ] },
          //        //if: ( { roundno: { $gte: [ "$roundno", 10 ] }} ),
          //        then: "$$DESCEND",
          //        else: "$$PRUNE"
               
          //     }
          //   }
          //  } ,
    
            { 
                '$facet'    : {
                metadata: [
                   { $count: "total" },
                   { $addFields: { page: page } },
                   ],
                data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ], // add projection here wish you re-shape the docs
                resource: [
                          { 
                              $lookup : {
                                  from : 'users',
                                  localField : 'scoreDetail.playerId',
                                  foreignField : '_id',
                                  as : 'userId'
                              }
                          },
                          {
                            $sort:{score:-1}
                          },
                          
                          {
                              $unwind : { path : '$userId', preserveNullAndEmptyArrays : true } 
                          },
                          {
                              $project : {
                                  _id : 1,
                                  subTotal:1,
                                  userId: {
                                    _id:"$userId._id",
                                    firstName:"$userId.firstName",
                                    lastName:"$userId.lastName",
                                    photo:"$userId.photo"
                                  }
                              }
                          },
                          {
                              $group : {              
                                  _id :"$scoreDetail.playerId",
                                  userId : {
                                    "$addToSet": "$userId"
                                 },
                                 subTotal : {
                                  "$addToSet": "$subTotal"
                               },
                              }
                          },
                          {
                            $addFields: {
                              total:{
                                parTotal: { $sum: "$scoreDetail.par" } ,
                                scoreTotal: { $sum: "$scoreDetail.score" } 
                              }
                            }
                          },
                          {
                              $project : {
                                  _id : 1,
                                  userId: 1,
                                  subTotal:1,
                                  total:1,
                              },
                              
                          },
                         
                         
                        ]
              } 
            },
          //  { $out: "agg_alternative_1" },
    
        ]
    
        ).exec()
    
        return aggregate
      }

  /**
   * find list of leaderBoardStatistic
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static leaderBoardStatistic(params) {
    console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 18;
    let page = 0;
    let skip = 0;
    var conditionCourse = {};
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }

    }
    if(params.courseId !== undefined)
    {
        conditionCourse = {
            "roundId.courseId": {$eq: new ObjectId(params.courseId)}
        }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }

    if(params.playerId){
      condition.playerId = new ObjectId(params.playerId) ;
    }

    if(params.roundId){
        condition.roundId = new ObjectId(params.roundId);
      }

    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page;
      }

     if(params.skip){
        skip =   params.skip;
      }
       console.log('limit',limit)
       var aggregate = RoundDetailSchema.aggregate([

        { $unwind: "$scoreDetail" },
      //   {
      //     $lookup:
      //       {
      //         from: "users",
      //         localField: "scoreDetail.playerId",
      //         foreignField: "_id",
      //         as: "playerdetails"
      //       },
      //    },
         
      //    {
      //         $unwind : { path : '$playerdetails', preserveNullAndEmptyArrays : true } 
      //     },
          
      //   { $group: { _id: "$scoreDetail.playerId", playerdetails:{ "addToSet":"$playerdetails" }}  },
      //    {
      //       $project : {
      //           score : 1,
      //           playerdetails:1,
      //           scoreDetail:1
               
      //       }
      //    }, 


        //{ $project: { value: { count: { $size: "$orders_ids" }, score: "$score", avg: { $divide: [ "$score", { $size: "$orders_ids" } ] } } } },
        
       //  { $group: { _id:null, playerId: "$scoreDetail.playerId", value: { $sum: "$scoreDetail.score" } } },

          {
              $match: condition
          },
          
          { 
              $lookup : {
                  from : 'rounds',
                  localField : 'roundId',
                  foreignField : '_id',
                  as : 'roundId'
              }
          },
          {
              $unwind : { path : '$roundId', preserveNullAndEmptyArrays : true } 
          },
          {
            $match: conditionCourse
        },
          { 
            $lookup : {
                from : 'users',
                localField : 'scoreDetail.playerId',
                foreignField : '_id',
                as : 'playerId'
            }
        },
        {
            $unwind : { path : '$playerId', preserveNullAndEmptyArrays : true } 
        },
        {
            $project : {
                holeNumber : 1,
                par:1,
                si:1,
                score:1,
                roundId:1,
                subTotal:1,
                playerScore:1,
                scoreDetail:1,
                playerId:{
                    firstName:'$playerId.firstName',
                    lastName:'$playerId.lastName',
                    photo:'$playerId.photo'
                },
                orders_ids:1,
                updatedAt:1
            }
        }, 
        
        {
            $group : { 
                _id: "$scoreDetail.playerId",
                 score: { $sum: "$scoreDetail.score" } , 
                 orders_ids: { $addToSet: "$_id" },   
               // _id :"$_id",
                roundId : {
                  "$first": "$roundId"
                },
                holeNumber : {
                    "$first": "$holeNumber"
                },
                par : {
                    "$first": "$par"
                },
                si : {
                    "$first": "$si"
                },
                subTotal : {
                    "$first": "$subTotal"
                },
                scoreDetail : {
                    "$first": "$scoreDetail"
                },
                playerId : {
                    "$first": "$playerId"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }
            }
        },
        {
            $project : {
                _id : 1,
                holeNumber : 1,
                roundId : 1,
                par:1,
                score:1,
                si:1,
                subTotal:1,
                 scoreDetail: 1,
                playerId: 1,
                roundno: {  $size: "$orders_ids"  },
                orders_ids:1,
                updatedAt:1
            }
        },
        
        { $match:
          
             { 
              'roundno' : {"$gte": 4 } 
             },
            
          
       },


       {
        $sort: {score: 1}
    },
      //   { $redact: {
      //     let: { order_item: "$orders_ids"},
      //     $cond: {
            
      //       if: { $gt: [ { $size: "$$order_item" }, 6 ] },
      //        //if: ( { roundno: { $gte: [ "$roundno", 10 ] }} ),
      //        then: "$$DESCEND",
      //        else: "$$PRUNE"
           
      //     }
      //   }
      //  } ,

        { 
            '$facet'    : {
            metadata: [
               { $count: "total" },
               { $addFields: { page: page } },
               ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ], // add projection here wish you re-shape the docs
            resource: [
                      { 
                          $lookup : {
                              from : 'users',
                              localField : 'scoreDetail.playerId',
                              foreignField : '_id',
                              as : 'userId'
                          }
                      },
                      {
                        $sort:{score:-1}
                      },
                      
                      {
                          $unwind : { path : '$userId', preserveNullAndEmptyArrays : true } 
                      },
                      {
                          $project : {
                              _id : 1,
                              subTotal:1,
                              userId: {
                                _id:"$userId._id",
                                firstName:"$userId.firstName",
                                lastName:"$userId.lastName",
                                photo:"$userId.photo"
                              }
                          }
                      },
                      {
                          $group : {              
                              _id :"$scoreDetail.playerId",
                              userId : {
                                "$addToSet": "$userId"
                             },
                             subTotal : {
                              "$addToSet": "$subTotal"
                           },
                          }
                      },
                      {
                        $addFields: {
                          total:{
                            parTotal: { $sum: "$scoreDetail.par" } ,
                            scoreTotal: { $sum: "$scoreDetail.score" } 
                          }
                        }
                      },
                      {
                          $project : {
                              _id : 1,
                              userId: 1,
                              subTotal:1,
                              total:1,
                          },
                          
                      },
                     
                     
                    ]
          } 
        },
      //  { $out: "agg_alternative_1" },

    ]

    ).exec()

    return aggregate
  }


  

  /**
   * find list of coursewiseLeaderBoardStatistic
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static coursewiseLeaderBoardStatistic(params) {
    console.log('coursewiseLeaderBoardStatistic  find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    var conditionCourse = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }

    }
    if(params.courseId !== undefined)
    {
        conditionCourse = {
            "roundId.courseId": {$eq: new ObjectId(params.courseId)}
        }
    }

       var aggregate = RoundDetailSchema.aggregate([
        {
            $match: condition

        },
        { 
            $lookup : {
                from : 'rounds',
                localField : 'roundId',
                foreignField : '_id',
                as : 'roundId'
            }
        },
        {
            $unwind : { path : '$roundId', preserveNullAndEmptyArrays : true } 
        },
        {
            $match: conditionCourse
        },
        {  
            $lookup : {
                from : 'courses',
                localField : 'roundId.courseId',
                foreignField : '_id',
                as : 'courseMaster'
            }
        },
        {
            $unwind : { path : '$courseMaster', preserveNullAndEmptyArrays : true } 
        },
        {  
            $lookup : {
                from : 'coursedetails',
                localField : 'roundId.courseId',
                foreignField : 'courseId',
                as : 'courseDetail'
            }
        },
        {
            $unwind : { path : '$courseDetail', preserveNullAndEmptyArrays : true } 
        },
        { 
            $lookup : {
                from : 'users',
                localField : 'playerId',
                foreignField : '_id',
                as : 'playerId'
            }
        },
        {
            $unwind : { path : '$playerId', preserveNullAndEmptyArrays : true } 
        },
        {
            $project : {
                _id : 1,
                holeNumber : 1,
                playerScore : 1,
                count : 1,
                courseDetail: {
                    _id:"$courseDetail._id",
                    holeNumber:"$courseDetail.holeNumber",
                    par:"$courseDetail.par",
                    strokeIndex:"$courseDetail.strokeIndex",
                    scoringAverage:"$courseDetail.scoringAverage",
                    courseId:"$courseDetail.courseId",
                    name:"$courseMaster.name",
                    
                },
                
                roundId: 1,
                playerId: {
                    _id:"$playerId._id",
                    firstName:"$playerId.firstName",
                    lastName:"$playerId.lastName",
                    photo:"$playerId.photo",
                    imageThumbPath:"$playerId.imageThumbPath",
                    imageMediumPath:"$playerId.imageMediumPath",
                },
                updatedAt:1
            }
        }, 
        {
            $group : {
                _id :{playerId:"$playerId",
                courseDetail:"$courseDetail"
            },
                // holeNumber : {
                //     "$first": "$holeNumber"
                // },
                // courseId : {
                //     "$first": "$courseId"
                // },
                // roundId : {
                //     "$first": "$roundId"
                // },
                // playerId : {
                //     "$first": "$playerId"
                // },
                // updatedAt : {
                //     "$first": "$updatedAt"
                // },
                playerScore :{ $sum: "$playerScore" },
                count: { $sum: 1 },
            }
        },
        {
            $project : {
                _id : 1,
                holeNumber : 1,
                playerScore : 1,
                count : 1,
                courseDetail:1,
                courseId: 1,
                roundId: 1,
                playerId: 1,
                updatedAt:1
            }
        }, 
        {
            $sort: {updatedAt: -1}
        }
    ]

    ).exec()

    return aggregate
  }









  /**
   * find list of roundDetails
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
   static async playerwiseLeaderBoardStatistic(params) {
    //console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let conditionPlayer={}
    let limit = 18;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    let playerId =null
    if(params.playerId !== undefined)
    {
      playerId = new ObjectId(params.playerId) 
    }

    if(params.limit){
      var filter = { sortCheck : order};
      filter[sort] = filter.sortCheck;
      delete filter.sortCheck;
      limit =   params.limit;
      }

      if(params.page){
        page =   params.page;
      }

     if(params.skip){
        skip =   params.skip;
      }
       //console.log('limit',limit)
       var aggregate = await RoundDetailSchema.aggregate(
        [
         {
             $match:{
             scoreDetail:{$elemMatch:{playerId:playerId}},
             }
         },
         {
             "$unwind": "$scoreDetail"
          },              
         { 
            $lookup : {
                from : 'rounds',
                localField : 'roundId',
                foreignField : '_id',
                as : 'roundId'
            }
         },
         {
            $unwind : { path : '$roundId', preserveNullAndEmptyArrays : true } 
         },   
        {  
            $lookup : {
                from : 'courses',
                localField : 'roundId.courseId',
                foreignField : '_id',
                as : 'courseId'
            }
        },
        {
            $unwind : { path : '$courseId', preserveNullAndEmptyArrays : true } 
        },
         {
          '$facet':{
                total:[     
                 {
                    "$match": {
                        "scoreDetail.playerId": playerId
                 }
                 },
                                   
                 {
                    $group:
                      {
                        _id: "$roundId",
                         "total": {
                             "$sum": "$scoreDetail.score"
                         },
                        courseId: { "$first": "$courseId" },
                        result: { "$first": "$result" },
                        holeNumber: { "$first": "$holeNumber"},
                        scoreDetail: { "$first": "$scoreDetail" },
                        roundId:{"$first":"$roundId"}
                      }
                  },
                  {
                   $project: {  
                      _id:{_id:"$_id._id",name:"$_id.name",createdAt:"$_id.createdAt"}, 
                       courseId:{name:"$courseId.name"},
                       total:1
                       } 
                      
                  },
                  {
                      $sort:{"_id.createdAt":-1}
                  }
                  ],
              frontLine:[     
                 {
                    "$match": {
                        "scoreDetail.playerId": playerId,
                        "holeNumber":{$lte:9}
                 }
                 },
                                   
                 {
                    $group:
                      {
                        _id: "$roundId",
                         "total": {
                             "$sum": "$scoreDetail.score"
                         },
                        result: { "$first": "$result" },
                        holeNumber: { "$first": "$holeNumber"},
                        scoreDetail: { "$first": "$scoreDetail" },
                        roundId:{"$first":"$roundId"}
                      }
                  },
                  {
                   $project: {  
                      _id:1, 
                       total:1
                       } 
                      
                  },
                  {
                      $sort:{"_id.createdAt":-1}
                  }
                  ],
                backLine:[     
                 {
                    "$match": {
                        "scoreDetail.playerId": ObjectId("603c93a493721c2551cbc8f5"),
                        "holeNumber":{$gte:10}
                 }
                 },
                                   
                 {
                    $group:
                      {
                        _id: "$roundId",
                         "total": {
                             "$sum": "$scoreDetail.score"
                         },
                        result: { "$first": "$result" },
                        holeNumber: { "$first": "$holeNumber"},
                        scoreDetail: { "$first": "$scoreDetail" },
                        roundId:{"$first":"$roundId"}
                      }
                  },
                  {
                   $project: {  
                      _id:1, 
                       total:1
                       } 
                      
                  },
                  {
                      $sort:{"_id.createdAt":-1}
                  }
                  ]                      
                      
                  }
                      
               }
        ]).exec()

        let promise = new Promise((resolve, reject) => {
        let arr = []
        console.log('aggregate total---',aggregate[0].total);
        console.log('aggregate[0].backLine---',aggregate[0].backLine);
        if (aggregate[0].total.length > 0){
        //console.log('aggregate--', aggregate[0].total);
          aggregate[0].total.map( (aggregateData) => {
          
            let roundId = aggregateData._id._id;
            let course = aggregateData.courseId.name;
            let createdAt = aggregateData._id.createdAt;
            let total = aggregateData.total;
            let frontLine = aggregate[0].frontLine.find(val => val._id._id.toString() == roundId.toString())
            console.log('frontLine-',frontLine);
            if(Object.keys(frontLine).length === 0)
            {
              frontLine = 0
            }else{
              frontLine = frontLine.total
            }
            let backLine = total-frontLine//aggregate[0].backLine.find(val => val._id._id.toString() == roundId.toString())

            // if(aggregate[0].backLine.some(person => person.total >= 0)){
            //   backLine = backLine.total
            // } else{
            //   console.log("Object not found.");
            //   backLine = 0
            // }

            arr.push({createdAt:createdAt,course:course,roundId:roundId,total:total,frontLine:frontLine,backLine:backLine})
            resolve(arr)
          })

          }
        })

    return promise
  }





















}

module.exports = StatisticBusiness;
