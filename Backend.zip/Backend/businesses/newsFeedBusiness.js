let {NewsFeedSchema}= require('../schema/api')
var fcmNotification = require('../modules/fcmNotification');



class NewsFeedBusiness{

  /**
   * create a new newsFeed
   * @param  {Object} data newsfeed data
   * @return {Promise}
   */
  static create(data) {
    var newNewsFeed = new NewsFeedSchema(data);
    return newNewsFeed.save().then((newsFeed) => {
      //fire event to another sides
    //console.log('newsFeed--->',newsFeed)
    return newsFeed
    });
  }



  /**
   * update newsFeed
   * @param  {Object} Mongoose newsFeed object
   * @return {Promise}
   */
  static update(newsFeed) {
    return newsFeed.save().then((updated) => {
     return updated
    });
  }






  /**
   * find list of newsFeeds
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
  static find(params) {
    //console.log('find hitted');
    
    var ObjectId = require('mongoose').Types.ObjectId;
    var condition = {};
    let limit = 10;
    let page = 0;
    let skip = 0;
    var sort = 'createdAt';
    var order = -1;
    if(params._id !== undefined){
      //console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }

    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
        var filter = { sortCheck : order};
        filter[sort] = filter.sortCheck;
        delete filter.sortCheck;
        limit =   params.limit;
    }


    if(params.page){
        page =   params.page -1;
        skip =   page*limit;
    }
    //console.log('limit',limit)
    var aggregate = NewsFeedSchema.aggregate([
        {
            $match: condition
        },
        {
            $lookup:{
              from:"users",
              localField:"userId",
              foreignField:"_id",
              as:"userId"
            }
        },
        {
          $unwind : { path : '$userId', preserveNullAndEmptyArrays : true } 
        },
        {
          $lookup:{
            from:"users",
            localField:"likedBy",
            foreignField:"_id",
            as:"likedBy"
          }
      },
      {
        $unwind : { path : '$likedBy', preserveNullAndEmptyArrays : true } 
      },
        {
            $project : {
                _id : 1,
                userId:{
                  _id:"$userId._id",
                  firstName:"$userId.firstName",
                  lastName:"$userId.lastName",
                  photo:"$userId.photo"
                },
                description : 1,
                photo: 1,
                imageMediumPath: 1,
                imageThumbPath : 1,
                status   :  1,
                updatedAt:1,
                video:1,
                likedBy:{
                  _id:"$likedBy._id",
                  firstName:"$likedBy.firstName",
                  lastName:"$likedBy.lastName",
                  photo:"$likedBy.photo"
                },
                videoThumb:1,
                
            }
        }, 
        {
            $group : {
                _id :"$_id",
                userId : {
                  "$first": "$userId"
                },
                description : {
                  "$first": "$description"
                },
                photo : {
                "$first": "$photo"
                },
                likedBy : {
                  "$addToSet": "$likedBy"
                },
                imageMediumPath : {
                "$first": "$imageMediumPath"
                },
                imageThumbPath: {
                    "$first": "$imageThumbPath"
                },
                video : {
                    "$first": "$video"
                },
                videoThumb : {
                    "$first": "$videoThumb"
                },
                status : {
                  "$first": "$status"
                },
                updatedAt : {
                    "$first": "$updatedAt"
                }

            }
        },
        {
            $sort: {updatedAt: -1}
        },
        { 
            '$facet'    : { 
            metadata: [ { $count: "total" }, { $addFields: { page: page +1, limit:limit } } ],
            data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
             } 
        }
    ]

    ).exec()

    return aggregate
  }


    /**
     * find single record by params
     * @param  {Object} params Mongo query
     * @return {Promise}
     */
    static findOne(params) {    
        return NewsFeedSchema.findOne(params).exec();
    }

    /**
     * delete account & fire delete event
     * @param  {String} id
     * @return {Promise}
     */
    static delete(id) {
      return NewsFeedSchema.findByIdAndRemove(id).exec()
      .then((data) => {

        return data;
      });
    }

    static newsFeedList(params){

      //console.log('newsFeedList hitted');
     
      
      let ObjectId = require('mongoose').Types.ObjectId;
      let condition = {};
      let limit = 10;
      let sort = 'createdAt';
      let order = -1;
      if(params._id !== undefined){
        //console.log('params._id hitted',params._id);
  
        condition = {
        _id: {$eq: new ObjectId(params._id)},
        role:'newsFeed'
        }
      }
      ////console.log("hiiiii-..")
      if(typeof params.sort != 'undefined'){
          sort = params.sort;
      }
      if(typeof params.order != 'undefined'){
        order = params.order;
      }
      if(params.status=='active'){
          condition.status = params.status;
      }
  
     return NewsFeedSchema.find(condition).sort({name:1}).exec();
  
  
     }




	static async sendNotification(toUser, notification) {
	//console.log('enter notification', friendRequestNotified, toUser, notification);
	// if(!friendRequestNotified){
				
	// let notificationData = {
	// 	title:'Friend Request',
	// 	excludeUserId : notification.fromUser,
	// 	toUser   : notification.toUser,
	// }
	// await fcmNotification.fcmSentPush(
	// 	notificationData, 
	// 	toUser.deviceId, 
	// 	`Hello ${toUser.firstName} ${toUser.lastName},
	// 	${notification.message}`
	// 	)
	// }
	
	let notificationData = {
		title:'Notification for new Newsfeed',
		excludeUserId : notification.fromUser,
		toUser   : notification.toUser,
	}
	await fcmNotification.fcmSentPush(
		notificationData, 
		toUser.deviceId, 
		`Hello ${toUser.firstName} ${toUser.lastName},
		New Newsfed posted`
		)  
	}

}

module.exports = NewsFeedBusiness;