let {FeedbackSchema}= require("../schema/api");
const feedback = require("../schema/api/feedback");

class FeedbackBusiness{

    //==================== Creata a FEEDBACK ==================
    static create(data)
    {
        let Feedbackdata=new FeedbackSchema(data);
        return Feedbackdata.save().then((feedback)=>{
            console.log("feedback--->",feedback);
            return feedback;
        })
    }

  /**
   * find list of feedbacks
   * @param  {Object} params Mongo query
   * @return {Promise}
   */
   static find(params) {
    console.log('find hitted');
    
    console.log('params=',params);
    let ObjectId = require('mongoose').Types.ObjectId;
    let condition = {};
    let limit = 10;
    let page=0;
    let skip=0;
    let sort = 'createdAt';
    let order = -1;
    let queryName=''

    if(params._id !== undefined){
      console.log('params._id hitted',params._id);

      condition = {
      _id: {$eq: new ObjectId(params._id)}
      }
    }
    console.log("hiiiii-..")
    if(typeof params.sort != 'undefined'){
        sort = params.sort;
    }
    if(typeof params.order != 'undefined'){
      order = params.order;
    }
    if(params.status=='active'){
        condition.status = params.status;
    }
    if(params.page){
      page =   params.page;
    }
    if(params.searchName!='undefined')
    {
      queryName={
        "$or":[{
          "title":new RegExp(params.searchName,'i')
        },{
          "userId.name":new RegExp(params.searchName) 
        }]
      }
    }
    if(params.skip){
      skip =   params.skip;
    }
    if(typeof params.keyword != 'undefined' && params.sort != null){
      var regex = new RegExp(params.keyword, "i")
      condition = {'$or':[{name : regex},{email : regex}]};
    }
    if(params.limit){
      limit =   params.limit;
    }

    condition=(params.searchName!= 'undefined' || params.searchName!=='')?
    {...condition,...queryName}:condition;
    console.log("params.limit=",params.limit)
    let aggregate=FeedbackSchema.aggregate([
      {
        $match:condition
      },
      {
        $lookup:{
          from:'users',
          localField:'userId',
          foreignField:'_id',
          as:'userId'
        }
      },
      {
        $unwind:{
          path:'$userId', 
          preserveNullAndEmptyArrays : true
        }
      },
      {
        $project:{
          _id:1,
          title:1,
          description:1,
          userId:{
            firstName:"$userId.firstName",
            lastName:"$userId.lastName",
            photo:"$userId.photo",
            email:"$userId.email"
          },
          updatedAt:1
        }
      },
      {
        $group:{
          _id:"$_id",
          title:{
            "$first":"$title"
          },
          description:{
            "$first":"$description"
          },
          userId:{
            "$first":"$userId"
          },
          updatedAt:{
            "$first":"$updatedAt"
          },

        }
      },
      {
        $project:{
          _id:1,
          title:1,
          description:1,
          userId:1,
          updatedAt:1
        }
      },
      {
        $sort:{updatedAt:-1}
      },
      { 
        '$facet'    : {
        metadata: [ { $count: "total" }, { $addFields: { page: page, limit:limit} } ],
        data: [ { $skip: parseInt(skip) }, { $limit: parseInt(limit) } ] // add projection here wish you re-shape the docs
         } 
      }
    ]).exec();

    return aggregate;

  }  

  static findOne(params) {    
    return FeedbackSchema.findOne(params).populate('userId').exec();
  } 

  /**
     * update feedback
     * @param  {Object} Mongoose faq object
     * @return {Promise}
     */
   static update(feedback) {
    return feedback.save().then((updated) => {
    return updated
    });
}


 /**
     * delete account & fire delete event
     * @param  {String} id
     * @return {Promise}
     */
  static delete(id) {
    return FeedbackSchema.findByIdAndRemove(id).exec()
    .then((data) => {

      return data;
    });
  }
  
}

module.exports= FeedbackBusiness
