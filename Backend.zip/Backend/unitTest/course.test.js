const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { StateSchema } = require('../schema/api')
var before = require('mocha').before;
const { userOne,setupDatabase, countryOne,stateOne,courseOne,cityOne} = require('./utils/user')
const stateId = new mongoose.Types.ObjectId()

before(setupDatabase);
        describe('POST /api/v1/course/add', function(){
            it('Should register a new course record', function(done){
             
                 request(app)
                  .post('/api/v1/course/add')
                  .send({
                    "rating" : 4.8,
                    "lastRecord" : 1,
                    "status" : true,
                    "name" : "Amby Golf Club",
                    "countryId" : `${countryOne._id}`,
                    "stateId" :`${stateOne._id}`,
                    "cityId" : `${cityOne._id}`,
                    "description" : "The AMBY Golf Club, a municipal course in the early 1930s became a corporate entity in 24th February 1950. The Course, comprises of the championship 18 hole Lodhi Course, part of the Asian PGA Tour, and the shorter 9 hole Peacock Course. The latter came into being when the course was re-designed by Peter Thomson in 1976-77.",
                    "blueYard" : 3,
                    "redYard" : 5,
                    "whiteYard" : 6,
                    "yellowYard" : 8,
                    "geoLocation" :JSON.stringify([ 
                        {
                            "lat" : 23.4930567,
                            "lng" : 89.3553
                        }, 
                        {
                            "lat" : 23.4930567,
                            "lng" : 89.3553
                        }, 
                        {
                            "lat" : 23.4929377481547,
                            "lng" : 87.357810547638
                        }, 
                        {
                            "lat" : 23.4907569462013,
                            "lng" : 87.3586044815064
                        }, 
                        {
                            "lat" : 23.4902811302989,
                            "lng" : 87.3557506111145
                        }, 
                        {
                            "lat" : 23.4917085730983,
                            "lng" : 87.3535082843781
                        }
                    ])
                  })
                  .expect('Content-Type', /json/)
                  .expect(200)
                  .end(function(err, res) {
                      if (err) return done(err);
                      return done();
              });
          }); 
          });
 
  describe('GET /api/v1/course', function() {
      it('Should get all course', function(done) {
        request(app)
          .get('/api/v1/course')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  

 /*
   * START
   * Test Case For Update Specific User Photo
   */

 describe(`PUT /api/v1/course/${courseOne._id}`, function() {
    it('Should update course photo', function(done) {
      request(app)
        .put(`/api/v1/course/${courseOne._id}`)
        .set('authorization',`Bearer ${userOne.authToken}`)
        .attach('avatar', 'test/fixtures/default.jpeg')
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
          return done();
        });
    });
  });  

/*
* END
* Test Case For Update Specific User Photo
*/
    //--------- course Statistic start -------   //

    describe('GET /api/v1/mostPopular', function() {
      it('Should get all mostPopular', function(done) {
        request(app)
          .get('/api/v1/mostPopular')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  
  


    describe('GET /api/v1/mostPlayed', function() {
      it('Should get all mostPlayed', function(done) {
        request(app)
          .get('/api/v1/mostPlayed')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  


    



    //--------- course Statistic end ------- //

describe(`PUT /api/v1/course/${courseOne._id}`, function() {
  it('Should update course', function(done) {
    request(app)
      .put(`/api/v1/course/${courseOne._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)
      .send({name:'East Point Golf Club'})        
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  

describe(`DELETE /api/v1/course/${courseOne._id}`, function() {
  it('Should delete course', function(done) {
    request(app)
      .delete(`/api/v1/course/${courseOne._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)       
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  