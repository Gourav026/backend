const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { StateSchema } = require('../schema/api')
var before = require('mocha').before;
const { userOne,setupDatabase ,countryOne,stateOne} = require('./utils/user')
const stateId = new mongoose.Types.ObjectId()


before(setupDatabase);

        describe('POST /api/v1/state/add', function(){
            it('Should register a new state record', function(done){
                 request(app)
                  .post('/api/v1/state/add')
                  .send({
                      "name":"Hariyana",
                      "countryId":`${countryOne._id}`
                  })
                  .expect('Content-Type', /json/)
                  .expect(200)
                  .end(function(err, res) {
                      if (err) return done(err);
                      return done();
              });
          }); 
          });
 
  describe('GET /api/v1/state', function() {
      it('Should get all state', function(done) {
        request(app)
          .get('/api/v1/state')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  


    
describe(`PUT /api/v1/state/${stateOne._id}`, function() {
  it('Should update state', function(done) {
    request(app)
      .put(`/api/v1/state/${stateOne._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)
      .send({name:'Maharashtra'})        
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  

describe(`DELETE /api/v1/state/${stateOne._id}`, function() {
  it('Should delete state', function(done) {
    request(app)
      .delete(`/api/v1/state/${stateOne._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)       
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  