const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { RoundDetailSchema } = require('../schema/api')
var beforeAll = require('mocha').beforeAll;
var before = require('mocha').before;
const { userOne,setupDatabase ,roundOne,courseOne,rounddetailOne} = require('./utils/user')
const stateId = new mongoose.Types.ObjectId()




        // describe("POST /api/v1/roundDetail/add",function(){
        //     console.log("courseid-------------------------------------------->",courseOne._id)
        //     console.log("userid-------------------------------------------->",userOne._id);
        //     it('Should register a new roundDetail record', function(done){
        //          request(app)
        //           .post("/api/v1/roundDetail/add")
        //           .set('authorization',`Bearer ${userOne.authToken}`)
        //           .send({
                    
        //             "holeNumber": 18,
        //              "roundId": `${roundOne._id}`,
        //               "scoreDetail": [{"playerId":` ${userOne._id}`, "score": 4}]
                    
        //         })
                  
        //           .expect('Content-Type', /json/)
        //           .expect(200)
        //           .end(function(err, res) {
        //               if (err) return done(err);
        //               return done();
        //       });
        //   }); 
        //   });
          

          exports.mochaHooks = {
            beforeAll(done) {
              describe("POST /api/v1/roundDetail/add",function(){
                
                console.log("userid-------------------------------------------->",userOne._id);
                it('Should register a new roundDetail record', function(done){
                     request(app)
                      .post("POST /api/v1/roundDetail/add")
                      .set('authorization',`Bearer ${userOne.authToken}`)
                      .send({
                        
                        "holeNumber": 18,
                        "roundId": `${roundOne._id}`,
                         "scoreDetail": [{"playerId":` ${userOne._id}`, "score": 4}]
                        
                    })
                      
                      .expect('Content-Type', /json/)
                      .expect(200)
                      .end(function(err, res) {
                          if (err) return done(err);
                          done();
                  });
              }); 
              });
             ;
            },
           
          };
 
  describe('GET /api/v1/roundDetail', function() {
      it('Should get all roundDetail', function(done) {
        request(app)
          .get('/api/v1/roundDetail')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  

//---------------Leadeboardstatistic start--------------//


describe('GET /api/v1/leaderBoardStatistic', function() {
    it('Should get all leaderBoardStatistic ', function(done) {
      request(app)
        .get('/api/v1/leaderBoardStatistic')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  



  describe('GET /api/v1/coursewiseLeaderBoardStatistic', function() {
    it('Should get all CoursewiseleaderBoardStatistic ', function(done) {
      request(app)
        .get('/api/v1/coursewiseLeaderBoardStatistic')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  






//---------------Leadeboardstatistic end--------------//


    
describe(`PUT /api/v1/roundDetail${rounddetailOne._id}`, function() {
  it('Should update roundDetail', function(done) {
    request(app)
      .put(`/api/v1/roundDetail/${rounddetailOne._id}`)
     .set('authorization',`Bearer ${userOne.authToken}`)
      .send({
        "holeNumber": 9,
     })        
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  

describe(`DELETE /api/v1/roundDetail/${rounddetailOne._id}`, function() {
  it('Should delete round', function(done) {
    request(app)
      .delete(`/api/v1/roundDetail/${rounddetailOne._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)       
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  