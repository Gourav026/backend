const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { RoundSchema } = require('../schema/api')
var beforeAll = require('mocha').beforeAll;
var before = require('mocha').before;
const { userOne,setupDatabase ,roundOne,courseOne} = require('./utils/user')
const stateId = new mongoose.Types.ObjectId()




        // describe(`POST /api/v1/users/${userOne._id}/round/start`,function(){
        //     console.log("courseid-------------------------------------------->",courseOne._id)
        //     console.log("userid-------------------------------------------->",userOne._id);
        //     it('Should register a new round record', function(done){
        //          request(app)
        //           .post(`/api/v1/users/${userOne._id}/round/start`)
        //           .set('authorization',`Bearer ${userOne.authToken}`)
        //           .send({
                    
        //                 "data":[
        //                         {"courseId":`${courseOne._id}`}, 
        //                         {"name": "ROUND 4 - The Riviera Country Club "}, 
        //                         {"modeSelection": ["Match Play", "Team A vs B", "Both Ball", "Straight"]}, 
        //                         {"startingHole": 1}, 
        //                         {"player1": {"_id":`${userOne._id}`,"firstName":"Warren","lastName":"Hasting"}}, 
        //                         {"player2": {"_id":`${userOne._id}`,"firstName":"Rohui","lastName":"Wasting"}}
        //                      ]
                    
        //         })
                  
        //           .expect('Content-Type', /json/)
        //           .expect(200)
        //           .end(function(err, res) {
        //               if (err) return done(err);
        //               return done();
        //       });
        //   }); 
        //   });
          

          exports.mochaHooks = {
            beforeAll(done) {
              describe(`POST /api/v1/users/${userOne._id}/round/start`,function(){
                console.log("courseid-------------------------------------------->",courseOne._id)
                console.log("userid-------------------------------------------->",userOne._id);
                it('Should register a new round record', function(done){
                     request(app)
                      .post(`/api/v1/users/${userOne._id}/round/start`)
                      .set('authorization',`Bearer ${userOne.authToken}`)
                      .send({
                        
                            "data":[
                                    {"courseId":`${courseOne._id}`}, 
                                    {"name": "ROUND 4 - The Riviera Country Club "}, 
                                    {"modeSelection": ["Match Play", "Team A vs B", "Both Ball", "Straight"]}, 
                                    {"startingHole": 1}, 
                                    {"player1": {"_id":`${userOne._id}`,"firstName":"Warren","lastName":"Hasting"}}, 
                                    {"player2": {"_id":`${userOne._id}`,"firstName":"Rohui","lastName":"Wasting"}}
                                 ]
                        
                    })
                      
                      .expect('Content-Type', /json/)
                      .expect(200)
                      .end(function(err, res) {
                          if (err) return done(err);
                          done();
                  });
              }); 
              });
             ;
            },
           
          };
 
  describe('GET /api/v1/round', function() {
      it('Should get all round', function(done) {
        request(app)
          .get('/api/v1/round')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  


    
describe(`PUT /api/v1/round/${roundOne._id}`, function() {
  it('Should update round', function(done) {
    request(app)
      .put(`/api/v1/round/${roundOne._id}`)
     .set('authorization',`Bearer ${userOne.authToken}`)
      .send({"data":[
        {"name": "ROUND 6 - The Rcdc Country Club "}, 
        {"modeSelection": ["Match Play1", "Team C vs D", "Both Ball1", "Straight"]}, 
        {"startingHole": 2}, 
     ]})        
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  

// describe(`DELETE /api/v1/round/${roundOne._id}`, function() {
//   it('Should delete round', function(done) {
//     request(app)
//       .delete(`/api/v1/round/${roundOne._id}`)
//       .set('authorization',`Bearer ${userOne.authToken}`)       
//       .expect(200)
//       .end(function(err, res) {
//         if (err) return done(err);
//         return done();
//       });
//   });
// });  