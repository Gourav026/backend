const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
const { app,server } = require('../index')
var before = require('mocha').before;



const { userOne,setupDatabase , feedbackOne,countryOne,stateOne} = require('./utils/user')


before(setupDatabase);


describe('POST /api/v1/feedback/add', function(){
    it('Should add a new feedback record', function(done){
        data={
                description:"hii",
                title:"new title",
                "userId":`${userOne._id}`
          }
         request(app)
          .post('/api/v1/feedback/add')
          .send(data)
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
              //console.log("res=====",res.body)
              expect(res.body.response).to.include(data);
              if (err) return done(err);
              return done();
      });
  }); 
});



describe('GET /api/v1/feedback', function() {
    it('Should get all feedback', function(done) {
      request(app)
        .get('/api/v1/feedback')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  



// describe(`PUT /admin/v1/feedback/${feedbackOne._id}`, function() {
// it('Should update feedback', function(done) {
//     console.log("feedbackid_______________________>",feedbackOne._id);
//     request(app)
//     .put(`/admin/v1/feedback/${feedbackOne._id}`)
//     .set('authorization',`Bearer ${userOne.authToken}`)
//     .send({
//             description:'test feedbacky',
//         })        
//     .expect(200)
//     .end(function(err, res) {
//         if (err) return done(err);
//         return done();
//     });
// });
// });  

// describe(`DELETE /admin/v1/feedback/${feedbackOne._id}`, function() {
// it('Should delete feedback', function(done) {
//     request(app)
//     .delete(`/admin/v1/feedback/${feedbackOne._id}`)
//     .set('authorization',`Bearer ${userOne.authToken}`)       
//     .expect(200)
//     .end(function(err, res) {
//         if (err) return done(err);
//         return done();
//     });
// });
// });  

