const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { CourseDetailSchema } = require('../schema/api')
var before = require('mocha').before;
const { userOne,courseOne,coursedetailOne} = require('./utils/user')
const stateId = new mongoose.Types.ObjectId()


        describe('POST /api/v1/courseDetail/add', function(){
            it('Should register a new courseDetail record', function(done){
             
                 request(app)
                  .post('/api/v1/courseDetail/add')
                  .send({
                    "blueYard" : 1,
                    "whiteYard" : 2,
                    "yellowYard" : 3,
                    "redYard" : 4,
                    "courseId":`${courseOne._id}`,
                    "holeNumber" : 9,
                    "par" : 1,
                    "strokeIndex" : 2,           
                    "scoringAverage"  : 13,
                    "firstLatitude"   : 22.4930587 ,
                    "firstLongitude"  : 88.3578105438,
                    "secondLatitude"  :22.490567 ,
                    "secondLongitude" :89.3553 ,
                    "rotateDegree"    : 45,
                    // "geoLocation"     : {
                    //                    0
                                        
                    //                   },
                  "CenterLatLong" : {
                                        "latitude": 23.4968631050574,
                                        "longitude":89.3552356269836,
                                        "latitudeDelta":22.49225139754,
                                        "longitudeDelta":88.3512432933,
                                     },                  
                    
                  })
                  .expect('Content-Type', /json/)
                  .expect(200)
                  .end(function(err, res) {
                      if (err) return done(err);
                      return done();
              });
          }); 
          });
 
  describe('GET /api/v1/courseDetail', function() {
      it('Should get all courseDetail', function(done) {
        request(app)
          .get('/api/v1/courseDetail')
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
            if (err) return done(err);
           return done();
          });
      });
    });  

 /*
   * START
   * Test Case For Update Specific User Photo
   */

 describe(`PUT /api/v1/courseDetail/${coursedetailOne._id}`, function() {
    it('Should update courseDetail photo', function(done) {
      request(app)
        .put(`/api/v1/courseDetail/${coursedetailOne._id}`)
        .set('authorization',`Bearer ${userOne.authToken}`)
        .attach('avatar', 'test/fixtures/default.jpeg')
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
          return done();
        });
    });
  });  

/*
* END
* Test Case For Update Specific User Photo
*/
    
describe(`PUT /api/v1/courseDetail/${coursedetailOne._id}`, function() {
  it('Should update courseDetail', function(done) {
    request(app)
      .put(`/api/v1/courseDetail/${coursedetailOne._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)
      .send({ "blueYard" : 8,
      "whiteYard" : 9,
      "yellowYard" : 10,
      "redYard" : 6,})        
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  

describe(`DELETE /api/v1/courseDetail/${coursedetailOne._id}`, function() {
  it('Should delete courseDetails', function(done) {
    request(app)
      .delete(`/api/v1/courseDetail/${coursedetailOne._id}`)
      .set('authorization',`Bearer ${userOne.authToken}`)       
      .expect(200)
      .end(function(err, res) {
        if (err) return done(err);
        return done();
      });
  });
});  