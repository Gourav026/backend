const mongoose = require('mongoose')
const {UserSchema} = require('../../schema/api')
const {UserBusiness,CourseBusiness,CourseDetailBusiness} = require('../../businesses/')
const {CountrySchema} = require('../../schema/api')
const {CitySchema} = require('../../schema/api')
const {StateSchema} = require('../../schema/api')
const {CourseSchema} = require('../../schema/api')
const {CourseDetailSchema} = require('../../schema/api')
const {RoundSchema} = require('../../schema/api')
const {RoundDetailSchema} = require('../../schema/api')

const {PrivacySchema} = require('../../schema/api')
const {NewsFeedSchema} = require('../../schema/api')
const {HelpSchema} = require('../../schema/api')
const {TermSchema} = require('../../schema/api')
const {FeedbackSchema} = require('../../schema/api')
const {FaqSchema} = require('../../schema/api')
const {CommentSchema} = require('../../schema/api')


var { signToken } =require('../../auth/auth.service')



const userOneId     = new mongoose.Types.ObjectId()
const cityOneId = new mongoose.Types.ObjectId()
const countryOneId = new mongoose.Types.ObjectId()
const stateOneId = new mongoose.Types.ObjectId()
const courseOneId = new mongoose.Types.ObjectId()
const coursedetailOneId = new mongoose.Types.ObjectId()
const roundOneId = new mongoose.Types.ObjectId()
const rounddetailOneId = new mongoose.Types.ObjectId()

const newsFeedOneId = new mongoose.Types.ObjectId()
const privacyOneId = new mongoose.Types.ObjectId()
const helpOneId = new mongoose.Types.ObjectId()
const termOneId = new mongoose.Types.ObjectId()
const feedbackOneId = new mongoose.Types.ObjectId()
const faqOneId = new mongoose.Types.ObjectId()
const commentOneId = new mongoose.Types.ObjectId()

const userOne = {
    _id: userOneId,
    "firstName":"TestUser",
    "lastName":"lastname",
    "email":"testuser@gmail.com",
    "contactNumber":"7003544591",
    "emailVerify":true,
    "password":"123456",
    "authToken": signToken(userOneId,'user')
}

const countryOne = {
    _id: countryOneId,
    "name":"India",
    "status":true,
    

}

const stateOne = {

    _id: stateOneId,
    // "countryId":countryOneId,
    "name":"Westbengal",
    "status":true,
    

}

const cityOne = {

    _id: cityOneId,

    "name":"Kolkata",
    "status":true,
    

}

const coursedetailOne = {

    _id: coursedetailOneId,
        "blueYard" : 1,
        "whiteYard" : 2,
        "yellowYard" : 3,
        "redYard" : 4,
        "holeNumber" : 9,
        "par" : 1,
        "strokeIndex" : 2,
        "scoringAverage"  : 12,
        "firstLatitude"   : 22.4930567 ,
        "firstLongitude"  : 88.357810547638,
       "secondLatitude"  :22.4930567 ,
        "secondLongitude" :88.3553 ,
        "rotateDegree"    : 90,
      
      "CenterLatLong" : {
                            "latitude": 22.4968631050574,
                            "longitude":88.3552356269836,
                            "latitudeDelta":22.4922513974154,
                            "longitudeDelta":88.351243291633,
                         },                  

}

const courseOne= {

    _id: courseOneId,
    "rating" : 4.6,
    "lastRecord" : 0,
    "name" : "Delhi Golf Club",
    "description" : "The Delhi Golf Club, a municipal course in the early 1930s became a corporate entity in 24th February 1950. The Course, comprises of the championship 18 hole Lodhi Course, part of the Asian PGA Tour, and the shorter 9 hole Peacock Course. The latter came into being when the course was re-designed by Peter Thomson in 1976-77.",
    "blueYard" : 1,
    "redYard" : 2,
    "whiteYard" : 3,
    "yellowYard" : 4,
    "geoLocation" :[ 
        {
            "lat" : 22.4930567,
            "lng" : 88.3553
        }, 
        {
            "lat" : 22.4930567,
            "lng" : 88.3553
        }, 
        {
            "lat" : 22.4929377481547,
            "lng" : 88.357810547638
        }, 
        {
            "lat" : 22.4907569462013,
            "lng" : 88.3586044815064
        }, 
        {
            "lat" : 22.4902811302989,
            "lng" : 88.3557506111145
        }, 
        {
            "lat" : 22.4917085730983,
            "lng" : 88.3535082843781
        }
    ],
    

}

const roundOne = {
        _id: roundOneId, 
        "courseId":`${courseOneId}`, 
        "name": "ROUND 4 - The Riviera Country Club ", 
        "modeSelection": ["Match Play", "Team A vs B", "Both Ball", "Straight"], 
        "startingHole": 1, 
        "player1": {"_id":`${userOne._id}`,"firstName":"Warren","lastName":"Hasting"}
     }

const rounddetailOne  ={
    _id: rounddetailOneId,
    "holeNumber": 7, 
    "roundId":`${roundOne._id}`,
     "scoreDetail": [{"playerId": `${userOne._id}`, "score": 7},{"playerId":`${userOne._id}`, "score": "2"}] 
   

}

const newsFeedOne={
    _id:newsFeedOneId,
    //userId:           {type: mongoose.Schema.ObjectId}
    "description"     : "test description",
    //likedBy         : [{type: mongoose.Schema.ObjectId}]
    status:true
}

const commentOne={
    _id:commentOneId,
    "comment"     : "test comment",
    //likedBy         : [{type: mongoose.Schema.ObjectId}]
    status:true
}

const privacyOne={
    _id:privacyOneId,
    "description"     : "test description",
    status:true
}

const helpOne={
    _id:helpOneId,
    "description"     : "test description",
    "title"     : "test title",
    status:true
}

const termOne={
    _id:termOneId,
    "description"     : "test description",
    status:true
}

const feedbackOne={
    _id:feedbackOneId,
    "description"     : "test description",
    "title"     : "test title",
    status:true
}

const faqOne={
    _id:feedbackOneId,
    "description"     : "test description",
    "title"     : "test title",
    status:true
}
console.log('rounddetailOne---------------------------------------------------->',rounddetailOne);

const setupDatabase = async () => {
    let getUsers =  await UserSchema.find({}) 
    if(getUsers.length> 0)
    {
        getUsers.map( (user) => {  

                if(user.photo && user.photo!=''){
                    UserBusiness.unlinkFile(user.photo)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                    handleResponse(res, 500, err.message,false, err)
                    });
                }

                console.log('user.imageMediumPath--',user.imageMediumPath)

                if(user.imageMediumPath && user.imageMediumPath!=''){
                    UserBusiness.unlinkFile(user.imageMediumPath)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }

                if(user.imageThumbPath && user.imageThumbPath!=''){
                    UserBusiness.unlinkFile(user.imageThumbPath)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }
      })
    }

    let getCourses =  await CourseSchema.find({}) 
    if(getCourses.length> 0)
    {
        getCourses.map( (course) => {  

                if(course.photo && course.photo!=''){
                    CourseBusiness.unlinkFile(course.photo)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                    handleResponse(res, 500, err.message,false, err)
                    });
                }

                console.log('course.imageMediumPath--',course.imageMediumPath)

                if(course.imageMediumPath && course.imageMediumPath!=''){
                    CourseBusiness.unlinkFile(course.imageMediumPath)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }

                if(course.imageThumbPath && course.imageThumbPath!=''){
                    CourseBusiness.unlinkFile(course.imageThumbPath)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }
      })
    }


    let getCourseDetails =  await CourseSchema.find({}) 
    if(getCourseDetails.length> 0)
    {
        getCourseDetails.map( (courseDetail) => {  

                if(courseDetail.photo && courseDetail.photo!=''){
                    CourseBusiness.unlinkFile(courseDetail.photo)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                    handleResponse(res, 500, err.message,false, err)
                    });
                }

                console.log('courseDetail.imageMediumPath--',courseDetail.imageMediumPath)

                if(courseDetail.imageMediumPath && courseDetail.imageMediumPath!=''){
                    CourseBusiness.unlinkFile(courseDetail.imageMediumPath)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }

                if(courseDetail.imageThumbPath && courseDetail.imageThumbPath!=''){
                    CourseDetailBusiness.unlinkFile(courseDetail.imageThumbPath)
                    .then( unlinkres => { console.log('unlinkres-',unlinkres)})
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }
      })
    }

    await UserSchema.deleteMany()
    await UserSchema.create(userOne)
    await CountrySchema.deleteMany()
    await CountrySchema.create(countryOne)
    await StateSchema.deleteMany()
    await StateSchema.create(stateOne)
    await CitySchema.deleteMany()
    await CitySchema.create(cityOne)
    await CourseSchema.deleteMany()
    await CourseSchema.create(courseOne)
     await CourseDetailSchema.deleteMany()
    await CourseDetailSchema.create(coursedetailOne)
    await RoundSchema.deleteMany()
    await RoundSchema.create(roundOne)
    await RoundDetailSchema.deleteMany()
    await RoundDetailSchema.create(rounddetailOne)

    await NewsFeedSchema.deleteMany()
    await NewsFeedSchema.create(newsFeedOne)
    await PrivacySchema.deleteMany()
    await PrivacySchema.create(privacyOne)
    await HelpSchema.deleteMany()
    await HelpSchema.create(helpOne)
    await TermSchema.deleteMany()
    await TermSchema.create(termOne)
    await FeedbackSchema.deleteMany()
    await FeedbackSchema.create(feedbackOne)
    await FaqSchema.deleteMany()
    await FaqSchema.create(faqOne)
    await CommentSchema.deleteMany()
    await CommentSchema.create(commentOne)
}

module.exports = {
    userOne,
    setupDatabase,
    countryOne,
    countryOneId,
    stateOne,
    stateOneId,
    cityOne,
    cityOneId,
    courseOne,
    courseOneId,
    coursedetailOne,
    coursedetailOneId,
    roundOne,
    roundOneId,
    rounddetailOne,
    rounddetailOneId,
    privacyOneId,
    privacyOne,
    helpOneId,
    helpOne,
    termOneId,
    termOne,
    feedbackOneId,
    feedbackOne,
    faqOneId,
    faqOne,
    commentOneId,
    commentOne,
    newsFeedOneId,
    newsFeedOne

}