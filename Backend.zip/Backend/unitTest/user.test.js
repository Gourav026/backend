const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { UserSchema } = require('../schema/api')
var before = require('mocha').before;
const { setupDatabase , userOne} = require('./utils/user')
const userId = new mongoose.Types.ObjectId()

before(setupDatabase);


  /*
   * START
   * Test Case For Register a User
   */

      // describe('POST /api/v1/users/register', function() {
      //     it('Should register a new user', function(done) {
      //       request(app)
      //         .post('/api/v1/users/register')
      //         .send({
      //             "firstName":"registerfirstnameuser",
      //             "lastName":"registerlastnameuser",
      //             "email":"registeruser@gmail.com",
      //             "contactNumber":"7003544591",
      //             "password":"123456"
      //         })
      //         .expect(200)
      //         .end(function(err, res) {
      //           if (err) return done(err);
      //           return done();
      //         });
      //     });
          
      //   });

  /*
   * END
   * Test Case For Register a User
   */


  /*
   * START
   * Test Case For Find All User
   */

      describe('GET /api/v1/users', function() {
        it('Should get all users', function(done) {
          request(app)
            .get('/api/v1/users')
            .expect(200)
            .end(function(err, res) {
              if (err) return done(err);
              return done();
            });
        });
      });  

  /*
   * END
   * Test Case For Find All User
   */


  /*
   * START
   * Test Case For Find Specific User
   */   

      describe(`GET /api/v1/users/`, function() {
        it('Should get specific user', function(done) {
          request(app)
            .get(`/api/v1/users/`)
            .send({
              _id:userOne._id
            })
            .expect(200)
            .end(function(err, res) {
              if (err) return done(err);
              return done();
            });
        });
      });   

  /*
   * END
   * Test Case For Find Specific User
   */

  /*
   * START
   * Test Case For Update Specific User Photo
   */

      // describe(`PUT /api/v1/users/${userOne._id}`, function() {
      //   it('Should update user photo', function(done) {
      //     request(app)
      //       .put(`/api/v1/users/${userOne._id}`)
      //       .set('authorization',`Bearer ${userOne.authToken}`)
      //       .attach('photo', 'test/fixtures/default.jpeg')
      //       .expect(200)
      //       .end(function(err, res) {
      //         if (err) return done(err);
      //         return done();
      //       });
      //   });
      // });  

  /*
   * END
   * Test Case For Update Specific User Photo
   */

  
  /*
   * START
   * Test Case For Update Specific User
   */

      describe(`PUT /api/v1/users/${userOne._id}`, function() {
        it('Should update user photo', function(done) {
          request(app)
            .put(`/api/v1/users/${userOne._id}`)
            .set('authorization',`Bearer ${userOne.authToken}`)
            .send({firstName:'UpdatedUser'})        
            .expect(200)
            .end(function(err, res) {
              if (err) return done(err);
              return done();
            });
        });
      });  

  /*
   * END
   * Test Case For Update Specific User
   */  



  /*
   * START
   * Test Case For User Login Without Email verify
   */  

      describe('POST /auth/local/index', function() {
        it('Should login without email verify', function(done) {
          request(app)
            .post('/auth/local/index')
            .send({
                "email":"registeruser@gmail.com",
                "password":"123456"
            })        
            .expect(401)
            .end(function(err, res) {
              if (err) return done(err);
              return done();
            });
        });
      });  

  /*
   * END
   * Test Case For User Login Without Email verify
   */  
