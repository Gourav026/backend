const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
const { app,server } = require('../index')
var before = require('mocha').before;



const { userOne,setupDatabase , privacyOne,countryOne,stateOne} = require('./utils/user')


before(setupDatabase);


describe('POST /admin/v1/privacy/register', function(){
    it('Should register a new privacy record', function(done){
        data={
                description:"hii",
          }
         request(app)
          .post('/admin/v1/privacy/register')
          .send(data)
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
              //console.log("res=====",res.body)
              expect(res.body.response).to.include(data);
              if (err) return done(err);
              return done();
      });
  }); 
});



describe('GET /api/v1/privacy', function() {
    it('Should get all privacy', function(done) {
      request(app)
        .get('/api/v1/privacy')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  



describe(`PUT /admin/v1/privacy/${privacyOne._id}`, function() {
it('Should update privacy', function(done) {
    console.log("privacyid_______________________>",privacyOne._id);
    request(app)
    .put(`/admin/v1/privacy/${privacyOne._id}`)
    .set('authorization',`Bearer ${userOne.authToken}`)
    .send({
            description:'test privacyy',
        })        
    .expect(200)
    .end(function(err, res) {
        if (err) return done(err);
        return done();
    });
});
});  

describe(`DELETE /admin/v1/privacy/${privacyOne._id}`, function() {
it('Should delete privacy', function(done) {
    request(app)
    .delete(`/admin/v1/privacy/${privacyOne._id}`)
    .set('authorization',`Bearer ${userOne.authToken}`)       
    .expect(200)
    .end(function(err, res) {
        if (err) return done(err);
        return done();
    });
});
});  

