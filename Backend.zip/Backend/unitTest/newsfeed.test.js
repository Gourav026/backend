const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
const { app,server } = require('../index')
var before = require('mocha').before;



const { userOne,setupDatabase , newsFeedOne,countryOne,stateOne} = require('./utils/user')


before(setupDatabase);


describe('POST /api/v1/newsfeed/add', function(){
    it('Should register a new newsfeed record', function(done){
         request(app)
          .post('/api/v1/newsfeed/add')
          .attach('photo', 'test/fixtures/default.jpeg')
          .field({
                description:"hii",
                "userId":`${userOne._id}`

          })
          .expect('Content-Type', /json/)
          .expect(200)
          .end(function(err, res) {
              //console.log("res=====scdsd===",res.body)
              if (err) return done(err);
              return done();
      });
  }); 
});



describe('GET /api/v1/newsfeed', function() {
    it('Should get all newsfeed', function(done) {
      request(app)
        .get('/api/v1/newsfeed')
        .expect('Content-Type', /json/)
        .expect(200)
        .end(function(err, res) {
          if (err) return done(err);
         return done();
        });
    });
  });  



describe(`PUT /api/v1/newsfeed/${newsFeedOne._id}`, function() {
it('Should update newsfeed', function(done) {
    console.log("Newsfeedid_______________________>",newsFeedOne._id);
    request(app)
    .put(`/api/v1/newsfeed/${newsFeedOne._id}`)
    .set('authorization',`Bearer ${userOne.authToken}`)
    .send({description:'Bangalore'})        
    .expect(200)
    .end(function(err, res) {
        if (err) return done(err);
        return done();
    });
});
});  

describe(`DELETE /api/v1/newsfeed/${newsFeedOne._id}`, function() {
it('Should delete newsfeed', function(done) {
    request(app)
    .delete(`/api/v1/newsfeed/${newsFeedOne._id}`)
    .set('authorization',`Bearer ${userOne.authToken}`)       
    .expect(200)
    .end(function(err, res) {
        if (err) return done(err);
        return done();
    });
});
});  


// describe(`PUT /api/v1/users/${userOne._id}`, function() {
//     it('Should update user photo', function(done) {
//       request(app)
//         .put(`/api/v1/users/${userOne._id}`)
//         .set('authorization',`Bearer ${userOne.authToken}`)
//         .attach('photo', 'test/fixtures/default.jpeg')
//         .expect(200)
//         .end(function(err, res) {
//           if (err) return done(err);
//           return done();
//         });
//     });
//   });  