module.exports = {
  user: {
    type: 'document',
    index: 'users'
  }
};