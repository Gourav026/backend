const mongoose = require('mongoose')
const {UserSchema} = require('../../schema/api')
const {UserBusiness,CourseBusiness,CourseDetailBusiness} = require('../../businesses/')
const {CourseSchema} = require('../../schema/api')
const {CourseDetailSchema} = require('../../schema/api')
const {RoundSchema} = require('../../schema/api')
const {RoundDetailSchema} = require('../../schema/api')



var { signToken } =require('../../auth/auth.service')



const userOneId     = "6095fa5cd98b4c411aab92bf"//new mongoose.Types.ObjectId()

const courseOneId = new mongoose.Types.ObjectId()
const coursedetailOneId = new mongoose.Types.ObjectId()
const roundOneId = new mongoose.Types.ObjectId()
const rounddetailOneId = new mongoose.Types.ObjectId()


const userOne = {
    _id: userOneId,
    "firstName":"TestUser",
    "lastName":"lastname",
    "email":"testuser@gmail.com",
    "contactNumber":"7003544591",
    "emailVerify":true,
    "password":"123456",
    "authToken": signToken(userOneId,'user')
}



const coursedetailOne = {

    _id: coursedetailOneId,
        "blueYard" : 1,
        "whiteYard" : 2,
        "yellowYard" : 3,
        "redYard" : 4,
        "holeNumber" : 9,
        "par" : 1,
        "strokeIndex" : 2,
        "scoringAverage"  : 12,
        "firstLatitude"   : 22.4930567 ,
        "firstLongitude"  : 88.357810547638,
       "secondLatitude"  :22.4930567 ,
        "secondLongitude" :88.3553 ,
        "rotateDegree"    : 90,
      
      "CenterLatLong" : {
                            "latitude": 22.4968631050574,
                            "longitude":88.3552356269836,
                            "latitudeDelta":22.4922513974154,
                            "longitudeDelta":88.351243291633,
                         },                  

}
        
    
    




const courseOne= {

    _id: courseOneId,
    "rating" : 4.6,
    "lastRecord" : 0,
    "name" : "Delhi Golf Club",
    "description" : "The Delhi Golf Club, a municipal course in the early 1930s became a corporate entity in 24th February 1950. The Course, comprises of the championship 18 hole Lodhi Course, part of the Asian PGA Tour, and the shorter 9 hole Peacock Course. The latter came into being when the course was re-designed by Peter Thomson in 1976-77.",
    "blueYard" : 1,
    "redYard" : 2,
    "whiteYard" : 3,
    "yellowYard" : 4,
    "geoLocation" :[ 
        {
            "lat" : 22.4930567,
            "lng" : 88.3553
        }, 
        {
            "lat" : 22.4930567,
            "lng" : 88.3553
        }, 
        {
            "lat" : 22.4929377481547,
            "lng" : 88.357810547638
        }, 
        {
            "lat" : 22.4907569462013,
            "lng" : 88.3586044815064
        }, 
        {
            "lat" : 22.4902811302989,
            "lng" : 88.3557506111145
        }, 
        {
            "lat" : 22.4917085730983,
            "lng" : 88.3535082843781
        }
    ],
    

}

const roundOne = {
        _id: roundOneId, 
        "courseId":`${courseOneId}`, 
        "name": "ROUND 4 - The Riviera Country Club ", 
        "modeSelection": ["Match Play", "Team A vs B", "Both Ball", "Straight"], 
        "startingHole": 1, 
        "player1": {"_id":`${userOne._id}`,"firstName":"Warren","lastName":"Hasting"}
     }

//console.log('roundOne---------------->',roundOne);

const rounddetailOne  ={
    _id: rounddetailOneId,
    "holeNumber": 7, 
    "roundId":`${roundOne._id}`,
     "scoreDetail": [{"playerId": `${userOne._id}`, "score": 7},{"playerId":`${userOne._id}`, "score": "2"}] 
   

}


//console.log('rounddetailOne---------------------------------------------------->',rounddetailOne);

const setupDatabase = async () => {
    let getUsers =  await UserSchema.find({}) 
    if(getUsers.length> 0)
    {
        getUsers.map( (user) => {  

                if(user.photo && user.photo!=''){
                    UserBusiness.unlinkFile(user.photo)
                    .then( unlinkres => { //console.log('unlinkres-',unlinkres)
                    })
                    .catch((err) => {
                    handleResponse(res, 500, err.message,false, err)
                    });
                }

                //console.log('user.imageMediumPath--',user.imageMediumPath)

                if(user.imageMediumPath && user.imageMediumPath!=''){
                    UserBusiness.unlinkFile(user.imageMediumPath)
                    .then( unlinkres => { //console.log('unlinkres-',unlinkres)
                    })
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }

                if(user.imageThumbPath && user.imageThumbPath!=''){
                    UserBusiness.unlinkFile(user.imageThumbPath)
                    .then( unlinkres => { //console.log('unlinkres-',unlinkres)'
                    })
                    .catch((err) => {
                        handleResponse(res, 500, err.message,false, err)
                    });
                }
      })
    }

    let getCourses =  await CourseSchema.find({}) 
    // if(getCourses.length> 0)
    // {
    //     getCourses.map( (course) => {  

    //             if(course.photo && course.photo!=''){
    //                 CourseBusiness.unlinkFile(course.photo)
    //                 .then( unlinkres => { //console.log('unlinkres-',unlinkres)
    //                 })
    //                 .catch((err) => {
    //                 handleResponse(res, 500, err.message,false, err)
    //                 });
    //             }

    //             //console.log('course.imageMediumPath--',course.imageMediumPath)

    //             if(course.imageMediumPath && course.imageMediumPath!=''){
    //                 CourseBusiness.unlinkFile(course.imageMediumPath)
    //                 .then( unlinkres => { //console.log('unlinkres-',unlinkres)
    //                 })
    //                 .catch((err) => {
    //                     handleResponse(res, 500, err.message,false, err)
    //                 });
    //             }

    //             if(course.imageThumbPath && course.imageThumbPath!=''){
    //                 CourseBusiness.unlinkFile(course.imageThumbPath)
    //                 .then( unlinkres => { //console.log('unlinkres-',unlinkres)
    //                 })
    //                 .catch((err) => {
    //                     handleResponse(res, 500, err.message,false, err)
    //                 });
    //             }
    //   })
    // }


    let getCourseDetails =  await CourseSchema.find({}) 
    // if(getCourseDetails.length> 0)
    // {
    //     getCourseDetails.map( (courseDetail) => {  

    //             if(courseDetail.photo && courseDetail.photo!=''){
    //                 CourseBusiness.unlinkFile(courseDetail.photo)
    //                 .then( unlinkres => { //console.log('unlinkres-',unlinkres)
    //                 })
    //                 .catch((err) => {
    //                 handleResponse(res, 500, err.message,false, err)
    //                 });
    //             }

    //             //console.log('courseDetail.imageMediumPath--',courseDetail.imageMediumPath)

    //             if(courseDetail.imageMediumPath && courseDetail.imageMediumPath!=''){
    //                 CourseBusiness.unlinkFile(courseDetail.imageMediumPath)
    //                 .then( unlinkres => { //console.log('unlinkres-',unlinkres)
    //                 })
    //                 .catch((err) => {
    //                     handleResponse(res, 500, err.message,false, err)
    //                 });
    //             }

    //             if(courseDetail.imageThumbPath && courseDetail.imageThumbPath!=''){
    //                 CourseDetailBusiness.unlinkFile(courseDetail.imageThumbPath)
    //                 .then( unlinkres => { //console.log('unlinkres-',unlinkres)
    //                 })
    //                 .catch((err) => {
    //                     handleResponse(res, 500, err.message,false, err)
    //                 });
    //             }
    //   })
    // }

    await UserSchema.deleteMany()
    await UserSchema.create(userOne)
    await CourseSchema.deleteMany()
    await CourseSchema.create(courseOne)
    await CourseDetailSchema.deleteMany()
    await CourseDetailSchema.create(coursedetailOne)
    await RoundSchema.deleteMany()
    //await RoundSchema.create(roundOne)
    await RoundDetailSchema.deleteMany()
   // await RoundDetailSchema.create(rounddetailOne)
    
}

module.exports = {
    userOne,
    setupDatabase,
    courseOne,
    courseOneId,
     coursedetailOne,
     coursedetailOneId,
     roundOne,
    roundOneId,
    rounddetailOne,
     rounddetailOneId,

}