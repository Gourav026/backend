const request = require('supertest')
const mongoose = require('mongoose')
const expect = require('chai').expect
var { signToken } =require('../auth/auth.service')
const { app,server } = require('../index')
const { StateSchema } = require('../schema/api')
var before = require('mocha').before;
const { userOne,setupDatabase ,courseOne} = require('./utils/user')
const stateId = new mongoose.Types.ObjectId()
const axios = require('axios').default;
const {UserSchema,CourseSchema} = require('../schema/api')
const  playerDatatoUpdate=require('./utils/playerData')



before(setupDatabase);

  let courseData={};
  let playersData=[]
  userIds=["6095fa5cd98b4c411aab92bf","60a36597603e1c4b3ea96f33","60a3676d603e1c4b3ea96f35","60a36838603e1c4b3ea96f36"]
  let roundData={}
  let allPlayerData=[]
  //let userData=[]

describe('GET /api/v1/course', function() {
	it('User selects a course', function(done) {
		
		axios.get('https://node.addydigital.com:3003/api/v1/course?_id=5ffec04cabd859700b3fddab')
			.then(async (response)=>{

				expect(response.data.statuscode).to.equal(200,"course fetch success");

				courseData= response.data.response[0].data[0];
				////console.log("courseData-----",courseData);
				courseData={
					_id:courseData._id,
					name: courseData.name,
					description: courseData.description,
					blueYard: courseData.blueYard,
					whiteYard: courseData.whiteYard,
					yellowYard: courseData.yellowYard,
					redYard: courseData.redYard,
					
				}
				
				await CourseSchema.create(courseData)

				return done();
			})
			.catch(err=>{
			//console.log(err);
			})          
		
		
			//return done();
	}).timeout(5000);
});  

    

//=============== get player 1 ==================
describe('GET /api/v1/user', function() {
	it('Player 1 selected',function(done) {
			axios.get(`https://node.addydigital.com:3003/api/v1/users?_id=${userIds[0]}`)
			.then(async (response)=>{
				//to insert in our test db

				expect(response.data.statuscode).to.equal(200,"player 1 fetch success");
				let playerData= response.data.response[0].data[0];
				playerData= playerDatatoUpdate(playerData);
				
				allPlayerData[0]=playerData
				
				//console.log("updated=",playerData);
				playersData.push(playersData)
    			const data=await UserSchema.updateOne(playerData)
				//console.log("data in player1=",data);
				statuscode=data._id?200:500
				expect(statuscode,200,"data inserted successfully")
				return done();
			})
			.catch(err=>{
				//console.log(err);
				return done();

			})  
			//return done();
	}).timeout(20000);
});  


//=============== get player 2 ==================

describe('GET /api/v1/user', function() {
	it('Player 2 selected',function(done) {
			axios.get(`https://node.addydigital.com:3003/api/v1/users?_id=${userIds[1]}`)
			.then(async (response)=>{
				//to insert in our test db
				expect(response.data.statuscode).to.equal(200,"player 2 fetch success");
				let playerData= response.data.response[0].data[0];
				playerData= playerDatatoUpdate(playerData);
				
				allPlayerData[1]=playerData
				////console.log("updated=",playerData);
				playersData.push(playersData)
    			await UserSchema.create(playerData)
				return done();
			})
			.catch(err=>{
				//console.log(err);
				return done();

			})  
			//return done();

	}).timeout(20000);
});  

//=============== get player 3 ==================

describe('GET /api/v1/user', function() {
	it('Player 3 selected',function(done) {
			axios.get(`https://node.addydigital.com:3003/api/v1/users?_id=${userIds[2]}`)
			.then(async (response)=>{
				//to insert in our test db
				expect(response.data.statuscode).to.equal(200,"player 3 fetch success");
				let playerData= response.data.response[0].data[0];
				playerData= playerDatatoUpdate(playerData);
				allPlayerData[2]=playerData
	
				////console.log("updated=",playerData);
				playersData.push(playersData)
    			await UserSchema.create(playerData)
				return done();
			})
			.catch(err=>{
				//console.log(err);
				return done();

			})  
			//return done();
	}).timeout(20000);
});  


//=============== get player 4 ==================

describe('GET /api/v1/user', function() {
	it('Player 4 selected',function(done) {
			axios.get(`https://node.addydigital.com:3003/api/v1/users?_id=${userIds[3]}`)
			.then(async (response)=>{
				//to insert in our test db
				expect(response.data.statuscode).to.equal(200,"player 4 fetch success");
				let playerData= response.data.response[0].data[0];
				playerData= playerDatatoUpdate(playerData);
				allPlayerData[3]=playerData
	
				////console.log("updated=",playerData);
				playersData.push(playersData)
    			await UserSchema.create(playerData)
				console.log("p=",(allPlayerData));
				return done();
			})
			.catch(err=>{
				//console.log(err);
				return done();

			})  
			//return done(); 
	}).timeout(20000);
});  

//========================= start round=====================

describe('POST /api/v1/users/:id/round/start', function(){
	it('new round started with 4 players', function(done){

	//console.log("courseData=",courseData);

		request(app)
		.post(`/api/v1/users/${userIds[0]}/round/start`)
		.set('authorization',`Bearer ${userOne.authToken}`)
		.set('Content-Type', 'application/json')
		.send({"data":[
			{"courseId":courseData._id},
			{"name"           : "round 1"},
            {"modeSelection"   : ["Match Play", "Team A vs B", "Both Ball", "Straight"]},
            {"startingHole"    : 1},   
            {"player1"        : {"_id":userIds[1],"firstName":"Ridd","lastName":"Biswas"} 
            },
            {
                "player2"         : {
                    "_id": userIds[0],
                    "firstName": "Abhishek",
                    "lastName": "Agrahari"
                    
                }
            },
			{
                "player3"         : {
                    "_id": userIds[2],
                    "firstName": "Biswajit",
                    "lastName": "shaw"
                    
                }
            },
			{
                "player4"         : {
                    "_id": userIds[3],
                    "firstName": "Rajeev",
                    "lastName": "shaw"
                    
                }
            }
            
		]})
		.expect(200)
		.end(function(err, res) {
			if (err)
				return done(err);

			//console.log("res=",res.body);
			roundData=res.body;
			return done();
		})
	// return done()
}).timeout(50000); 
});
    