var joibird = require('joibird')

class StateValidator {
	//validate create new data
	static validateCreating(body)  {
		var schema = joibird.object().keys({

			name: joibird.string().required().options({
				language: {
					key: 'name ',
					string: {
						min: 'name required'
					}
				}
			}),

			countryId: joibird.string().required().options({
				language: {
					key: 'countryId ',
					string: {
						min: 'countryId required'
					}
				}
			}),

			stateId: joibird.string().required().options({
				language: {
					key: 'stateId ',
					string: {
						min: 'stateId required'
					}
				}
			})

		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
	
	static validateUpdating(body)  {
		var schema = joibird.object().keys({
	    id: joibird.string().required().options({
	    	language: {
	    		key: 'id ',
	    		string: {
	    			min: 'id required'
	    		}
	    	}
		})
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
}

module.exports = StateValidator;
