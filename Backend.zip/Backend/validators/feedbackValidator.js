let joibird=require("joibird")

class FeedbackValidator{
    static validateCreating(body){

        let schema=joibird.object().keys({
            title: joibird.string().required().options({
				language: {
					key: 'title',
					string: {
						min: 'title required'
					}
				}
			}),
            
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    } 

	
}

module.exports=FeedbackValidator