let joibird=require('joibird')

class NotificationValidator{
    static validateCreating(body)
    {
        let schema=joibird.object().keys({

            fromUser: joibird.string().required().options({
                language: {
                    key: 'fromUser ',
                    string: {
                        min: 'fromUser required'
                    }
                }
            }),
            toUser: joibird.string().required().options({
                language: {
                    key: 'toUser ',
                    string: {
                        min: 'toUser required'
                    }
                }
            }),
            message: joibird.string().required().options({
                language: {
                    key: 'message ',
                    string: {
                        min: 'message required'
                    }
                }
            }),
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    }


    static validateUpdating(body)
    {
        let schema=joibird.object().keys({

            id: joibird.string().required().options({
                language: {
                    key: 'id ',
                    string: {
                        min: 'id required'
                    }
                }
            })
            
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    }
}

module.exports= NotificationValidator;