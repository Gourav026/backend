let joibird=require('joibird')

class CommentValidator{
    static validateCreating(body)
    {
        let schema=joibird.object().keys({

            comment: joibird.string().required().options({
                language: {
                    key: 'comment ',
                    string: {
                        min: 'comment required'
                    }
                }
            }),
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    }


    static validateUpdating(body)
    {
        let schema=joibird.object().keys({

            id: joibird.string().required().options({
                language: {
                    key: 'id ',
                    string: {
                        min: 'id required'
                    }
                }
            })
            
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    }
}

module.exports= CommentValidator;