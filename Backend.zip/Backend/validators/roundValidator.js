var joibird = require('joibird')

class UserTempValidator {
	//validate create new data
	static validateCreating(body)  {
		var schema = joibird.object().keys({

			name: joibird.string().required().options({
				language: {
					key: 'name ',
					string: {
						min: 'name required'
					}
				}
			}),
			courseId: joibird.string().required().options({
				language: {
					key: 'courseId ',
					string: {
						min: 'courseId required'
					}
				}
			}),
			modeSelection: joibird.array().required().options({
				language: {
					key: 'modeSelection ',
					string: {
						min: 'modeSelection required'
					}
				}
			}),
			player1: joibird.object().required().options({
				language: {
					key: 'player1 ',
					string: {
						min: 'player1 required'
					}
				}
			})
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
	
	static validateUpdating(body)  {
		var schema = joibird.object().keys({
	    id: joibird.string().required().options({
	    	language: {
	    		key: 'id ',
	    		string: {
	    			min: 'id required'
	    		}
	    	}
		})
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}

}

module.exports = UserTempValidator;
