let joibird=require("joibird")

class FaqValidator{
    static validateCreaating(body){

        let schema=joibird.object().keys({
            title: joibird.string().required().options({
				language: {
					key: 'title ',
					string: {
						min: 'title required'
					}
				}
			}),
            
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    } 

	static validateUpdating(body)  {
		var schema = joibird.object().keys({
	    id: joibird.string().required().options({
	    	language: {
	    		key: 'id ',
	    		string: {
	    			min: 'id required'
	    		}
	    	}
		})
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
}

module.exports=FaqValidator