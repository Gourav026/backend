let joibird=require('joibird')

class PetitionValidator{
    static validateCreating(body)
    {
        let schema=joibird.object().keys({

            userId: joibird.string().required().options({
                language: {
                    key: 'userId ',
                    string: {
                        min: 'userId required'
                    }
                }
            }),
            roundId: joibird.string().required().options({
                language: {
                    key: 'roundId ',
                    string: {
                        min: 'roundId required'
                    }
                }
            }),
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    }


    static validateUpdating(body)
    {
        let schema=joibird.object().keys({

            id: joibird.string().required().options({
                language: {
                    key: 'id ',
                    string: {
                        min: 'id required'
                    }
                }
            })
            
        });
        return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
    }
}

module.exports= PetitionValidator;