var _ =require('lodash')
var UserValidator =require('./userValidator')
var CountryValidator =require('./countryValidator')
var StateValidator =require('./stateValidator')
var CityValidator =require('./cityValidator')
var CourseValidator =require('./courseValidator')
var CourseDetailValidator =require('./courseDetailValidator')
var RoundValidator =require('./roundValidator')
var RoundDetailValidator =require('./roundDetailValidator')
var TermValidator =require('./termValidator')
var PrivacyValidator =require('./privacyValidator')
var AboutUsValidator =require('./aboutUsValidator')
var NewsFeedValidator =require('./newsFeedValidator')
var CommentValidator =require('./commentValidator')
var FeedbackValidator =require('./feedbackValidator')
let HelpValidator=require("./helpValidator")
let FaqValidator=require("./faqValidator")
let PetitionValidator=require("./petitionValidator")
let NotificationValidator=require("./notificationValidator")
let InsuaranceformValidator=require("./insuaranceformValidator")


let parseJoiError = (err) => {
	let errors = {};
  _.map(err.details, e => {
  	if(!errors[e.path]) {
  		errors[e.path] = [];
  	}
    errors[e.path].push(e.message);
  });
  return errors;
};

module.exports= {
	parseJoiError,
	UserValidator,
	CountryValidator,
	StateValidator,
	CityValidator,
	CourseValidator,
	CourseDetailValidator,
	RoundValidator,
	RoundDetailValidator,
	TermValidator,
	PrivacyValidator,
	CommentValidator,
	NewsFeedValidator,
	AboutUsValidator,
	HelpValidator,
	FaqValidator,
	FeedbackValidator,
	PetitionValidator,
	NotificationValidator,
	InsuaranceformValidator
};
