var joibird = require('joibird')

class StateValidator {
	//validate create new data
	static validateCreating(body)  {
		var schema = joibird.object().keys({
			roundId: joibird.string().required().options({
				language: {
					key: 'roundId ',
					string: {
						min: 'roundId required'
					}
				}
			}),

			holeNumber: joibird.number().required().options({
				language: {
					key: 'holeNumber ',
					string: {
						min: 'holeNumber required'
					}
				}
			})
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
	
	static validateUpdating(body)  {
		var schema = joibird.object().keys({
	    id: joibird.string().required().options({
	    	language: {
	    		key: 'id ',
	    		string: {
	    			min: 'id required'
	    		}
	    	}
		})
		});
		return joibird.validate(body, schema, {
			stripUnknown: true,
			abortEarly: false
		});
	}
}

module.exports = StateValidator;
