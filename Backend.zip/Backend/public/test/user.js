

 function deleteAllUser(){


    let deletePromise = new Promise( (resolve, reject) => { 
                            const res =  superagent
                            .delete(`${api}/api/v1/users/deleteAll`)
                            .end((err, res) => {
                                // Calling the end function will send the request
                                resolve(res)
                            });
                        });
     console.log(deletePromise);

    return deletePromise
}

 function beforeUserTest(){

    let userData ={
        "firstName":"testuser",
        "lastName":"name",
        "email":"admintea@gmail.com",
        "contactNumber":"7003544591",
        "password":"123456",
        "emailVerify":true
    }
    console.log(userData);

      let promise = new Promise( (resolve, reject) => { 
        const res =  superagent
        .post(`${api}/api/v1/users/register`)
        .send(userData)
        .end((err, res) => {
            // Calling the end function will send the request
            resolve(res)
          });
        console.log(res);
    })

    return promise
}

function checkUserLogin(){

   let userData ={
       "email":"admintea@gmail.com",
       "password":"123456"
   }

   console.log(userData);
     let promise = new Promise( (resolve, reject) => { 
       const res =  superagent
       .post(`${api}/auth/local/index`)
       .send(userData)
       .end((err, res) => {
           // Calling the end function will send the request
           resolve(res)
         });
       console.log(res);
   })

   return promise
}