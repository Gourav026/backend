


function deleteAllCountry(){


    let deletePromise = new Promise( (resolve, reject) => { 
                            const res =  superagent
                            .delete(`${api}/api/v1/country/deleteAll`)
                            .end((err, res) => {
                                // Calling the end function will send the request
                                resolve(res)
                            });
                        });
     console.log(deletePromise);

    return deletePromise
}


function beforeCountryTest(){

    let countryData ={
        "name":"Srilanka",
    }
    console.log("countryDa________----------------------___________>>",countryData);

      let promise = new Promise( (resolve, reject) => { 
        const res =  superagent
        .post(`${api}/api/v1/country/add`)
        .send(countryData)
        .end((err, res) => {
            // Calling the end function will send the request
            resolve(res)
          });
        console.log(res);
    })

    return promise
}


// function updateCountry() {
//     let countryData ={
//         _id: countryOneId,
//         "name":"Srilanka",
//     }
//     console.log("countryData---------------------================--------------->",countryData);
//     let promise = new Promise( (resolve, reject) => { 
//         const res =  superagent
//         .PUT (`${api}/api/v1/country/${countryData._id}`)
//         .send(countryData)
//         .end((err, res) => {
//             // Calling the end function will send the request
//             resolve(res)
//           });
//         console.log(res);
//     })

//     return promise
    
// }