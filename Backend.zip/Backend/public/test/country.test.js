// const api = 'http://localhost:3004' 


var countryId =''

describe('#Api Test Case For Country', async function() {
  //this.timedOut(50000)
     context('GET all Countries', async function() {


      it('should delete all countries',async function() {
        
        return new Promise(function (resolve) {
          deleteAllCountry()
            .then(function(result) {
              console.log('delCountry------------------------------------------------------->',result)

               resolve();
            });
       });
     
      
      })


      it('should return one added user',async function() {
    
        return new Promise(function (resolve) {
            beforeCountryTest()
            .then(function(result) {
              console.log('added country---------------------------------->',result)
              countryId = result.body.response._id
               resolve();
            });
         });

        })

        it('should return all countriess',async function() {
                

            (async () => {
              console.log('get authToken',authToken)
              console.log('get countryId',countryId)
  
              try {
                const res = await superagent.get(`${api}/api/v1/country`);
                console.log(res);
  
                console.log('apires----',apires);
                expect(apires.status).to.equal(200)
                
              } catch (err) {
                console.error(err);
              }
            })()
  
                
            })
  
            it('should update one country',async function() {
                  
              (async () => {
  
                console.log('get authToken',authToken)
              console.log('get countryId',countryId)
                try {
                  const res = await superagent.put(`${api}/api/v1/country/${countryId}`)
                  .set('authorization',`Bearer ${authToken}`)
                  .send({"name":"India"})
                  console.log(res);
                } catch (err) {
                  console.error(err);
                }
              })();
    
                  
              })
  
  
              it('should delete one country',async function() {
                  
                (async () => {
    
                  console.log('get authToken',authToken)
                console.log('get countryId',countryId)
                  try {
                    const res = await superagent.delete(`${api}/api/v1/country/${countryId}`)
                    .set('authorization',`Bearer ${authToken}`)
                    console.log(res);
                  } catch (err) {
                    console.error(err);
                  }
                })();
      
                    
                })
        


     })

    })