//const api = 'https://node.addydigital.com:3004'
const api = 'https://golfernet-backend.herokuapp.com/' 
//const api = 'http://localhost:3004' 


var userId =''
var authToken =''
describe('#Api Test Case For User', async function() {
  //this.timedOut(50000)
     context('GET all Users', async function() {


      it('should delete all users',async function() {
        
        return new Promise(function (resolve) {
          deleteAllUser()
            .then(function(result) {
              console.log('del',result)

               resolve();
            });
       });
     
      
      })

      it('should return one added user',async function() {
    
        return new Promise(function (resolve) {
          beforeUserTest()
            .then(function(result) {
              console.log('added user',result)
              userId = result.body.response._id
               resolve();
            });
         });

        })

        it('should return login user',async function() {
    
          return new Promise(function (resolve) {
            checkUserLogin()
              .then(function(result) {
                console.log('authToken',result.body.response.authToken)
                authToken = result.body.response.authToken
                 resolve();
              });
           });
  
          })

        it('should return all users',async function() {
                

          (async () => {
            console.log('get authToken',authToken)
            console.log('get userId',userId)

            try {
              const res = await superagent.get(`${api}/api/v1/users`);
              console.log(res);

              console.log('apires----',apires);
              expect(apires.status).to.equal(200)
              
            } catch (err) {
              console.error(err);
            }
          })()

              
          })
      
    })

    
  })
  
  