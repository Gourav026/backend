var express = require('express');
var fileUpload = require('express-fileupload');
var mongoose = require('mongoose');
var bodyparser = require('body-parser');
var cookieParser = require('cookie-parser');
var path = require('path');
var methodOverride = require('method-override');
var _ = require('lodash');
var config = require("./config");
var UserSchema = require("./schema/api/users");
var PetitionSchema = require("./schema/api/petition");

const { generateMessage, generateLocationMessage } = require('./utils/messages')
const { addUser, removeUser, getUser, getUsersInRoom } = require('./utils/users')
var https = require('https');
var http = require('http');
var fs = require('fs');
var rp = require('request-promise');
const socketIo = require("socket.io");
// This line is from the Node.js HTTPS documentation.............................
// /etc/letsencrypt/live/node.addydigital.com/fullchain.pem
// Your key file has been saved at:
// /etc/letsencrypt/live/node.addydigital.com/privkey.pem

// const credential = {
//   key: fs.readFileSync('/home/ec2-user/privkey.pem','utf8'),
//   cert: fs.readFileSync('/home/ec2-user/fullchain.pem','utf8')
// };

var app = express();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
require('dotenv').config({path: __dirname + '/.env'})
//var server = https.createServer(credential, app);
var server = http.createServer(app);

//var server = https.createServer(credentials, app);
var io = socketIo(server);
//==============Add middleware necessary for REST API's===============
app.use(bodyparser.urlencoded(
    {
        limit: '50mb',
        parameterLimit: 100000, 
        extended: true 
    }));
app.use(bodyparser.json());
app.use(fileUpload());

var timeOut = 60 * 10000;
app.use(cookieParser());

// app.get("*", function (req, res) {
//     res.sendFile(__dirname + '/public/views/404.html');
// });


app.use(methodOverride('X-HTTP-Method-Override'));

//==========Add module to recieve file from angular to node===========
app.use(express.static(__dirname + '/public'));

//===========================CORS support==============================
app.use(function (req, res, next) {

    req.setEncoding('utf8');
    // Website you wish to allow to connect
    res.setHeader("Access-Control-Allow-Origin", "*");

    // Request methods you wish to allow
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");

    // Request headers you wish to allow
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, x-access-token, user_id, authtoken, authorization");
    //res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, x-access-token");
    res.setHeader("Access-Control-Allow-Credentials", true);

    if ('OPTIONS' == req.method) {
        res.sendStatus(200);
    } else {
        next();
    }
});
//=========================Load the routes===============================
var authRoutes = require('./auth');

app.get("/resetPassword/:id/:authToken", async function (req, res) {
    console.log('id-->',req.params.id);
    let _id = req.params.id
    res.sendFile(__dirname + '/public/views/forgetPassword.html', {_id:_id});
})

app.get("/accountVerify/:id/:authToken", async function (req, res) {
    console.log('id-->',req.params.id);
    let _id = req.params.id
    res.sendFile(__dirname + '/public/views/signupVerification.html', {_id:_id});
})

app.get("/signedPetition/:userId/:roundId", async function (req, res) {
    let userId = req.params.userId
    let roundId = req.params.roundId
    await PetitionSchema.updateOne({userId:userId, roundId:roundId},{$set:{signedStatus:'Done'}})
    res.sendFile(__dirname + '/public/views/petition.html');
})




//-------------------------important---------------------------
app.use('/auth', authRoutes);

var apiRoutes = require('./routes/apiRoutes.js');
app.use('/api', apiRoutes);

var adminRoutes = require('./routes/adminRoutes.js');
app.use('/admin', adminRoutes);

//-------------------------important---------------------------

//===========================Connect to MongoDB==========================
console.log('process env------',process.env.DB_ENV);
// var db = config.database['local'];
// db.dbName = process.env.DB_ENV
// var connectionString = "mongodb://" + db.host + ":" + db.port + "/" + db.dbName
//mongodb+srv://gourav:Gourav123@cluster0.daale.mongodb.net/myFirstDatabase?retryWrites=true&w=majority
//compass link ---mongodb+srv://golfer:YV5gVumDcAB9h0D7@cluster0.zi288.mongodb.net/test

var connectionString = "mongodb+srv://golfer:YV5gVumDcAB9h0D7@cluster0.zi288.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
mongoose.connect(connectionString, function (err) {
    if (err) {
        console.log(err)
    } else {
        console.log('Connected to database ' );
    }
});

// db.dbName =='golf' ? mongoose.set('debug', true):'';
//===========================Connect to MongoDB==========================
io.sockets.on('connection', function (socket) {
    console.log(socket.id + 'a user connected');
    socket.on('inappmessage', async (message) => {
        console.log('WebSocket startCall connected')
        io.emit('message',  message)
    })
})
module.exports = { app, server}